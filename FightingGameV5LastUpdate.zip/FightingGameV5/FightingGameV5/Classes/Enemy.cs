namespace EnemyCsharp
{
    class Enemy
    {
        public int hp = 200; // Health of the Enemy
        public int atk = 10; // does nothing tbh
        public int def = 10; // reduces Damage dealt by Player
        public int spareprog = 0; // How far the Enemy is to being spared in %
    }
}