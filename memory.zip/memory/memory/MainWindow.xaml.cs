﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace memory
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static string ImageNameStart = "_";
        string ImageName;
        Image Image1Content = new Image();
        Image Image2Content = new Image();
        BitmapImage defaultImage = new BitmapImage(new Uri("Default.png", UriKind.Relative));
        Button button1;
        Button button2;
        int openedCards = 0;
        Random random = new Random();
        public MainWindow()
        {
            InitializeComponent();
            Image1Content.Source = defaultImage;
            Image2Content.Source = defaultImage;
        }
        public void randomGame(object sender, RoutedEventArgs e)
        {

            List<string> Images = new List<string>()
                {
                    "Morbius(2022).jpg", "1997.png", "DavidHasselhoff.jpg", "Mittwochsfrosch.jpg", "BritishRaj.png", "RedAlert.jpg", "Getoutofmypng.png", "ComicSansMS.PNG",
                    "Morbius(2022).jpg", "1997.png", "DavidHasselhoff.jpg", "Mittwochsfrosch.jpg", "BritishRaj.png", "RedAlert.jpg", "Getoutofmypng.png", "ComicSansMS.PNG"
                };
            foreach (Image image in LabledCanvas.Children)
            {
                Image iconImage = image as Image;
                if (iconImage != null)
                {
                    int randomNumber = random.Next(Images.Count);
                    BitmapImage memoryImage = new BitmapImage(new Uri(Images[randomNumber], UriKind.Relative));
                    iconImage.Source = memoryImage;
                    Images.RemoveAt(randomNumber);
                }
            }
            foreach (Button button in ButtonedCanvas.Children)
            {
                button.Visibility = Visibility.Visible;
            }
        }
        public void OpenCard(object sender, RoutedEventArgs e)
        {
            ImageName = ImageNameStart + (sender as Button).Uid;
            object ImageUnderButton = FindName(ImageName);
            Image ContentGetter = ImageUnderButton as Image;
            Button ButtonOverImage = sender as Button;
            if(openedCards == 0)
            {
                ButtonOverImage.Visibility = Visibility.Hidden;
                Image1Content.Source = ContentGetter.Source;
                button1 = ButtonOverImage;
                openedCards = 1;
            } else if (openedCards == 1)
            {
                ButtonOverImage.Visibility = Visibility.Hidden;
                Image2Content.Source = ContentGetter.Source;
                button2 = ButtonOverImage;
                openedCards = 2;
            } else
            {
                if(Image1Content.Source.ToString() != Image2Content.Source.ToString())
                {
                    Image1Content.Source = defaultImage;
                    Image2Content.Source = defaultImage;
                    button1.Visibility = Visibility.Visible;
                    button2.Visibility = Visibility.Visible;
                    openedCards = 0;
                } else
                {
                    ButtonOverImage.Visibility = Visibility.Hidden;
                    Image1Content.Source = ContentGetter.Source;
                    button1 = ButtonOverImage;
                    openedCards = 1;
                }
            }
        }
    }
}