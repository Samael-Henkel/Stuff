﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace memoryOOP
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Memory memory = new Memory();
        public MainWindow()
        {
            InitializeComponent();
        }
        void OpenCard(object sender, RoutedEventArgs e)
        {
            if(memory.OpenedCards == 0)
            {
                memory.firstCardFront.TheCardFront = sender as Button;
                memory.firstCardFront.Uid = memory.firstCardFront.TheCardFront.Uid;
                memory.firstCardBack.Name = "_" + memory.firstCardFront.Uid;
                Image image = Field.FindName(memory.firstCardBack.Name) as Image;
                memory.firstCardBack.image = new BitmapImage(new Uri(image.Source.ToString(), UriKind.RelativeOrAbsolute));
                memory.OpenedCards = 1;
                memory.firstCardFront.MakeHidden();
            } else if(memory.OpenedCards == 1)
            {
                memory.secondCardFront.TheCardFront = sender as Button;
                memory.secondCardFront.Uid = memory.secondCardFront.TheCardFront.Uid;
                memory.secondCardBack.Name = "_" + memory.secondCardFront.Uid;
                Image image = Field.FindName(memory.secondCardBack.Name) as Image;
                memory.secondCardBack.image = new BitmapImage(new Uri(image.Source.ToString(), UriKind.RelativeOrAbsolute));
                memory.secondCardFront.MakeHidden();
                memory.OpenedCards = 2;
            } else
            {
                memory.CompareImages();
                if (memory.same)
                {
                    memory.firstCardFront.TheCardFront = sender as Button;
                    memory.firstCardFront.Uid = memory.firstCardFront.TheCardFront.Uid;
                    memory.firstCardBack.Name = "_" + memory.firstCardFront.Uid;
                    Image image = Field.FindName(memory.firstCardBack.Name) as Image;
                    memory.firstCardBack.image = new BitmapImage(new Uri(image.Source.ToString(), UriKind.RelativeOrAbsolute));
                    memory.OpenedCards = 1;
                    memory.firstCardFront.MakeHidden();
                }
            }
        }
        void newGame(object sender, RoutedEventArgs e)
        {
            foreach(Image image in FieldOfImages.Children)
            {
                Random random = new Random();
                int randomNumber = random.Next(memory.Images.Count);
                BitmapImage memoryImage = new BitmapImage(new Uri(memory.Images[randomNumber], UriKind.Relative));
                image.Source = memoryImage;
                memory.Images.RemoveAt(randomNumber);
            }
            memory.Images = new List<string>()
                {
                    "Morbius(2022).jpg", "1997.png", "DavidHasselhoff.jpg", "Mittwochsfrosch.jpg", "BritishRaj.png", "RedAlert.jpg", "Getoutofmypng.png", "ComicSansMS.PNG",
                    "Morbius(2022).jpg", "1997.png", "DavidHasselhoff.jpg", "Mittwochsfrosch.jpg", "BritishRaj.png", "RedAlert.jpg", "Getoutofmypng.png", "ComicSansMS.PNG"
                };
            foreach(Button button in FieldOfButtons.Children)
            {
                button.Visibility = Visibility.Visible;
            }
        }
    }
    public class CardFront
    {
        public string Uid = "";
        public Visibility Visibility = Visibility.Visible;
        public Button TheCardFront;
        public void MakeVisible()
        {
            Visibility = Visibility.Visible;
            TheCardFront.Visibility = Visibility.Visible;
        }
        public void MakeHidden()
        {
            Visibility = Visibility.Hidden;
            TheCardFront.Visibility = Visibility.Hidden;
        }
    }
    public class CardBack
    {
        public string Name;
        public BitmapImage image = new BitmapImage(new Uri("Default.png", UriKind.Relative));
    }
    public class Memory
    {
        public CardBack firstCardBack = new CardBack();
        public CardBack secondCardBack = new CardBack();
        public CardFront firstCardFront = new CardFront();
        public CardFront secondCardFront = new CardFront();
        BitmapImage first;
        BitmapImage second;
        public bool same = false;
        public int OpenedCards = 0;
        public List<string> Images = new List<string>()
        {
            "Morbius(2022).jpg", "1997.png", "DavidHasselhoff.jpg", "Mittwochsfrosch.jpg", "BritishRaj.png", "RedAlert.jpg", "Getoutofmypng.png", "ComicSansMS.PNG",
            "Morbius(2022).jpg", "1997.png", "DavidHasselhoff.jpg", "Mittwochsfrosch.jpg", "BritishRaj.png", "RedAlert.jpg", "Getoutofmypng.png", "ComicSansMS.PNG"
        };
        public void CompareImages()
        {
            first = firstCardBack.image;
            second = secondCardBack.image;
            if (first.ToString() != second.ToString())
            {
                firstCardFront.MakeVisible();
                secondCardFront.MakeVisible();
                same = false;
                OpenedCards = 0;
            } else
            {
                same = true;
                OpenedCards = 0;
            }
        }
    }
}