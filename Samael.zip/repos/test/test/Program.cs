﻿using System;
using System.IO;
using System.IO.Compression;

class Program
{
    static void Main(string[] args)
    {
        string initialText = "Hello world!";
        string fileName = "readme.txt";

        // Generate the initial text file
        File.WriteAllText(fileName, initialText);

        // Create the zip bomb
        CreateZipBomb(fileName);

        Console.WriteLine("Zip bomb created successfully.");
    }

    static void CreateZipBomb(string fileName)
    {
        // Depth of recursion for text duplication
        int recursionDepth = 10;

        // Generate exponentially increasing text content
        string textContent = "Hello world!";
        for (int i = 0; i < recursionDepth; i++)
        {
            textContent += textContent;
        }

        // Write the expanded text content to the file
        File.WriteAllText(fileName, textContent);

        // Compress the text file into a zip bomb
        string zipFileName = "README.zip";
        using (FileStream zipFileStream = new FileStream(zipFileName, FileMode.Create))
        {
            using (ZipArchive archive = new ZipArchive(zipFileStream, ZipArchiveMode.Create))
            {
                ZipArchiveEntry entry = archive.CreateEntryFromFile(fileName, Path.GetFileName(fileName));
            }
        }
    }
}