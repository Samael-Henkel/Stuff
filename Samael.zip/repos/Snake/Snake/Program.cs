﻿using System;

namespace Snake
{
    class Program
    {
        static bool foodExists = false;
        static int FoodRow;
        static int FoodColumn;
        static string[,] Field = {
            {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"},
            {"-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"}
        };

        enum Direction
        {
            Up,
            Down,
            Left,
            Right
        }

        static Direction snakeDirection = Direction.Right; // Initial direction
        static List<(int, int)> snakeSegments = new List<(int, int)>(); // List to store snake segments

        static void Main()
        {
            UpdateFood();
            InitializeSnake();
            PrintField();

            while (true)
            {
                Console.Clear(); // Clear the console for smoother animation
                if (Console.KeyAvailable)
                {
                    ConsoleKeyInfo key = Console.ReadKey(intercept: true);
                    HandleInput(key);
                }

                MoveSnake();
                PrintField();
                System.Threading.Thread.Sleep(250); // Adjust the speed of the game
            }
        }
        static void InitializeSnake()
        {
            // Start the snake with a few initial segments
            snakeSegments.Add((7, 7)); // Snake's head
            snakeSegments.Add((7, 6)); // First segment
            snakeSegments.Add((7, 5)); // Second segment
        }

        static void UpdateFood()
        {
            if (!foodExists)
            {
                Random random = new Random();
                bool HasChanged = false;
                while (!HasChanged)
                {
                    int row = random.Next(0, Field.GetLength(0));
                    int col = random.Next(0, Field.GetLength(1));
                    if (Field[row, col] != "S")
                    {
                        FoodRow = row;
                        FoodColumn = col;
                        Field[row, col] = "F";
                        HasChanged = true;
                    }
                }
            }
        }

        static void PrintField()
        {
            int rows = Field.GetLength(0);
            int cols = Field.GetLength(1);

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    // Check if the current position is part of the snake
                    bool isSnakeSegment = false;
                    foreach (var segment in snakeSegments)
                    {
                        if (segment.Item1 == i && segment.Item2 == j)
                        {
                            isSnakeSegment = true;
                            break;
                        }
                    }

                    // Print the appropriate symbol based on whether it's part of the snake or not
                    if (isSnakeSegment)
                    {
                        Console.Write("S ");
                    }
                    else
                    {
                        Console.Write(Field[i, j] + " ");
                    }
                }
                Console.WriteLine();
            }
        }


        static void HandleInput(ConsoleKeyInfo key)
        {
            switch (key.Key)
            {
                case ConsoleKey.UpArrow:
                    if (snakeDirection != Direction.Down)
                        snakeDirection = Direction.Up;
                    break;
                case ConsoleKey.DownArrow:
                    if (snakeDirection != Direction.Up)
                        snakeDirection = Direction.Down;
                    break;
                case ConsoleKey.LeftArrow:
                    if (snakeDirection != Direction.Right)
                        snakeDirection = Direction.Left;
                    break;
                case ConsoleKey.RightArrow:
                    if (snakeDirection != Direction.Left)
                        snakeDirection = Direction.Right;
                    break;
            }
        }

        static void MoveSnake()
        {
            // Move the snake's head based on direction
            int headRow = snakeSegments[0].Item1;
            int headCol = snakeSegments[0].Item2;
            int newHeadRow = headRow;
            int newHeadCol = headCol;

            switch (snakeDirection)
            {
                case Direction.Up:
                    newHeadRow = headRow - 1;
                    break;
                case Direction.Down:
                    newHeadRow = headRow + 1;
                    break;
                case Direction.Left:
                    newHeadCol = headCol - 1;
                    break;
                case Direction.Right:
                    newHeadCol = headCol + 1;
                    break;
            }

            // Check if the new head position is out of bounds (border collision)
            if (newHeadRow < 0 || newHeadRow >= Field.GetLength(0) ||
                newHeadCol < 0 || newHeadCol >= Field.GetLength(1))
            {
                // Snake collided with the border, end the game
                Environment.Exit(0); // Exit the game
            }

            // Check if the new head position collides with the snake's body
            foreach (var segment in snakeSegments.Skip(1)) // Skip the head as it won't collide with itself
            {
                if (newHeadRow == segment.Item1 && newHeadCol == segment.Item2)
                {
                    // Snake collided with itself, end the game
                    Environment.Exit(0); // Exit the game
                }
            }

            // Add the new head position to the beginning of the snakeSegments list
            snakeSegments.Insert(0, (newHeadRow, newHeadCol));

            // Check if the new head position is on the food
            if (newHeadRow == FoodRow && newHeadCol == FoodColumn)
            {
                // The snake ate food, update food position and don't remove the tail segment
                Field[FoodRow, FoodColumn] = "-";
                foodExists = false;
                UpdateFood();
            }
            else
            {
                // Remove the last segment to keep the snake moving forward
                snakeSegments.RemoveAt(snakeSegments.Count - 1);
            }
        }
    }
}