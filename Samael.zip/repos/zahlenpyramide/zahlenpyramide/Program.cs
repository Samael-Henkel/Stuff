﻿using System;
namespace zahlenpyramide
{
    class Program
    {
        static void Main(string[] args)
        {
            int pyramidSize = 0;
            bool Cont = true;
            while (Cont)
            {
                bool IsNumber = false;
                while (!IsNumber)
                {
                    Console.WriteLine("How tall should the pyramid be?");
                    string inputSize = Console.ReadLine();
                    try
                    {
                        pyramidSize = int.Parse(inputSize);
                        IsNumber = true;
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("Thats not a number!");
                    }
                }
                int updateSize = pyramidSize;
                for (int i = 0; i < pyramidSize; i++)
                {
                    for (int j = 0; j < updateSize; j++)
                    {
                        Console.Write(" ");
                    }
                    for (int k = 0; k < i + 1; k++)
                    {
                        Console.Write(i + 1 + " ");
                    }
                    updateSize -= 1;

                    Console.WriteLine();
                }
            }
        }
    }
}