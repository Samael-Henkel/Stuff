﻿using System.Text;

namespace GrundlagenCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            char[] letters;
            bool exit = false;
            while (!exit)
            {
                Console.WriteLine("Welche Aufgabe möchten Sie durchführen?");
                string Answer = Console.ReadLine();
                switch (Answer.ToLower())
                {
                    case "aufgabe 1":
                    case "aufgabe1":
                    case "1":
                        letters = Task1();
                        WriteOut(letters);
                        break;

                    case "aufgabe 2":
                    case "aufgabe2":
                    case "2":
                        letters = Task2();
                        WriteOut(letters);
                        break;
                    case "aufgabe 3":
                    case "aufgabe3":
                    case "3":
                        int length = Task3();
                        Console.WriteLine(length.ToString());
                        break;
                    case "aufgabe 4":
                    case "aufgabe4":
                    case "4":
                        Task4();
                        break;
                    case "aufgabe 5":
                    case "aufgabe5":
                    case "5":
                        bool Palindrome = Task5();
                        if (Palindrome)
                        {
                            Console.WriteLine("Ist ein Palindrom.");
                        } 
                        else
                        {
                            Console.WriteLine("Ist kein Palindrom.");
                        }
                        break;
                    case "exit":
                    case "quit":
                    case "stop":
                        exit = true;
                        break;
                }
            }
        }
        static char[] Task1()
        {
            Console.Write("Dieser Satz wird in seine Buchstaben aufgeteilt:");
            string Sentence = Console.ReadLine();
            string[] words = Sentence.Split(" ");
            StringBuilder sb = new StringBuilder("", Sentence.Length);
            for (int i = 0; i < words.Length; i++)
            {
                sb.Append(words[i]);
            }
            string newSentence = sb.ToString();
            char[] letters = newSentence.ToCharArray();
            return letters;
        }
        static char[] Task2()
        {
            char[] letters = Task1();
            Array.Reverse(letters);
            return letters;
        }
        static int Task3()
        {
            char[] letters = Task1();
            return letters.Length;
        }
        static void Task4()
        {
            Console.Write("Dieser Satz wird in Grossbuchstaben formatiert:");
            string Sentence = Console.ReadLine();
            Console.WriteLine(Sentence.ToUpper());
        }
        static bool Task5()
        {
            Console.Write("Dieser Satz wird auf Palindromheit getestet (Keine Satzzeichen):");
            string Sentence = Console.ReadLine().ToLower();
            string[] Words = Sentence.Split(" ");
            StringBuilder sb = new StringBuilder("", Sentence.Length);
            for (int i = 0; i < Words.Length; i++)
            {
                sb.Append(Words[i]);
            }
            string SplssSentence = sb.ToString(); //Splss = Spaceless
            char[] CharacterArray = SplssSentence.ToCharArray();
            Array.Reverse(CharacterArray);
            string RevSplssSentence = new string(CharacterArray);
            if (SplssSentence == RevSplssSentence)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        static void WriteOut(char[] List)
        {
            for (int i = 0; i < List.Length; i++)
            {
                Console.WriteLine(List[i]);
            }
        }
    }
}