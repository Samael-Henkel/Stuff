﻿namespace OOP
{
    class Kamel
    {
        private string Name;
        private int Ausdauer;
        private int UrspruenglicheAusdauer;
        private int Lastkraft;
        private int UrspruenglicheLastkraft;
        private void PauseMachen()
        {
            Lastkraft = 0;
            while (Ausdauer < UrspruenglicheAusdauer)
            {
                Thread.Sleep(100);
                Ausdauer += 1;
            }
            Lastkraft = UrspruenglicheLastkraft;
        }
    }
    class KarwanBaschi
    {
        private string Name;
        private string Herkunft;
        private int Loyalitaet;
        //Keine passenden Methoden für direkt in diese Klasse gefunden
    }
    class Karawan
    {
        private string Gueter;
        private string Herkunft;
        private string Zielort;
        private KarwanBaschi karwanBaschi;
        private Kamel[] Kamele;
        //Keine passenden Methoden für direkt in diese Klasse gefunden
    }
    class Scheich
    {
        private string Name;
        private string Herkunft;
        private int Geld;
        private Karawan[] karawane;
        //Keine passenden Methoden für direkt in diese Klasse gefunden
    }
}