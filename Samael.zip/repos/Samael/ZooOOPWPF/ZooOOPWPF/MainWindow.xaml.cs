﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ZooOOPWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private int gridCount = 0;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddButtonToGrid(Grid grid)
        {
            Button button = new Button();
            button.Content = "Button " + (grid.Children.Count + 1);
            grid.Children.Add(button);
        }

        private void AddGrid_Click(object sender, RoutedEventArgs e)
        {
            Grid newGrid = new Grid();
            newGrid.Margin = new Thickness(300 * (gridCount - 1), 0, 610 - (300 * (gridCount - 1)), 0);
            newGrid.Height = 255;
            newGrid.Width = 150;
            newGrid.Background = Brushes.LightGray;
            Grid.SetColumn(newGrid, gridCount); // Set column to align grids horizontally
            gridCount++;
            AddButtonToGrid(newGrid); // Add button to the newly created grid
            // Add the new grid to the parent stack panel
            Grids.Children.Insert(gridCount - 1, newGrid);
        }
    }
    // Basisklasse für Tiere
    public abstract class Tier
    {
        public string Name { get; set; }
        public abstract string Art { get; }
        public abstract string Gattung { get; }
        public abstract string Ernährung { get; }
        public abstract string Fortpflanzung { get; }

        public virtual string SagWasDuBist()
        {
            return ($"Ich bin ein {Art} aus der Gattung {Gattung}.");
        }

        public virtual string SagWieDuIsst()
        {
            return ($"Ich ernähre mich durch {Ernährung}.");
        }

        public virtual string SagWieDuDichFortpflanzt()
        {
            return ($"Ich pflanze mich fort durch {Fortpflanzung}.");
        }
    }

    // Säugetierklasse
    public class Säugetier : Tier
    {
        public override string Art => "Säugetier";
        public override string Gattung { get; }
        public override string Ernährung { get; }
        public override string Fortpflanzung { get; }

        public Säugetier(string gattung, string ernährung, string fortpflanzung)
        {
            Gattung = gattung;
            Ernährung = ernährung;
            Fortpflanzung = fortpflanzung;
        }
    }

    // Fischklasse
    public class Fisch : Tier
    {
        public override string Art => "Fisch";
        public override string Gattung { get; }
        public override string Ernährung { get; }
        public override string Fortpflanzung { get; }

        public Fisch(string gattung, string ernährung, string fortpflanzung)
        {
            Gattung = gattung;
            Ernährung = ernährung;
            Fortpflanzung = fortpflanzung;
        }
    }

    // Gehegeklasse
    public class Gehege
    {
        private List<Tier> tiere = new List<Tier>();

        public void TierHinzufügen(Tier tier)
        {
            tiere.Add(tier);
            Console.WriteLine($"{tier.Name} wurde dem Gehege hinzugefügt.");
        }

        public int AnzahlDerTiere()
        {
            return tiere.Count;
        }

        public int AnzahlDerTiereArt(string art)
        {
            return tiere.FindAll(t => t.Art.Equals(art, StringComparison.OrdinalIgnoreCase)).Count;
        }

        public void GrundzustandZurücksetzen()
        {
            tiere.Clear();
            Console.WriteLine("Das Gehege wurde zurückgesetzt.");
        }
    }

    // Zoo-Klasse
    public class Zoo
    {
        private List<Gehege> gehegeListe = new List<Gehege>();

        public void GehegeErstellen()
        {
            Gehege gehege = new Gehege();
            gehegeListe.Add(gehege);
            Console.WriteLine("Ein neues Gehege wurde erstellt.");
        }

        public void TierGeboren(Tier tier, int gehegeIndex)
        {
            if (gehegeIndex >= 0 && gehegeIndex < gehegeListe.Count)
            {
                gehegeListe[gehegeIndex].TierHinzufügen(tier);
            }
            else
            {
                Console.WriteLine("Ungültiger Gehegeindex.");
            }
        }

        public int AnzahlDerGehege()
        {
            return gehegeListe.Count;
        }

        public int AnzahlDerTiereInZoo()
        {
            int count = 0;
            foreach (var gehege in gehegeListe)
            {
                count += gehege.AnzahlDerTiere();
            }
            return count;
        }

        public int AnzahlDerTiereArtInZoo(string art)
        {
            int count = 0;
            foreach (var gehege in gehegeListe)
            {
                count += gehege.AnzahlDerTiereArt(art);
            }
            return count;
        }

        public void GrundzustandZurücksetzen()
        {
            gehegeListe.Clear();
            Console.WriteLine("Der Zoo wurde zurückgesetzt.");
        }
    }
}
