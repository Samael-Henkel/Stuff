﻿namespace TicTacToe
{
    /// <summary>
    /// 
    /// </summary>
    class Program
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            bool ContinuePlaying = true;
            bool WorkingInput;
            while (ContinuePlaying)
            {
                TicTacToe();
                WorkingInput = false;
                while (!WorkingInput)
                {
                    Console.WriteLine("Play Again?");
                    string Input = Console.ReadLine();
                    switch (Input.ToLower())
                    {
                        case "y":
                        case "yes":
                            WorkingInput = true;
                            break;
                        case "n":
                        case "no":
                            WorkingInput = true;
                            ContinuePlaying = false;
                            break;
                        default:
                            Console.WriteLine("y/n");
                            break;
                    }

                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        static void TicTacToe()
        {
            string[,] GameField = { { "1", "2", "3" }, { "4", "5", "6" }, { "7", "8", "9" } };
            string[] PlayerSymbols = { "X", "O" };
            int CurrentPlayer = 0;
            bool GameOver = false;

            while (!GameOver)
            {
                DisplayField(GameField);
                bool ValidPlay = false;
                while (!ValidPlay)
                {
                    Console.WriteLine($"Player {PlayerSymbols[CurrentPlayer]}'s turn. Enter a position (1-9):");
                    string Pos = Console.ReadLine();

                    // Check if the input is a valid integer between 1 and 9
                    if (int.TryParse(Pos, out int position) && position >= 1 && position <= 9)
                    {
                        // Convert the position to row and column indices
                        int row = (position - 1) / 3;
                        int col = (position - 1) % 3;

                        // Check if the selected spot is already taken
                        if (IsValidPlay(GameField[row, col], PlayerSymbols))
                        {
                            // Is a valid Play
                            ValidPlay = true;
                            // Place the current player's symbol on the selected spot
                            GameField[row, col] = PlayerSymbols[CurrentPlayer];

                            // Check for a win or draw condition
                            if (CheckWin(GameField, PlayerSymbols[CurrentPlayer]))
                            {
                                DisplayField(GameField);
                                Console.WriteLine($"Player {PlayerSymbols[CurrentPlayer]} wins!");
                                GameOver = true;
                            }
                            else if (IsDraw(GameField))
                            {
                                DisplayField(GameField);
                                Console.WriteLine("It's a draw!");
                                GameOver = true;
                            }
                            else
                            {
                                // Switch to the next player
                                CurrentPlayer = (CurrentPlayer + 1) % 2;
                            }
                        }
                        else
                        {
                            Console.WriteLine("That spot is already taken. Try again.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input. Enter a number between 1 and 9.");
                    }
                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="SelectedSpace"></param>
        /// <param name="PlayerSymbols"></param>
        /// <returns></returns>
        static bool IsValidPlay(string SelectedSpace, string[] PlayerSymbols)
        {
            for (int i = 0; i < PlayerSymbols.Length; i++)
            {
                if (SelectedSpace == PlayerSymbols[i])
                {
                    return false;
                }
            }
            return true;
        }
        /// <summary>
        /// Checks rows, columns, and diagonals for a win
        /// </summary>
        /// <param name="GameField"></param>
        /// <param name="symbol"></param>
        /// <returns></returns>
        static bool CheckWin(string[,] GameField, string symbol)
        {
            for (int i = 0; i < 3; i++)
            {
                if ((GameField[i, 0] == symbol && GameField[i, 1] == symbol && GameField[i, 2] == symbol) ||
                    (GameField[0, i] == symbol && GameField[1, i] == symbol && GameField[2, i] == symbol))
                {
                    return true;
                }
            }

            if ((GameField[0, 0] == symbol && GameField[1, 1] == symbol && GameField[2, 2] == symbol) ||
                (GameField[0, 2] == symbol && GameField[1, 1] == symbol && GameField[2, 0] == symbol))
            {
                return true;
            }

            return false;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="GameField"></param>
        /// <returns></returns>
        static bool IsDraw(string[,] GameField)
        {
            // Check if all spots on the board are filled
            foreach (string spot in GameField)
            {
                if (spot != "X" && spot != "O")
                {
                    return false;
                }
            }
            return true;
        }
        static void DisplayField(string[,] GameField)
        {
            Console.Clear(); // Clear the console to refresh the display

            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    Console.Write(GameField[row, col]);

                    // Add a separator between columns
                    if (col < 2)
                    {
                        Console.Write(" | ");
                    }
                }

                Console.WriteLine(); // Move to the next row

                // Add a separator between rows
                if (row < 2)
                {
                    Console.WriteLine("---------");
                }
            }
        }
    }
}
