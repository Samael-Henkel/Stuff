﻿using Player;
using System.Security.Cryptography;

namespace Projektarbeit
{
    class Program
    {
        static PlayerCharacter player;
        static string location;
        static int TaxesDone = 0;
        static int BeetlesKilled = 0;
        static int U235Amount = 0;
        static int NothingAmount = 0;
        static Random rng = new Random();
        static void Main(string[] args)
        {
            bool continuePlaying = true;

            while (continuePlaying)
            {
                PlayGame(); 
                TaxesDone = 0;
                BeetlesKilled = 0;
                U235Amount = 0;
                NothingAmount = 0; 
                player.MaxHP = 20;
                player.Level = 1;
                player.atk = 5;
                player.def = 5;
                player.Experience = 0;
                player.NextLevel = 100;
                Console.WriteLine("Play Again? (y/n)");
                string input = Console.ReadLine().ToLower();

                while (input != "y" && input != "n" && input != "yes" && input != "no")
                {
                    Console.WriteLine("Invalid input. Please enter y/n.");
                    input = Console.ReadLine().ToLower();
                }

                if (input == "n" || input == "no")
                {
                    continuePlaying = false;
                }

                Console.Clear();
            }
        }

        static void PlayGame()
        {
            player = new PlayerCharacter();
            location = "home";

            while (player.HP > 0)
            {
                DisplayLocation(location);
                Console.WriteLine("What will you do? (go [inside/away/to hell], look [around/down/up], search for [item/fight/U-235], check stats)");
                string action = Console.ReadLine();
                PerformAction(action, player);
            }
            Console.WriteLine("Game Over");
        }

        static void DisplayLocation(string location)
        {
            switch (location)
            {
                case "home":
                    Console.WriteLine("You're in front of your Home");
                    break;
                case "hell":
                    Console.WriteLine("You're in hell.");
                    break;
                case "inside":
                    Console.WriteLine("You're inside your house.");
                    break;
                case "away":
                    Console.WriteLine("You're away from your house.");
                    break;
            }
        }
        static void PerformAction(string action, PlayerCharacter player)
        {
            Console.Clear();
            switch (action.ToLower())
            {
                case "go inside":
                    if (location == "home")
                    {
                        Console.WriteLine("You went inside.");
                        location = "inside";
                    } else if (location == "inside")
                    {
                        Console.WriteLine("You tried to go inside, but ended up going outside instead.");
                        location = "home";
                    } else if (location == "hell")
                    {
                        Console.WriteLine("You're stuck in hell and you can't leave.");
                    } else
                    {
                        Console.WriteLine("There's nothing to enter.");
                    }
                    break;
                case "go away":
                    if (location == "home")
                    {
                        Console.WriteLine("You went away.");
                        location = "away";
                    }
                    else if (location == "away")
                    {
                        Console.WriteLine("You went away from away, returning home.");
                        location = "home";
                    }
                    else if (location == "hell")
                    {
                        Console.WriteLine("You're stuck in hell and you can't leave.");
                    }
                    else if (location == "inside")
                    {
                        if (player.HP > 10)
                        {
                            Console.WriteLine("You walked against a wall. That hurt!");
                            player.HP -= 1;
                        } else
                        {
                            Console.WriteLine("You walked against a wall...and feel better, somehow...");
                            player.HP = player.MaxHP;
                        }
                    } 
                    else
                    {
                        Console.WriteLine("There's nowhere to go.");
                    }
                    break;
                case "go to hell":
                    Console.WriteLine("You went to hell. It's getting hot in here!");
                    location = "hell";
                    break;
                case "look around":
                    Console.WriteLine("You look around. Nothing unusual.");
                    break;
                case "look down":
                    Console.WriteLine("You look down. You see the ground.");
                    break;
                case "look up":
                    Console.WriteLine("You look up. The sky is clear.");
                    break;
                case "search for item":
                    Console.WriteLine("You search for an item. You found nothing.");
                    NothingAmount += 1;
                    break;
                case "search for fight":
                    Console.WriteLine("You found a fight!");
                    CombatLogic();
                    break;
                case "search for u-235":
                case "search for u235":
                    Console.WriteLine("You search for U-235. You find a radioactive material.");
                    U235Amount += 1;
                    if (U235Amount >= 10)
                    {
                        player.HP = 1;
                        player.MaxHP = 1;
                        U235Amount = 0;
                        Console.WriteLine("The amount of U-235 reached critical amounts. Your Maximum HP has been reduced to 1 permanently.");
                    }
                    break;
                case "check stats":
                    StatCheck();
                    break;
                default:
                    Console.WriteLine("Invalid action. Try again.");
                    break;
            }
        }
        static void StatCheck()
        {
            Console.WriteLine("Player HP:        " + player.HP + "/" + player.MaxHP);
            Console.WriteLine("Player Attack:    " + player.atk);
            Console.WriteLine("Player Defense:   " + player.def);
            Console.WriteLine("Player Level:     " + player.Level);
            Console.WriteLine("Player Experience:" + player.Experience);
            Console.WriteLine("Next Level in:    " + (player.NextLevel - player.Experience));
            if (BeetlesKilled < 20)
            {
                Console.WriteLine("Beetles Killed:   " + BeetlesKilled + "/20");
            } else
            {
                Console.WriteLine("Beetles Killed:   Too many, according to God");
            }
            Console.WriteLine("Taxes done:       " + TaxesDone);
            Console.WriteLine("Amount of Nothing:" + NothingAmount);
            Console.WriteLine("Amount of U-235:  " + U235Amount + "/10");
        }
        static void CombatLogic()
        {
            bool PlayerTurn = true;
            int HPenemy;
            int atkenemy;
            int defenemy;
            string EnemyName;
            int tempDef = 0;
            switch (location)
            {
                case "hell":
                    EnemyName = "Lucifer";
                    HPenemy = 666;
                    atkenemy = 666;
                    defenemy = 666;
                    break;
                case "inside":
                    EnemyName = "Taxes";
                    HPenemy = 501;
                    atkenemy = 1 + TaxesDone;
                    defenemy = 3 + TaxesDone;
                    break;
                case "home":
                    int RandomEncounter = rng.Next(1 + BeetlesKilled, 20 + BeetlesKilled);
                    if (RandomEncounter <= 20)
                    {
                        EnemyName = "Random Beetle";
                        HPenemy = 1;
                        atkenemy = 1;
                        defenemy = 1;
                    }
                    else
                    {
                        EnemyName = "God";
                        HPenemy = 888 * player.Level;
                        atkenemy = 888 * player.Level;
                        defenemy = 888 * player.Level;
                    }
                    break;
                case "away":
                    EnemyName = "Stranger";
                    HPenemy = 20;
                    atkenemy = 5;
                    defenemy = 5;
                    break;
                default:
                    EnemyName = "Enemy";
                    HPenemy = 10;
                    atkenemy = 5;
                    defenemy = 5;
                    break;
            }
            while (HPenemy > 0 && player.HP > 0)
            {
                Console.WriteLine($"{EnemyName} blocks your path.");
                while (PlayerTurn == true)
                {
                    Console.WriteLine($"What will you do? [atk, item, def]");
                    string Action = Console.ReadLine();
                    switch (Action.ToLower())
                    {
                        case "def":
                        case "defend":
                        case "defending":
                            Console.WriteLine("You defended. +5 Defense for this turn.");
                            tempDef += 5;
                            PlayerTurn = false;
                            break;
                        case "item":
                        case "use":
                        case "use item":
                            Console.WriteLine("What Item do you use?");
                            Action = Console.ReadLine();
                            if (Action.ToLower() == "nothing" && NothingAmount > 0)
                            {
                                NothingAmount -= 1;
                                switch (rng.Next(1, 10))
                                {
                                    case 1:
                                    case 2:
                                    case 3:
                                    case 4:
                                    case 5:
                                        Console.WriteLine("Nothing happened.");
                                        break;
                                    case 6:
                                        Console.WriteLine("Quantum fluctuations caused you to experience healing. HP maxxed out.");
                                        player.HP = player.MaxHP;
                                        break;
                                    case 7:
                                        Console.WriteLine("You glitched out the Nothing. It corrupted your stats, so you reset them.");
                                        player.MaxHP = 20;
                                        player.Level = 1;
                                        player.atk = 5;
                                        player.def = 5;
                                        player.NextLevel = 100;
                                        break;
                                    case 8:
                                        Console.WriteLine("You glitched out the Nothing. Now you just pulled your enemy out of your pocket. You throw him away.");
                                        double NewHP = HPenemy / 2;
                                        HPenemy = Convert.ToInt16(Math.Round(NewHP));
                                        break;
                                    case 9:
                                        Console.WriteLine("You glitched out the Nothing. Now you have one additional Nothing.");
                                        NothingAmount += 2;
                                        break;
                                    default:
                                        Console.WriteLine("No thing happened.");
                                        break;
                                }
                                PlayerTurn = false;
                            }
                            else if ((Action.ToLower() == "u-235" || Action.ToLower() == "u235") && U235Amount > 0)
                            {
                                Console.WriteLine("You started the nuclear fission proceedure...");
                                player.HP = 1;
                                if (EnemyName != "God" && EnemyName != "Lucifer")
                                {
                                    HPenemy = 0;
                                }
                                else
                                {
                                    HPenemy = HPenemy / 2;
                                }
                                Console.WriteLine("Turns out that stuff bombs.");
                                U235Amount -= 1;
                                NothingAmount += 1;
                                PlayerTurn = false;
                            }
                            else Console.WriteLine("That's not a Item.");
                            break;
                        case "atk":
                        case "attack":
                        case "attacking":
                            int enemydefchance = rng.Next(0, defenemy);
                            int playeratkchance = rng.Next(0, player.atk);
                            if (playeratkchance >= enemydefchance)
                            {
                                Console.WriteLine("Your Attack dealt " + (playeratkchance - enemydefchance + 1) + " damage.");
                                HPenemy -= (playeratkchance - enemydefchance + 1);
                            }
                            else
                            {
                                Console.WriteLine("Miss!");
                            }
                            PlayerTurn = false;
                            break;
                        default:
                            Console.WriteLine("Invalid Action!");
                            break;
                    }
                }
                if (HPenemy > 0)
                {
                    int enemyatkchance = rng.Next(0, atkenemy);
                    int playerdefchance = rng.Next(0, player.def += tempDef);
                    tempDef = 0;
                    PlayerTurn = true;
                    if (enemyatkchance >= playerdefchance)
                    {
                        player.HP -= (enemyatkchance - playerdefchance + 1);
                        Console.WriteLine(EnemyName + " dealt " + (enemyatkchance - playerdefchance + 1) + " damage.");
                    }
                    else
                    {
                        Console.WriteLine(EnemyName + " missed.");
                    }
                }
            }
            if (HPenemy <= 0)
            {
                Console.WriteLine("You won!");
                player.Experience += (defenemy + atkenemy);
                Console.WriteLine("Gained " + (defenemy + atkenemy) + " experience");
                if (location == "hell")
                {
                    location = "home";
                    Console.WriteLine("Escaped Hell.");
                }
                if (EnemyName == "Random Beetle") 
                {
                    BeetlesKilled += 1;
                }
                else if (EnemyName == "Taxes")
                {
                    TaxesDone += 1;
                }
                else if (EnemyName == "God")
                {
                    BeetlesKilled = 20;
                }
                int LevelsGained = 0;
                while (player.Experience >= player.NextLevel)
                {
                    LevelsGained++;
                    player.Level++;
                    player.Experience -= player.NextLevel;
                    player.NextLevel += Convert.ToInt32(Math.Floor(player.NextLevel * 0.2));
                    player.atk += Convert.ToInt32(Math.Floor(player.atk * 0.2));
                    player.def += Convert.ToInt32(Math.Floor(player.def * 0.2));
                    player.MaxHP += Convert.ToInt32(Math.Floor(player.MaxHP * 0.2));
                    player.HP = player.MaxHP;
                }
                Console.WriteLine($"Gained " + LevelsGained + " levels");
            }
        }
    }
}
