namespace Player
{
    public class PlayerCharacter
    {
        public int HP { get; set; } = 20;
        public int MaxHP { get; set; } = 20;
        public int Level { get; set; } = 1;
        public int atk { get; set; } = 5;
        public int def { get; set; } = 5;
        public int Experience { get; set; } = 0;
        public int NextLevel { get; set; } = 100;
    }
}