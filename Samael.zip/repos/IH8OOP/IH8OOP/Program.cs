﻿namespace IH8OOP
{
    // Zeug, dass in jedes Programm gehört.
    class Program
    {
        static void Main()
        {
            Dog myDog = new Dog("IH8OOP");
            Console.WriteLine($"Name des Hundes: {myDog.Name}");
            myDog.MakeSound();
        }
    }
    // Sünden
    public class Animal
    {
        public string Name { get; set; }

        public Animal(string name)
        {
            Name = name;
        }

        public virtual void MakeSound()
        {
            Console.WriteLine("Ein Tier macht ein Geräusch.");
        }
    }
    
    public class Dog : Animal
    {
        public Dog(string name) : base(name) { }

        public override void MakeSound()
        {
            Console.WriteLine("Ein Hund bellt.");
        }
    }
}