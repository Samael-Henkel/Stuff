﻿using System;
namespace zahlenpyramideUmgekehrt
{
    class Program
    {
        static void Main(string[] args)
        {
            int pyramidSize = 0;
            bool Cont = true;
            while (Cont)
            {
                bool IsNumber = false;
                while (!IsNumber)
                {
                    Console.WriteLine("How tall should the pyramid be?");
                    string inputSize = Console.ReadLine();
                    try
                    {
                        pyramidSize = int.Parse(inputSize);
                        IsNumber = true;
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("That's not a number!");
                    }
                }

                for (int i = pyramidSize; i >= 1; i--)
                {
                    // Print spaces before the numbers
                    for (int j = 0; j < pyramidSize - i; j++)
                    {
                        Console.Write(" ");
                    }

                    // Print numbers
                    for (int j = 1; j <= 2 * i - 1; j++)
                    {
                        Console.Write("*");
                    }

                    // Move to the next line
                    Console.WriteLine();
                }
            }
        }
    }
}