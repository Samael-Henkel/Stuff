﻿using System;

namespace RaumschiffOOP
{
    class Raumschiff
    {
        private readonly int MinBesatzung;
        private readonly int MaxBesatzung;
        private readonly int MaxTreibstoff;
        private readonly int MaxLadekapazitaet;
        private readonly int MaxGeschwindigkeit;
        public int Treibstoffstand;
        public int LetzteRevision;
        public int NaechsteRevision;
        public int Lademenge = 0;
        public int aktuelleBesatzung;
        public int DistanzZurückgelegt = 0;
        public Raumschiff(int MindestBesatzung, int MaximalBesatzung, int MaximalTank, int MaximalLadekapazitaet)
        {
            MinBesatzung = MindestBesatzung;
            MaxBesatzung = MaximalBesatzung;
            MaxTreibstoff = MaximalTank;
            MaxLadekapazitaet = MaximalLadekapazitaet;
        }
        public bool Fliegen(int Distanz, int Geschwindigkeit)
        {
            if (IstGenugTreibstoff(Distanz, Geschwindigkeit) && NaechsteRevision > DistanzZurückgelegt && aktuelleBesatzung > MinBesatzung)
            {
                Treibstoffstand -= BerechneTreibstoffBedarf(Distanz, Geschwindigkeit);
                DistanzZurückgelegt += Distanz;
                return true;
            }
            return false;
        }
        private bool IstGenugTreibstoff(int Distanz, int Geschwindigkeit)
        {
            if (Treibstoffstand >= BerechneTreibstoffBedarf(Distanz, Geschwindigkeit))
            {
                return true;
            }
            return false;
        }
        public bool Tanken(int Tankmenge)
        {
            if(Treibstoffstand + Tankmenge <= MaxTreibstoff)
            {
                Treibstoffstand += Tankmenge;
                return true;
            }
            return false;
        }
        public void Revidieren()
        {
            LetzteRevision = DistanzZurückgelegt;
            NaechsteRevision = NaechsteRevision += 100000000;
        }
        private int BerechneTreibstoffBedarf(int Distanz, int Geschwindigkeit)
        {
            return (Geschwindigkeit / 1000 / 3) + (2 / 3) *(Distanz / Geschwindigkeit);
        }
    }
}