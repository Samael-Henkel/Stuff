﻿namespace ZooOOPConsole
{
    class Program
    {
        static string Input = "";
        static Zoo zoo = new Zoo();
        static bool Running = true;
        static int CageSelected;
        static void Main(string[] args)
        {
            while (Running)
            {
                Console.WriteLine("Zoo OOP in Console");
                Console.WriteLine("Enter Command");
                Input = Console.ReadLine();
                switch (Input)
                {
                    case "select cage":
                        Console.WriteLine("Enter cage index");
                        Input = Console.ReadLine();
                        if (Convert.ToInt32(Input) >= zoo.AnzahlDerGehege())
                        {
                            Console.Clear();
                            Console.WriteLine("Invalid cage index");
                        }
                        else
                        {
                            Console.WriteLine("Cage " + Input + ":");
                            for (int i = 0; i < zoo.gehegeListe[Convert.ToInt32(Input)].AnzahlDerTiere(); i++)
                            {
                                CageSelected = Convert.ToInt32(Input);
                                Console.WriteLine("Animal: " + (i + 1));
                                zoo.gehegeListe[Convert.ToInt32(Input)].tiere[i].SagWasDuBist();
                                zoo.gehegeListe[Convert.ToInt32(Input)].tiere[i].SagWieDuIsst();
                                zoo.gehegeListe[Convert.ToInt32(Input)].tiere[i].SagWieDuDichFortpflanzt();
                            }
                        }
                        break;
                    case "select animal":
                        if (CageSelected != null)
                        {
                            Console.WriteLine("Enter animal index");
                            Input = Console.ReadLine();
                            Console.WriteLine("Animal " + (Convert.ToInt32(Input) + 1) + ":");
                            zoo.gehegeListe[CageSelected].tiere[Convert.ToInt32(Input)].SagWasDuBist();
                            zoo.gehegeListe[CageSelected].tiere[Convert.ToInt32(Input)].SagWieDuIsst();
                            zoo.gehegeListe[CageSelected].tiere[Convert.ToInt32(Input)].SagWieDuDichFortpflanzt();

                        }
                        break;
                    case "new cage":
                        Console.Clear();
                        zoo.GehegeErstellen();
                        Console.WriteLine("Created new cage");
                        break;
                    case "new fish":
                        Console.WriteLine("Enter cage index");
                        Input = Console.ReadLine();
                        if (Convert.ToInt32(Input) >= zoo.AnzahlDerGehege())
                        {
                            Console.Clear();
                            Console.WriteLine("Invalid cage index");
                        }
                        else
                        {
                            Console.Clear();
                            zoo.TierGeboren(new Fisch("Fisch", "Pflanzliche Ernährung", "Laichung"), Convert.ToInt32(Input));
                        }
                        break;
                    case "new mammal":
                        Console.WriteLine("Enter cage index");
                        Input = Console.ReadLine();
                        if (Convert.ToInt32(Input) >= zoo.AnzahlDerGehege())
                        {
                            Console.Clear();
                            Console.WriteLine("Invalid cage index");
                        }
                        else
                        {
                            Console.Clear();
                            zoo.TierGeboren(new Säugetier("Säugetier", "Fleischhaltige Ernährung", "Lebendgeburt"), Convert.ToInt32(Input));
                        }
                        break;
                    case "exit":
                        Running = false;
                        break;
                }
            }
        }
    }
    public abstract class Tier
    {
        public string Name { get; set; }
        public abstract string Art { get; }
        public abstract string Gattung { get; }
        public abstract string Ernährung { get; }
        public abstract string Fortpflanzung { get; }

        public virtual void SagWasDuBist()
        {
            Console.WriteLine($"Ich bin ein {Art} aus der Gattung {Gattung}.");
        }

        public virtual void SagWieDuIsst()
        {
            Console.WriteLine($"Ich ernähre mich durch {Ernährung}.");
        }

        public virtual void SagWieDuDichFortpflanzt()
        {
            Console.WriteLine($"Ich pflanze mich fort durch {Fortpflanzung}.");
        }
    }

    // Säugetierklasse
    public class Säugetier : Tier
    {
        public override string Art => "Säugetier";
        public override string Gattung { get; }
        public override string Ernährung { get; }
        public override string Fortpflanzung { get; }

        public Säugetier(string gattung, string ernährung, string fortpflanzung)
        {
            Gattung = gattung;
            Ernährung = ernährung;
            Fortpflanzung = fortpflanzung;
        }
    }

    // Fischklasse
    public class Fisch : Tier
    {
        public override string Art => "Fisch";
        public override string Gattung { get; }
        public override string Ernährung { get; }
        public override string Fortpflanzung { get; }

        public Fisch(string gattung, string ernährung, string fortpflanzung)
        {
            Gattung = gattung;
            Ernährung = ernährung;
            Fortpflanzung = fortpflanzung;
        }
    }

    // Gehegeklasse
    public class Gehege
    {
        public List<Tier> tiere = new List<Tier>();

        public void TierHinzufügen(Tier tier)
        {
            tiere.Add(tier);
        }

        public int AnzahlDerTiere()
        {
            return tiere.Count;
        }

        public int AnzahlDerTiereArt(string art)
        {
            return tiere.FindAll(t => t.Art.Equals(art, StringComparison.OrdinalIgnoreCase)).Count;
        }

        public void GrundzustandZurücksetzen()
        {
            tiere.Clear();
        }
    }

    // Zoo-Klasse
    public class Zoo
    {
        public List<Gehege> gehegeListe = new List<Gehege>();

        public void GehegeErstellen()
        {
            Gehege gehege = new Gehege();
            gehegeListe.Add(gehege);
        }

        public void TierGeboren(Tier tier, int gehegeIndex)
        {
            if (gehegeIndex >= 0 && gehegeIndex < gehegeListe.Count)
            {
                gehegeListe[gehegeIndex].TierHinzufügen(tier);
            }
            else
            {
                Console.WriteLine("Ungültiger Gehegeindex.");
            }
        }

        public int AnzahlDerGehege()
        {
            return gehegeListe.Count;
        }

        public int AnzahlDerTiereInZoo()
        {
            int count = 0;
            foreach (var gehege in gehegeListe)
            {
                count += gehege.AnzahlDerTiere();
            }
            return count;
        }

        public int AnzahlDerTiereArtInZoo(string art)
        {
            int count = 0;
            foreach (var gehege in gehegeListe)
            {
                count += gehege.AnzahlDerTiereArt(art);
            }
            return count;
        }

        public void GrundzustandZurücksetzen()
        {
            gehegeListe.Clear();
        }
    }
}