﻿using System;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            bool ContinuePlaying = true;
            bool WorkingInput;
            while (ContinuePlaying)
            {
                Hangman();
                WorkingInput = false;
                while (!WorkingInput)
                {
                    Console.WriteLine("Play Again?");
                    string Input = Console.ReadLine();
                    switch (Input.ToLower())
                    {
                        case "y":
                        case "yes":
                            WorkingInput = true;
                            break;
                        case "n":
                        case "no":
                            WorkingInput = true;
                            ContinuePlaying = false;
                            break;
                        default:
                            Console.WriteLine("y/n");
                            break;
                    }

                }
            }
        }
        static void Hangman()
        {
            string[] words = { "apple", "microsoft", "python", "csharp", "amogus", "ralsei", "nuclear", "jazz", "tram", "llanfairpwllgwyngyllgogerychwyrndrobwllllantysiliogogogoch", "xkcd", "bagels", "systemthirtytwo", "windowsxp", "password", "informatik", "samaelhenkel"}; // Word list
            string wordToGuess = SelectRandomWord(words); // Random Word
            char[] guessedLetters = new char[wordToGuess.Length]; // List of correctly guessed characters
            int wrongGuesses = 0; // amount of wrongly guessed characters
            bool gameOver = false;

            while (!gameOver)
            {
                Console.Clear(); // Clears Console
                HangmanDraw(wrongGuesses);
                DisplayWord(wordToGuess, guessedLetters);

                Console.Write("Enter a letter or guess the word: ");
                string input = Console.ReadLine().ToLower();

                if (input.Length == 1 && Char.IsLetter(input[0])) // single letter guess
                {
                    char guess = input[0];
                    if (wordToGuess.Contains(guess)) // Correct guess
                    {
                        // Update guessed letters
                        for (int i = 0; i < wordToGuess.Length; i++)
                        {
                            if (wordToGuess[i] == guess)
                            {
                                guessedLetters[i] = guess;
                            }
                        }

                        // Check if the player has won
                        if (new string(guessedLetters) == wordToGuess)
                        {
                            Console.Clear();
                            DisplayWord(wordToGuess, guessedLetters);
                            Console.WriteLine("Congratulations! You've won!");
                            gameOver = true;
                        }
                    }
                    else
                    {
                        // Incorrect guess
                        wrongGuesses++;
                        if (wrongGuesses == 11) // maximum wrong guesses
                        {
                            Console.Clear();
                            HangmanDraw(wrongGuesses);
                            Console.WriteLine("Game over! The word was: " + wordToGuess); // This word was looked for.
                            gameOver = true;
                        }
                    }
                }
                else if (input.Length == wordToGuess.Length && input == wordToGuess)
                {
                    // Guessed the whole word correctly
                    Console.Clear();
                    DisplayWord(wordToGuess, guessedLetters);
                    Console.WriteLine("Congratulations! You've won!");
                    gameOver = true;
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a single letter or guess the whole word.");
                }
            }
        }

        static string SelectRandomWord(string[] words) //Random Word selector
        {
            Random random = new Random();
            int index = random.Next(words.Length);
            return words[index];
        }

        static void DisplayWord(string word, char[] guessedLetters) // Displays the word, or what parts of it were guessed.
        {
            for (int i = 0; i < word.Length; i++)
            {
                if (guessedLetters[i] != 0)
                {
                    Console.Write(guessedLetters[i] + " ");
                }
                else
                {
                    Console.Write("_ ");
                }
            }
            Console.WriteLine();
        }
        static void HangmanDraw(int WrongGuesses)
        {
            switch (WrongGuesses)
            {
                case 0:
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    break;
                case 1:
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine(".........................................");
                    Console.WriteLine("...._________________________________....");
                    Console.WriteLine(@".../.................................\...");
                    Console.WriteLine(@"../...................................\..");
                    Console.WriteLine(@"./.....................................\.");
                    Console.WriteLine(@"/.......................................\");
                    break;
                case 2:
                    Console.WriteLine( ".........................................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "....__________|______________________....");
                    Console.WriteLine(@".../.................................\...");
                    Console.WriteLine(@"../...................................\..");
                    Console.WriteLine(@"./.....................................\.");
                    Console.WriteLine(@"/.......................................\");
                    break;
                case 3:
                    Console.WriteLine( ".............._________..................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "....__________|______________________....");
                    Console.WriteLine(@".../.................................\...");
                    Console.WriteLine(@"../...................................\..");
                    Console.WriteLine(@"./.....................................\.");
                    Console.WriteLine(@"/.......................................\");
                    break;
                case 4:
                    Console.WriteLine( ".............._________..................");
                    Console.WriteLine( "..............|/.........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "....__________|______________________....");
                    Console.WriteLine(@".../.................................\...");
                    Console.WriteLine(@"../...................................\..");
                    Console.WriteLine(@"./.....................................\.");
                    Console.WriteLine(@"/.......................................\");
                    break;
                case 5:
                    Console.WriteLine( ".............._________..................");
                    Console.WriteLine( "..............|/......|..................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "....__________|______________________....");
                    Console.WriteLine(@".../.................................\...");
                    Console.WriteLine(@"../...................................\..");
                    Console.WriteLine(@"./.....................................\.");
                    Console.WriteLine(@"/.......................................\");
                    break;
                case 6:
                    Console.WriteLine( ".............._________..................");
                    Console.WriteLine( "..............|/......|..................");
                    Console.WriteLine( "..............|.......O..................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "....__________|______________________....");
                    Console.WriteLine(@".../.................................\...");
                    Console.WriteLine(@"../...................................\..");
                    Console.WriteLine(@"./.....................................\.");
                    Console.WriteLine(@"/.......................................\");
                    break;
                case 7:
                    Console.WriteLine( ".............._________..................");
                    Console.WriteLine( "..............|/......|..................");
                    Console.WriteLine( "..............|.......O..................");
                    Console.WriteLine( "..............|.......|..................");
                    Console.WriteLine( "..............|.......|..................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "....__________|______________________....");
                    Console.WriteLine(@".../.................................\...");
                    Console.WriteLine(@"../...................................\..");
                    Console.WriteLine(@"./.....................................\.");
                    Console.WriteLine(@"/.......................................\");
                    break;
                case 8:
                    Console.WriteLine( ".............._________..................");
                    Console.WriteLine( "..............|/......|..................");
                    Console.WriteLine( "..............|.......O..................");
                    Console.WriteLine( "..............|....../|..................");
                    Console.WriteLine( "..............|.......|..................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "....__________|______________________....");
                    Console.WriteLine(@".../.................................\...");
                    Console.WriteLine(@"../...................................\..");
                    Console.WriteLine(@"./.....................................\.");
                    Console.WriteLine(@"/.......................................\");
                    break;
                case 9:
                    Console.WriteLine( ".............._________..................");
                    Console.WriteLine( "..............|/......|..................");
                    Console.WriteLine( "..............|.......O..................");
                    Console.WriteLine(@"..............|....../|\.................");
                    Console.WriteLine( "..............|.......|..................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "....__________|______________________....");
                    Console.WriteLine(@".../.................................\...");
                    Console.WriteLine(@"../...................................\..");
                    Console.WriteLine(@"./.....................................\.");
                    Console.WriteLine(@"/.......................................\");
                    break;
                case 10:
                    Console.WriteLine( ".............._________..................");
                    Console.WriteLine( "..............|/......|..................");
                    Console.WriteLine( "..............|.......O..................");
                    Console.WriteLine(@"..............|....../|\.................");
                    Console.WriteLine( "..............|.......|..................");
                    Console.WriteLine( "..............|....../...................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "....__________|______________________....");
                    Console.WriteLine(@".../.................................\...");
                    Console.WriteLine(@"../...................................\..");
                    Console.WriteLine(@"./.....................................\.");
                    Console.WriteLine(@"/.......................................\");
                    break;
                case 11:
                    Console.WriteLine( ".............._________..................");
                    Console.WriteLine( "..............|/......|..................");
                    Console.WriteLine( "..............|.......O..................");
                    Console.WriteLine(@"..............|....../|\.................");
                    Console.WriteLine( "..............|.......|..................");
                    Console.WriteLine(@"..............|....../.\.................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "..............|..........................");
                    Console.WriteLine( "....__________|______________________....");
                    Console.WriteLine(@".../.................................\...");
                    Console.WriteLine(@"../...................................\..");
                    Console.WriteLine(@"./.....................................\.");
                    Console.WriteLine(@"/.......................................\");
                    break;
            }
        }
    }
}