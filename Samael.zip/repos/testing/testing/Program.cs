﻿using System.Reflection.Emit;

namespace testing
{
    class Program
    {
        string[,] TierArray = new string[1600, 4];
        string[,] GehegeArray = new string[400, 3];
        int GehegeMenge = 0; // Menge von Gehege im Zoo
        int FischMenge = 0; // Menge von Fische im Zoo
        int SaeugetierMenge = 0; // Menge von Säugetieren im Zoo
        int TierMenge = 0; // Menge von Tieren im Zoo
        int MengeFutter = 800;
        private void Fuettern()
        {
            bool Hunger = true;
            while (Hunger)
            {
                if (MengeFutter >= FischMenge + (SaeugetierMenge * 2)) // Säugetiere brauchen mehr Futter als Fische.
                {
                    MengeFutter -= FischMenge + (SaeugetierMenge * 2);
                    Hunger = false;
                }
                else if (FischMenge >= 1) // Fische werden von den Säugetieren als Futter angesehen
                {
                    FischMenge -= 1;
                    MengeFutter += 1;
                }
                else if (SaeugetierMenge >= 1) // Säugetiere verhungern
                {
                    SaeugetierMenge -= 1;
                }
                else // Futter wird zurückgesetzt
                {
                    MengeFutter = 800;
                }
                label5.Text = "Menge Futter: " + MengeFutter;
            }
        }
        private void GehegeErstellen(string GehegeArt)
        {
            GehegeArray[GehegeMenge, 0] = "Gehege";
            GehegeArray[GehegeMenge, 1] = GehegeArt;
            GehegeArray[GehegeMenge, 2] = GehegeMenge.ToString();
            GehegeMenge++;
            label1.Text = "Anzahl Gehege: " + GehegeMenge;
        }
        private void TierErstellen(string TierArt)
        {
            int i = 0;
            bool HatGehege = false;
            for (i = 0; i < GehegeMenge; i++)
            {
                if (GehegeArray[i, 1] == TierArt)
                {
                    HatGehege = true;
                    break;
                }
            }
            if (HatGehege)
            {
                TierArray[TierMenge, 0] = "Tier";
                TierArray[TierMenge, 1] = TierArt;
                TierArray[TierMenge, 2] = GehegeMenge.ToString();
                TierMenge++;
                if (TierArt == "Fische")
                {
                    FischMenge++;
                    label4.Text = "Anzahl Fische: " + FischMenge;
                }
                if (TierArt == "Säugetier")
                {
                    SaeugetierMenge++;
                    label3.Text = "Anzahl Säugetiere: " + SaeugetierMenge;
                }
                TierMenge = FischMenge + SaeugetierMenge;
                label2.Text = "Anzahl Tiere: " + TierMenge;
            }
            else
            {
                MessageBox.Show("Es ist kein Gehege verfügbar!", "Kein Gehege verfügbar!");
            }
        }
        private void GrundzustandZurücksetzen()
        {
            TierArray = new string[1600, 3];
            GehegeArray = new string[400, 3];
            GehegeMenge = 0;
            FischMenge = 0;
            SaeugetierMenge = 0;
            TierMenge = 0;
            label1.Text = "Anzahl Gehege: " + GehegeMenge;
            label2.Text = "Anzahl Tiere: " + TierMenge;
            label3.Text = "Anzahl Säugetiere: " + SaeugetierMenge;
            label4.Text = "Anzahl Fische: " + FischMenge;
        }

        private string ArtBestimmen()
        {
            string Output = "0";
            string message = "Welche Tierart? Ja = Säugetier Nein = Fische";
            string title = "Tierart";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons);
            if (result == DialogResult.Yes)
            {
                Output = "Säugetier";
            }
            if (result == DialogResult.No)
            {
                Output = "Fische";
            }
            return Output;
        }
        static void Main()
        {
            int zahl = 65;
            char zeichen = 'c';
            string text = zeichen.ToString();
            text += zahl;
            Console.WriteLine(text);
            Console.WriteLine(zeichen);
            Console.WriteLine(zeichen + zahl);
        }
    }
}
