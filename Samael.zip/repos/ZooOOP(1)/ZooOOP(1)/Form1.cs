namespace ZooOOP_1_
{
    public partial class Form1 : Form
    {
        string[,] Gehege;
        string[,] Tiere;
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Dr�cke Knopf 4 zuerst");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Dr�cke Knopf 4 zuerst");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Der Zoo ist weg! Endlich!"); //Einziger Code, der mir gef�llt
        }
    }
}