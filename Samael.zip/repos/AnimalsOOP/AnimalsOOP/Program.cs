﻿using System;
using System.Collections.Generic;

// Basisklasse für Tiere
public abstract class Tier
{
    public string Name { get; set; }
    public abstract string Art { get; }
    public abstract string Gattung { get; }
    public abstract string Ernährung { get; }
    public abstract string Fortpflanzung { get; }

    public virtual void SagWasDuBist()
    {
        Console.WriteLine($"Ich bin ein {Art} aus der Gattung {Gattung}.");
    }

    public virtual void SagWieDuIsst()
    {
        Console.WriteLine($"Ich ernähre mich durch {Ernährung}.");
    }

    public virtual void SagWieDuDichFortpflanzt()
    {
        Console.WriteLine($"Ich pflanze mich fort durch {Fortpflanzung}.");
    }
}

// Säugetierklasse
public class Säugetier : Tier
{
    public override string Art => "Säugetier";
    public override string Gattung { get; }
    public override string Ernährung { get; }
    public override string Fortpflanzung { get; }

    public Säugetier(string gattung, string ernährung, string fortpflanzung)
    {
        Gattung = gattung;
        Ernährung = ernährung;
        Fortpflanzung = fortpflanzung;
    }
}

// Fischklasse
public class Fisch : Tier
{
    public override string Art => "Fisch";
    public override string Gattung { get; }
    public override string Ernährung { get; }
    public override string Fortpflanzung { get; }

    public Fisch(string gattung, string ernährung, string fortpflanzung)
    {
        Gattung = gattung;
        Ernährung = ernährung;
        Fortpflanzung = fortpflanzung;
    }
}

// Gehegeklasse
public class Gehege
{
    private List<Tier> tiere = new List<Tier>();

    public void TierHinzufügen(Tier tier)
    {
        tiere.Add(tier);
        Console.WriteLine($"{tier.Name} wurde dem Gehege hinzugefügt.");
    }

    public int AnzahlDerTiere()
    {
        return tiere.Count;
    }

    public int AnzahlDerTiereArt(string art)
    {
        return tiere.FindAll(t => t.Art.Equals(art, StringComparison.OrdinalIgnoreCase)).Count;
    }

    public void GrundzustandZurücksetzen()
    {
        tiere.Clear();
        Console.WriteLine("Das Gehege wurde zurückgesetzt.");
    }
}

// Zoo-Klasse
public class Zoo
{
    private List<Gehege> gehegeListe = new List<Gehege>();

    public void GehegeErstellen()
    {
        Gehege gehege = new Gehege();
        gehegeListe.Add(gehege);
        Console.WriteLine("Ein neues Gehege wurde erstellt.");
    }

    public void TierGeboren(Tier tier, int gehegeIndex)
    {
        if (gehegeIndex >= 0 && gehegeIndex < gehegeListe.Count)
        {
            gehegeListe[gehegeIndex].TierHinzufügen(tier);
        }
        else
        {
            Console.WriteLine("Ungültiger Gehegeindex.");
        }
    }

    public int AnzahlDerGehege()
    {
        return gehegeListe.Count;
    }

    public int AnzahlDerTiereInZoo()
    {
        int count = 0;
        foreach (var gehege in gehegeListe)
        {
            count += gehege.AnzahlDerTiere();
        }
        return count;
    }

    public int AnzahlDerTiereArtInZoo(string art)
    {
        int count = 0;
        foreach (var gehege in gehegeListe)
        {
            count += gehege.AnzahlDerTiereArt(art);
        }
        return count;
    }

    public void GrundzustandZurücksetzen()
    {
        gehegeListe.Clear();
        Console.WriteLine("Der Zoo wurde zurückgesetzt.");
    }
}

class Program
{
    static void Main()
    {
        Zoo zoo = new Zoo();

        zoo.GehegeErstellen();

        Tier löwe = new Säugetier("Felidae", "Fleisch", "Geburt");
        löwe.Name = "Simba";
        zoo.TierGeboren(löwe, 0);

        Tier hai = new Fisch("Elasmobranchii", "Fleisch", "Eierlegung");
        hai.Name = "Bruce";
        zoo.TierGeboren(hai, 0);

        Console.WriteLine($"Anzahl der Gehege: {zoo.AnzahlDerGehege()}");
        Console.WriteLine($"Anzahl der Tiere im Zoo: {zoo.AnzahlDerTiereInZoo()}");
        Console.WriteLine($"Anzahl der Säugetiere im Zoo: {zoo.AnzahlDerTiereArtInZoo("Säugetier")}");
        Console.WriteLine($"Anzahl der Fische im Zoo: {zoo.AnzahlDerTiereArtInZoo("Fisch")}");

        zoo.GrundzustandZurücksetzen();

        Console.WriteLine($"Anzahl der Gehege nach dem Zurücksetzen: {zoo.AnzahlDerGehege()}");

        Console.ReadLine();
    }
}