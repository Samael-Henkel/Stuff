using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ZooOOP
{
    /// <summary>
    /// Ich hasse diesen Code und alles, wof�r er steht!
    /// </summary>

    //Ich bin fertig!
    public partial class Form1 : Form
    {
        Zoo zoo = new Zoo();
        int MengeFische = 0;
        int MengeS�uger = 0;
        int AnimalCount = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            zoo.GehegeErstellen();
            label1.Text = "Anzahl Gehege: " + zoo.AnzahlDerGehege();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            zoo.TierGeboren(new Fisch("S�ugetier", "fleischenthaltende Ern�hrung", "Lebendgeburt"), 0);
            MengeS�uger++;
            label3.Text = "Anzahl S�ugetiere: " + MengeS�uger;
            label2.Text = "Anzahl Tiere: " + (MengeFische + MengeS�uger);
            CreateButtons();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            zoo.TierGeboren(new Fisch("Fisch", "vegane Ern�hrung", "Laichung"), 0);
            MengeFische++;
            label4.Text = "Anzahl Fische: " + MengeFische;
            label2.Text = "Anzahl Tiere: " + (MengeFische + MengeS�uger);
            CreateButtons();
        }
        private void CreateButtons()
        {
            // Define button properties
            int buttonWidth = 100;
            int buttonHeight = 20;
            int buttonSpacing = 5;
            int numberOfButtons = 5;

            // Loop to create buttons
            while (AnimalCount < numberOfButtons)
            {
                // Create button
                System.Windows.Forms.Button button = new System.Windows.Forms.Button();
                button.Text = "Button " + (AnimalCount + 1);
                button.Width = buttonWidth;
                button.Height = buttonHeight;
                button.Top = buttonSpacing + (buttonHeight + buttonSpacing) * AnimalCount;
                button.Left = buttonSpacing;

                // Attach TierInfo function to button click event
                /// button.Click += TierInfo;
                AnimalCount++;
                // Add button to panel
                panel1.Controls.Add(button);
            }
        }
    }

    // Basisklasse f�r Tiere
    public abstract class Tier
    {
        public string Name { get; set; }
        public abstract string Art { get; }
        public abstract string Gattung { get; }
        public abstract string Ern�hrung { get; }
        public abstract string Fortpflanzung { get; }

        public virtual string SagWasDuBist()
        {
            return ($"Ich bin ein {Art} aus der Gattung {Gattung}.");
        }

        public virtual string SagWieDuIsst()
        {
            return ($"Ich ern�hre mich durch {Ern�hrung}.");
        }

        public virtual string SagWieDuDichFortpflanzt()
        {
            return ($"Ich pflanze mich fort durch {Fortpflanzung}.");
        }
    }

    // S�ugetierklasse
    public class S�ugetier : Tier
    {
        public override string Art => "S�ugetier";
        public override string Gattung { get; }
        public override string Ern�hrung { get; }
        public override string Fortpflanzung { get; }

        public S�ugetier(string gattung, string ern�hrung, string fortpflanzung)
        {
            Gattung = gattung;
            Ern�hrung = ern�hrung;
            Fortpflanzung = fortpflanzung;
        }
    }

    // Fischklasse
    public class Fisch : Tier
    {
        public override string Art => "Fisch";
        public override string Gattung { get; }
        public override string Ern�hrung { get; }
        public override string Fortpflanzung { get; }

        public Fisch(string gattung, string ern�hrung, string fortpflanzung)
        {
            Gattung = gattung;
            Ern�hrung = ern�hrung;
            Fortpflanzung = fortpflanzung;
        }
    }

    // Gehegeklasse
    public class Gehege
    {
        private List<Tier> tiere = new List<Tier>();

        public void TierHinzuf�gen(Tier tier)
        {
            tiere.Add(tier);
            Console.WriteLine($"{tier.Name} wurde dem Gehege hinzugef�gt.");
        }

        public int AnzahlDerTiere()
        {
            return tiere.Count;
        }

        public int AnzahlDerTiereArt(string art)
        {
            return tiere.FindAll(t => t.Art.Equals(art, StringComparison.OrdinalIgnoreCase)).Count;
        }

        public void GrundzustandZur�cksetzen()
        {
            tiere.Clear();
            Console.WriteLine("Das Gehege wurde zur�ckgesetzt.");
        }
    }

    // Zoo-Klasse
    public class Zoo
    {
        private List<Gehege> gehegeListe = new List<Gehege>();

        public void GehegeErstellen()
        {
            Gehege gehege = new Gehege();
            gehegeListe.Add(gehege);
            Console.WriteLine("Ein neues Gehege wurde erstellt.");
        }

        public void TierGeboren(Tier tier, int gehegeIndex)
        {
            if (gehegeIndex >= 0 && gehegeIndex < gehegeListe.Count)
            {
                gehegeListe[gehegeIndex].TierHinzuf�gen(tier);
            }
            else
            {
                Console.WriteLine("Ung�ltiger Gehegeindex.");
            }
        }

        public int AnzahlDerGehege()
        {
            return gehegeListe.Count;
        }

        public int AnzahlDerTiereInZoo()
        {
            int count = 0;
            foreach (var gehege in gehegeListe)
            {
                count += gehege.AnzahlDerTiere();
            }
            return count;
        }

        public int AnzahlDerTiereArtInZoo(string art)
        {
            int count = 0;
            foreach (var gehege in gehegeListe)
            {
                count += gehege.AnzahlDerTiereArt(art);
            }
            return count;
        }

        public void GrundzustandZur�cksetzen()
        {
            gehegeListe.Clear();
            Console.WriteLine("Der Zoo wurde zur�ckgesetzt.");
        }
    }
}