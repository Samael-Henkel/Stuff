﻿using System;

namespace FightingGame
{
    class Program
    {
        static void Main(string[] args)
        {
            Game();
        }
        static int EnemiesSpared = 0;
        static int EnemiesKilled = 0;
        static void Game()
        {
            player Player = new player();
            Console.WriteLine("Whats the name of the player character");
            Player.name = Console.ReadLine();
            bool Continue = true;
            while (Continue)
            {
                Random rng = new Random();
                enemy Enemy = new enemy();
                Player.hp = 100 + (20 * (EnemiesSpared + EnemiesKilled));
                Player.maxhp = 100 + (20 * (EnemiesSpared + EnemiesKilled));
                Player.tp = 0;
                Player.atk = 10 + (1 * EnemiesKilled);
                Player.def = 10 + (1 * EnemiesSpared);
                Enemy.hp = rng.Next(Player.maxhp - 50, Player.maxhp + 50);
                Enemy.atk = rng.Next(Player.def - 5, Player.def + 5);
                Enemy.def = rng.Next(Player.atk - 5, Player.atk + 5);
                while (Enemy.defeat == false && Player.defeat == false)
                {
                    Console.WriteLine(Player.name + ": " + Player.hp + "/" + Player.maxhp + " HP, " + Player.atk + " ATK, " + Player.def + " DEF, " + Player.tp + " TP");
                    Console.WriteLine("What will " + Player.name + " do?: [atk/def/check/heal/tpheal/specatk/spare/nothing]");
                    string PlayerDoes = Console.ReadLine().ToLower();
                    if (PlayerDoes == "atk" || PlayerDoes == "attack")
                    {
                        Enemy.Fight(Player.atk, Player.name);
                        if (Enemy.defeat == false)
                        {
                            Enemy.confused = Player.Attacked(Enemy.atk, Enemy.confused);
                        }
                    }
                    else if (PlayerDoes == "def" || PlayerDoes == "defend")
                    {
                        Player.Defend();
                        Enemy.confused = Player.Attacked(Enemy.atk, Enemy.confused);
                    }
                    else if (PlayerDoes == "heal")
                    {
                        Player.Heal();
                        Enemy.confused = Player.Attacked(Enemy.atk, Enemy.confused);
                    }
                    else if (PlayerDoes == "check")
                    {
                        Enemy.Check();
                        Enemy.confused = Player.Attacked(Enemy.atk, Enemy.confused);
                    }
                    else if (PlayerDoes == "tpheal")
                    {
                        if (Player.tp >= 30)
                        {
                            Player.TPHeal();
                            Enemy.confused = Player.Attacked(Enemy.atk, Enemy.confused);
                        }
                        else
                        {
                            Console.WriteLine("Not Enougth TP (30)");
                        }
                    }
                    else if (PlayerDoes == "specatk" || PlayerDoes == "specialattack")
                    {
                        if (Player.tp >= 30)
                        {
                            Player.tp = Enemy.SpecialAttack(Player.tp, Player.atk, Player.name);
                            if (Enemy.defeat == false)
                            {
                                Enemy.confused = Player.Attacked(Enemy.atk, Enemy.confused);
                            }
                        }
                        else
                        {
                            Console.WriteLine("Not Enougth TP (30)");
                        }
                    }
                    else if (PlayerDoes == "spare" || PlayerDoes == "mercy")
                    {
                        Enemy.Spare(Player.name);
                        if (Enemy.defeat == false)
                        {
                            Enemy.confused = Player.Attacked(Enemy.atk, Enemy.confused);
                        }
                    }
                    else if (PlayerDoes == "nothing")
                    {
                        Console.WriteLine(Player.name + " did nothing. The enemy got confused");
                        Enemy.spareprog = Enemy.spareprog + 15;
                        Enemy.confused = true;
                        Enemy.confused = Player.Attacked(Enemy.atk, Enemy.confused);
                    }
                    else
                    {
                        Console.WriteLine("Unknown Option! Please try again");
                    }
                }
                if (Enemy.spared)
                {
                    EnemiesSpared++;
                }
                else if (Enemy.killed)
                {
                    EnemiesKilled++;
                }
                Console.WriteLine("Enemies spared: " + Convert.ToString(EnemiesSpared) + ". Enemies Killed: " + Convert.ToString(EnemiesKilled) + ".");
                if (Player.defeat == false)
                {
                    string YesOrNo = "";
                    while (YesOrNo != "y" && YesOrNo != "n")
                    {
                        Console.WriteLine("Continue?[y/n]");
                        YesOrNo = Console.ReadLine().ToLower();
                        if (YesOrNo == "y")
                        {
                            Continue = true;
                        }
                        else if (YesOrNo == "n")
                        {
                            Continue = false;
                        }
                        else
                        {
                            Console.WriteLine("Invalid Input! Please try again");
                        }
                    }
                }
                else
                {
                    Continue = false;
                    Console.WriteLine("Game Over!");
                }
            }
        }
    }
    class player
    {
        public string name = "";
        public int hp;
        public int maxhp;
        public int atk;
        public int def;
        public bool isDefending = false;
        public int tp;
        public bool defeat = false;
        public void Defend()
        {
            isDefending = true;
            tp = tp + 15;
            if (tp > 100)
            {
                tp = 100;
            }
            Console.WriteLine(name + " defended. Enemy attacks deal less damage this turn, and " + name + " gained 15TP");
        }
        public void Heal()
        {
            hp = hp + 15;
            if (hp >= maxhp)
            {
                hp = maxhp;
                Console.WriteLine(name + " healed themself. HP fully restored!");
            }
            else
            {
                Console.WriteLine(name + " healed themself. 15 HP restored!");
            }
        }
        public void TPHeal()
        {
            tp = tp - 30;
            hp = hp + 50;
            if (hp == maxhp)
            {
                Console.WriteLine(name + " healed themselves alot. HP fully restored!");
            }
            else if (hp > maxhp)
            {
                Console.WriteLine(name + " healed themselves alot. They are now overhealed!");
            }
            else
            {
                Console.WriteLine(name + " healed yourselves alot. 50 HP restored!");
            }
        }
        public bool Attacked(int Enemyatk, bool Enemyconfused)
        {
            Random rng = new Random();
            int FiftyFifty = rng.Next(1, 100);
            int dmg;
            if (isDefending && Enemyconfused)
            {
                dmg = 10 + (Enemyatk / 4) - def;
                isDefending = false;
            }
            else if (isDefending || Enemyconfused)
            {
                dmg = 10 + (Enemyatk / 2) - def;
                isDefending = false;
            }
            else
            {
                dmg = 10 + Enemyatk - def;
            }
            hp = hp - dmg;
            Console.WriteLine("The Enemy dealt " + dmg + " Damage");
            if (FiftyFifty >= 65 && Enemyconfused == true)
            {
                Enemyconfused = false;
                Console.WriteLine("Enemy is no longer confused");
            }
            if (hp <= 0)
            {
                defeat = true;
                Console.WriteLine(name + " was defeated!");
            }
            return Enemyconfused;
        }
    }
    public class enemy
    {
        static Random rng = new Random();
        public int hp;
        public int atk;
        public int def;
        public int spareprog = 0;
        public bool defeat = false;
        public bool confused = false;
        public bool spared = false;
        public bool killed = false;
        public void Fight(int Playeratk, string Playername)
        {
            int dmg = 10 + Playeratk - def;
            hp = hp - dmg;
            Console.WriteLine(Playername + " dealt " + dmg + " Damage");
            if (hp <= 0)
            {
                defeat = true;
                Console.WriteLine("Enemy was defeated!");
                killed = true;
            }
        }
        public void Spare(string Playername)
        {
            Console.WriteLine(Playername + " spared the enemy");
            if (spareprog >= 100)
            {
                defeat = true;
                Console.WriteLine("Enemy was defeated...peacefully!");
                spared = true;
            }
            else
            {
                Console.WriteLine("...but they werent convinced");
                spareprog = spareprog + 10;
            }
        }
        public int SpecialAttack(int PlayerTP, int Playeratk, string Playername)
        {
            PlayerTP = PlayerTP - 30;
            int dmg = 5 * Playeratk / (def / rng.Next(1, def + 1));
            hp = hp - dmg;
            Console.WriteLine(Playername + " dealt " + dmg + " Damage");
            if (hp <= 0)
            {
                defeat = true;
                Console.WriteLine("Enemy was defeated!");
                killed = true;
            }
            return PlayerTP;
        }
        public void Check()
        {
            if (confused == true)
            {
                Console.Write("(Confused) ");
            }
            Console.WriteLine("Enemy: " + hp + " HP, " + atk + " ATK, " + def + " DEF, " + spareprog + "% ready to be spared.");
        }
    }
}
