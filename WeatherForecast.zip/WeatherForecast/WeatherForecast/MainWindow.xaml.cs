﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WeatherForecast.Weather;
using WeatherForecast.Services;
using WeatherForecast.Forecast;
using WeatherForecast.Services.Forecast;

namespace WeatherForecast
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DateTime startDate = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
        OpenWeatherMapServices openWeatherMapServices = new();
        OpenForecastMapServices openForecastMapServices = new();
        WeatherData weatherData;
        ForecastData forecastData;
        bool CityNotFound = false;
        public MainWindow()
        {
            InitializeComponent();
            Date.Content = "Date: " + DateTime.Now.ToString("yyyy'-'MM'-'dd");
            getWeather("Bern");
            getForecast("Bern");
        }

        private void Search(object sender, RoutedEventArgs e)
        {
            getWeather(Location.Text);
            getForecast(Location.Text);
        }
        private async void getForecast(string City)
        {
            forecastData = await openForecastMapServices.GetForecast(City);
            if(forecastData.Message == "city not found" && !CityNotFound)
            {
                forecastData = await openForecastMapServices.GetForecast("Bern");
                CityNotFound = true;
            }
            else
            {
                CityNotFound = false;
            }
            var i = 3;
            foreach (Label label in ForecastWindow.Items)
            {
                string labelContent1 = startDate.AddSeconds(forecastData.List[i].Dt) + ": ";
                string labelContent2 = forecastData.List[i].Main.Temp + "°C ";
                string labelContent3 = forecastData.List[i].Weather[0].Description + " (Feels like ";
                string labelContent4 = forecastData.List[i].Main.Feels_Like + "°C)";
                label.Content = labelContent1 + labelContent2 + labelContent3 + labelContent4;
                i += 4;
            }
        }
        private async void getWeather(string City)
        {
            weatherData = await openWeatherMapServices.GetWeather(City);
            if (weatherData.Message == "city not found" && !CityNotFound)
            {
                MessageBox.Show("City not found. Defaulting to Bern, CH", "City Not Found", MessageBoxButton.OK, MessageBoxImage.Error);
                weatherData = await openWeatherMapServices.GetWeather("Bern");
                CityNotFound = true;
            }
            else
            {
                CityNotFound = false;
            }
            ActualTemp.Content = weatherData.Main.Temp + "°C";
            FeltTemp.Content = $"Feels like {weatherData.Main.Feels_Like}°C";
            LocationText.Content = weatherData.Name + ", " + weatherData.Sys.Country;
            UpdateTime.Content = "Status: " + DateTime.Now.ToString("yyyy'-'MM'-'dd' 'HH':'mm':'ss");
            Sunset.Content = "Sunset: " + startDate.AddSeconds(weatherData.Sys.Sunset);
            Sunrise.Content = "Sunrise: " + startDate.AddSeconds(weatherData.Sys.Sunrise);
            switch (weatherData.Weather[0].Main)
            {
                case "Rain":
                case "Shower Rain":
                case "Drizzle":
                case "Thunderstorm":
                    {
                        if(weatherData.Weather[0].Description.ToLower() == "light rain")
                        {
                            WeatherImg.Source = new BitmapImage(new Uri("lightRain.png", UriKind.Relative));
                        } else if(weatherData.Weather[0].Description.ToLower() == "moderate rain" || weatherData.Weather[0].Description.ToLower() == "heavy rain" || weatherData.Weather[0].Description.ToLower() == "very heavy rain")
                        {
                            WeatherImg.Source = new BitmapImage(new Uri("rain.png", UriKind.Relative));
                        }
                        break;
                    }
                case "Clear":
                    {
                        WeatherImg.Source = new BitmapImage(new Uri("sunny.png", UriKind.Relative));
                        break;
                    }
                case "Clouds":
                    {
                        if (weatherData.Weather[0].Description.ToLower() == "broken clouds" || weatherData.Weather[0].Description.ToLower() == "scattered clouds" || weatherData.Weather[0].Description.ToLower() == "few clouds")
                        {
                            WeatherImg.Source = new BitmapImage(new Uri("cloudy.png", UriKind.Relative));
                        } else if (weatherData.Weather[0].Description.ToLower() == "overcast clouds")
                        {
                            WeatherImg.Source = new BitmapImage(new Uri("VeryCloudy.png", UriKind.Relative));
                        }
                        break;
                    }
                case "Snow":
                    {
                        WeatherImg.Source = new BitmapImage(new Uri("snow.png", UriKind.Relative));
                        break;
                    }
                case "Snow Rain":
                    {
                        WeatherImg.Source = new BitmapImage(new Uri("Snowrain.png", UriKind.Relative));
                        break;
                    }
                case "Mist":
                    {
                        WeatherImg.Source = new BitmapImage(new Uri("foggy.png", UriKind.Relative));
                        break;
                    }
                default:
                    {
                        WeatherImg.Source = new BitmapImage(new Uri("sunny.png", UriKind.Relative));
                        break;
                    }
            }
        }
    }
}
