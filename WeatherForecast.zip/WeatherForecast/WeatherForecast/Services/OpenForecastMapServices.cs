using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using WeatherForecast.Forecast;

namespace WeatherForecast.Services.Forecast
{
    class OpenForecastMapServices
    {
        private const string APID = "2d2e335a6a5f95ce980f1287043f1933";
        private string OpenWeatherMapURL = "https://api.openweathermap.org/data/2.5/";
        private HttpClient httpClient = new();
        public async Task<ForecastData> GetForecast(string location)
        {
            var LocationURL = $"{OpenWeatherMapURL}forecast?q={location}&units=metric&appid={APID}";
            var response = await httpClient.GetAsync(LocationURL);
            var responseContent = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<ForecastData>(responseContent);
        }
    }
}