﻿using System;
using System.Threading;
using System.IO;
using StuffFolder.AboutHSTBOS;
using StuffFolder.HenkelsoftWord;
using StuffFolder.UTDRBattleSim;

namespace StuffFolder
{
    class Stuff
    {
        TXT_About txt_About = new();
        FileReaderWriter writer = new();
        BattleSim battlesim = new();
        public void OpenStuff(int year)
        {
            bool inStuff = true;
            string toDo;
            Console.WriteLine(@"______________________________________________________________________________");
            Console.WriteLine(@"| Stuff                                                            _   8 | X |");
            Console.WriteLine(@"|________________________________________________________________________|___|");
            Console.WriteLine(@"| Icon    | Name                      | Type               | Size            |");
            Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
            Console.WriteLine(@"| _____   |                           |                    |                 |");
            Console.WriteLine(@"| | W |   | HenkelSoft Writer         | Program            | 27 KB           |");
            Console.WriteLine(@"| |___|   |                           |                    |                 |");
            Console.WriteLine(@"|---------|---------------------------|--------------------|-----------------|");
            Console.WriteLine(@"|  /\/\   |                           |                    |                 |");
            Console.WriteLine(@"|  \  /   | UT/DR Battle Sim          | Program            | 44 KB           |"); 
            Console.WriteLine(@"|   \/    |                           |                    |                 |");
            Console.WriteLine(@"|---------|---------------------------|--------------------|-----------------|");
            Console.WriteLine(@"|  ____   |                           |                    |                 |");
            Console.WriteLine(@"| |.txt|  | AboutHSTBOS.txt           | .txt file          | 6 KB            |");
            Console.WriteLine(@"| |____|  |                           |                    |                 |");
            Console.WriteLine(@"|---------|---------------------------|--------------------|-----------------|");
            Console.WriteLine(@"| /#####\ |                           |                    |                 |");
            Console.WriteLine(@"| |.exe | | HenkelSoftTextBasedOS.exe | .exe file          | 123 KB          |");
            Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
            Console.WriteLine(@"| S T A R T |  Stuff  |                                     01:00 01.01." + year + " |");
            Console.WriteLine(@"|___________|_________|______________________________________________________|");
            while(inStuff == true)
            {
                Console.Write("What do you want to do? (Enter help for help):");
                toDo = Console.ReadLine();
                switch (toDo)
                {
                    case "help":
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| Stuff                                                            _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"|  __________                                                                |");
                        Console.WriteLine(@"|  |      | |                                                                |");
                        Console.WriteLine(@"|  |      | |  Stuff - Folder                                                |");
                        Console.WriteLine(@"|  |      | |                                                                |");
                        Console.WriteLine(@"|  |______|_|                                                                |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|  open - open a Program/File                                                |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|  view - view the Contents of this folder                                   |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|  exit - leave the folder                                                   |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|  help - show this list                                                     |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                       TBOS was made " + year + " by HenkelSoft Inc.|");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T |  Stuff  |                                     01:00 01.01." + year + " |");
                        Console.WriteLine(@"|___________|_________|______________________________________________________|");
                        break;
                    case "view":
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| Stuff                                                            _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"| Icon    | Name                      | Type               | Size            |");
                        Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
                        Console.WriteLine(@"| _____   |                           |                    |                 |");
                        Console.WriteLine(@"| | W |   | HenkelSoft Writer         | Program            | 27 KB           |");
                        Console.WriteLine(@"| |___|   |                           |                    |                 |");
                        Console.WriteLine(@"|---------|---------------------------|--------------------|-----------------|");
                        Console.WriteLine(@"|  /\/\   |                           |                    |                 |");
                        Console.WriteLine(@"|  \  /   | UT/DR Battle Sim          | Program            | 44 KB           |");
                        Console.WriteLine(@"|   \/    |                           |                    |                 |");
                        Console.WriteLine(@"|---------|---------------------------|--------------------|-----------------|");
                        Console.WriteLine(@"|  ____   |                           |                    |                 |");
                        Console.WriteLine(@"| |.txt|  | AboutHSTBOS.txt           | .txt file          | 6 KB            |");
                        Console.WriteLine(@"| |____|  |                           |                    |                 |");
                        Console.WriteLine(@"|---------|---------------------------|--------------------|-----------------|");
                        Console.WriteLine(@"| /#####\ |                           |                    |                 |");
                        Console.WriteLine(@"| |.exe | | HenkelSoftTextBasedOS.exe | .exe file          | 123 KB          |");
                        Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
                        Console.WriteLine(@"| S T A R T |  Stuff  |                                     01:00 01.01." + year + " |");
                        Console.WriteLine(@"|___________|_________|______________________________________________________|");
                        break;
                    case "open":
                        Console.Write("What file/program do you want to open?:");
                        string OpenFile = Console.ReadLine();
                        switch (OpenFile)
                        {
                            case "HenkelSoftTextBasedOS.exe":
                            case "4":
                                Console.WriteLine(@"______________________________________________________________________________");
                                Console.WriteLine(@"| Stuff                                                            _   8 | X |");
                                Console.WriteLine(@"|________________________________________________________________________|___|");
                                Console.WriteLine(@"| Icon    | Name                      | Type               | Size            |");
                                Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
                                Console.WriteLine(@"|  ___    |           /_______________________________/    |                 |");
                                Console.WriteLine(@"| | W |   | HenkelSoft| Error                        |     | 27 KB           |");
                                Console.WriteLine(@"| |___|   |           |______________________________|     |                 |");
                                Console.WriteLine(@"|---------|-----------|    .                         |-----|-----------------|");
                                Console.WriteLine(@"|  /\/\   |           |   / \    Not Enough RAM!     |     |                 |");
                                Console.WriteLine(@"|  \  /   | UT/DR Batt|  / ! \   Try downloading     |     | 44 KB           |");
                                Console.WriteLine(@"|   \/    |           | /_____\  some!   ____________|     |                 |");
                                Console.WriteLine(@"|---------|-----------|                 |     Ok     |-----|-----------------|");
                                Console.WriteLine(@"|  ____   |           |_________________|____________|/    |                 |");
                                Console.WriteLine(@"| |.txt|  | AboutHSTBOS.txt           | .txt file          | 6 KB            |");
                                Console.WriteLine(@"| |____|  |                           |                    |                 |");
                                Console.WriteLine(@"|---------|---------------------------|--------------------|-----------------|");
                                Console.WriteLine(@"| /#####\ |                           |                    |                 |");
                                Console.WriteLine(@"| |.exe | | HenkelSoftTextBasedOS.exe | .exe file          | 56 KB           |");
                                Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
                                Console.WriteLine(@"| S T A R T |  Stuff  |                                     01:00 01.01." + year + " |");
                                Console.WriteLine(@"|___________|_________|______________________________________________________|");
                                break;
                            case "AboutHSTBOS.txt":
                            case "3":
                                txt_About.aboutHStxt(year);
                                break;
                            case "HenkelSoft Writer":
                            case "1":
                                writer.setYear = year;
                                writer.TextProgram();
                                break;
                            case "UT/DR Battle Sim":
                            case "2":
                                battlesim.BattleSimulator();
                                break;
                            default:
                                Console.WriteLine(@"______________________________________________________________________________");
                                Console.WriteLine(@"| Stuff                                                            _   8 | X |");
                                Console.WriteLine(@"|________________________________________________________________________|___|");
                                Console.WriteLine(@"| Icon    | Name                      | Type               | Size            |");
                                Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
                                Console.WriteLine(@"|  ___    |           /_______________________________/    |                 |");
                                Console.WriteLine(@"| | W |   | HenkelSoft| Error                        |     | 27 KB           |");
                                Console.WriteLine(@"| |___|   |           |______________________________|     |                 |");
                                Console.WriteLine(@"|---------|-----------|    .                         | ----|-----------------|");
                                Console.WriteLine(@"|  /\/\   |           |   / \ File/Program not found!|     |                 |");
                                Console.WriteLine(@"|  \  /   | UT/DR Batt|  / ! \   Try again!          |     | 44 KB           |");
                                Console.WriteLine(@"|   \/    |           | /_____\          ____________|     |                 |");
                                Console.WriteLine(@"|---------|-----------|                 |     Ok     | ----|-----------------|");
                                Console.WriteLine(@"|  ____   |           |_________________|____________|/    |                 |");
                                Console.WriteLine(@"| |.txt|  | AboutHSTBOS.txt           | .txt file          | 6 KB            |");
                                Console.WriteLine(@"| |____|  |                           |                    |                 |");
                                Console.WriteLine(@"|---------|---------------------------|--------------------|-----------------|");
                                Console.WriteLine(@"| /#####\ |                           |                    |                 |");
                                Console.WriteLine(@"| |.exe | | HenkelSoftTextBasedOS.exe | .exe file          | 56 KB           |");
                                Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
                                Console.WriteLine(@"| S T A R T |  Stuff  |                                     01:00 01.01." + year + " |");
                                Console.WriteLine(@"|___________|_________|______________________________________________________|");
                                break;
                        }
                        break;
                    case "exit":
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| Stuff                                                            _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"|  __________                                                                |");
                        Console.WriteLine(@"|  |      | |                                                                |");
                        Console.WriteLine(@"|  |      | |  Exiting Stuff...                                              |");
                        Console.WriteLine(@"|  |      | |                                                                |");
                        Console.WriteLine(@"|  |______|_|                                                                |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                       TBOS was made " + year + " by HenkelSoft Inc.|");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T |  Stuff  |                                     01:00 01.01." + year + " |");
                        Console.WriteLine(@"|___________|_________|______________________________________________________|");
                        inStuff = false;
                        break;
                    default:
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| Stuff                                                            _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"| Icon    | Name                      | Type               | Size            |");
                        Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
                        Console.WriteLine(@"|  ___    |           /_______________________________/    |                 |");
                        Console.WriteLine(@"| | W |   | HenkelSoft| Error                        |     | 27 KB           |");
                        Console.WriteLine(@"| |___|   |           |______________________________|     |                 |");
                        Console.WriteLine(@"|---------|-----------|    .                         | ----|-----------------|");
                        Console.WriteLine(@"|  /\/\   |           |   / \    Command not found!  |     |                 |");
                        Console.WriteLine(@"|  \  /   | UT/DR Batt|  / ! \   Try again!          |     | 44 KB           |");
                        Console.WriteLine(@"|   \/    |           | /_____\          ____________|     |                 |");
                        Console.WriteLine(@"|---------|-----------|                 |     Ok     | ----|-----------------|");
                        Console.WriteLine(@"|  ____   |           |_________________|____________|/    |                 |");
                        Console.WriteLine(@"| |.txt|  | AboutHSTBOS.txt           | .txt file          | 6 KB            |");
                        Console.WriteLine(@"| |____|  |                           |                    |                 |");
                        Console.WriteLine(@"|---------|---------------------------|--------------------|-----------------|");
                        Console.WriteLine(@"| /#####\ |                           |                    |                 |");
                        Console.WriteLine(@"| |.exe | | HenkelSoftTextBasedOS.exe | .exe file          | 56 KB           |");
                        Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
                        Console.WriteLine(@"| S T A R T |  Stuff  |                                     01:00 01.01." + year + " |");
                        Console.WriteLine(@"|___________|_________|______________________________________________________|");
                        break;
                }
            }
        }
    }
}