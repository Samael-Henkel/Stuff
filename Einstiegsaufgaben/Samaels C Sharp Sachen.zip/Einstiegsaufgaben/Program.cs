﻿using System;

namespace Einstiegsaufgaben
{
    class Program
    {
        static void Main(string[] args)
        {
            string weiterwürfeln = "0";
            while(weiterwürfeln == "0") 
            {
                weiterwürfeln = Würfeln();
            }
        }

        static string Würfeln()
        {
            Console.WriteLine("Würfeln? Y = Ja, N = Nein");
            string Zusage = Console.ReadLine();
            if (Zusage == "Y" || Zusage == "y")
            {
                Random zufall = new Random();
                string Ergebnis = Convert.ToString(zufall.Next(1, 7));
                Console.WriteLine(Ergebnis);
                return "0";
            } else if (Zusage == "N" || Zusage == "n")
            {
                Console.WriteLine("Okay. Schliesse Programm...");
                return "1";
            } else
            {
                Console.WriteLine("Ungültige Eingabe. Bitte geben sie eines der Auswahlmöglichkeiten ein.");
                return "0";
            }
        }
    }
}
