﻿using System;

namespace _1_100durch3undoder5
{
    class Program
    {
        static void Main(string[] args)
        {
            einsbishundert();
        }

        static string einsbishundert()
        {
            int einsbishundert = 1;
            string ergebnis = " ";
            while (einsbishundert <= 100)
            {
                if (einsbishundert % 3 == 0 && einsbishundert % 5 == 0)
                {
                    ergebnis = "fizzbuzz";
                } else if (einsbishundert % 3 == 0)
                {
                    ergebnis = "fizz";
                } else if (einsbishundert % 5 == 0)
                {
                    ergebnis = "buzz";
                } else
                {
                    ergebnis = Convert.ToString(einsbishundert);
                    
                }
                Console.WriteLine(ergebnis);
                einsbishundert += 1;
            }
            return ergebnis;
        }
    }
}
