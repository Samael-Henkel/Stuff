﻿using System;

namespace Aguessinggame
{
    class Program
    {
        static void Main(string[] args)
        {
            ratespiel();
        }
        static string ratespiel()
        {
            int n = 0;
            while (n == 0)
            {
                Random zufall = new Random();
                Console.WriteLine("Wähle eine untere Grenze");
                int zahl1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Wähle eine Obere Grenze");
                int zahl2 = Convert.ToInt32(Console.ReadLine());
                int zufallzahl = zufall.Next(zahl1, zahl2);
                int geraten = 0;
                int versuche = 0;
                while (geraten != zufallzahl)
                {
                    Console.WriteLine("Gib eine Zahl ein.");
                    geraten = Convert.ToInt32(Console.ReadLine());
                    if (geraten < zahl1 || geraten > zahl2)
                    {
                        Console.WriteLine("Ausserhalb der angegeben Reichweite!");
                    }
                    else if (geraten > zufallzahl)
                    {
                        Console.WriteLine("Zu gross");
                        versuche++;
                    }
                    else if (geraten < zufallzahl)
                    {
                        Console.WriteLine("Zu klein");
                        versuche++;
                    }
                }
                Console.WriteLine("Nach " + versuche + " Versuchen richtig geraten! " +
                    "Nochmal spielen? [Y/N]");
                string best = Console.ReadLine();
                if (best == "N" || best == "n")
                {
                    n = 1;
                }
                else if (best == "Y" || best == "y")
                {
                    n = 0;
                }
            }
            return "0";
        }
    }
}
