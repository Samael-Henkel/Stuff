﻿using System;

namespace telephonegame
{
    class Program
    {
        static void Main(string[] args)
        {
            string vokale = "aeiou";
            string konsonanten = "bcdfghjklmnpqrstvwxyz";
            string vokaleGross = "AEIOU";
            string konsonantenGross = "BCDFGHJKLMNPQRSTVWXYZ";
            int spieler = 0;
            int unterschiede = 0;
            string ursprungssatz = " ";
            bool stop = false;
            while(stop == false)
            {
                Console.Write("Wie viele Spieler gibt es? ");
                spieler = Convert.ToInt32(Console.ReadLine());
                Console.Write("Auf einer Skala von 1-5, wie schlecht hören die Spieler? ");
                unterschiede = Convert.ToInt32(Console.ReadLine());
                Console.Write("Wie lautet der Anfangssatz? ");
                ursprungssatz = Convert.ToString(Console.ReadLine());
                Random rng = new Random();
                for (int i = 1; i <= spieler; i++)
                {
                    for (int j = 1; j <= unterschiede; j++)
                    {
                        int change = 0;
                        while (change == 0)
                        {

                            int randomNumberGeneration1 = rng.Next(ursprungssatz.Length);
                            int randomNumberGeneration2 = rng.Next(vokale.Length);
                            int randomNumberGeneration3 = rng.Next(konsonanten.Length);
                            string ersatz = "";
                            int nachDemErsatz1 = randomNumberGeneration1 + 1;
                            int nachDemErsatz2 = ursprungssatz.Length - randomNumberGeneration1 - 1;
                            if (vokale.Contains(ursprungssatz.Substring(randomNumberGeneration1, 1)))
                            {
                                ersatz = vokale.Substring(randomNumberGeneration2, 1);
                                string neuerSatz = ursprungssatz.Substring(0, randomNumberGeneration1) + ersatz + ursprungssatz.Substring(nachDemErsatz1, nachDemErsatz2);
                                ursprungssatz = neuerSatz;
                                change = 1;
                            }
                            else if (konsonanten.Contains(ursprungssatz.Substring(randomNumberGeneration1, 1)))
                            {
                                ersatz = konsonanten.Substring(randomNumberGeneration3, 1);
                                string neuerSatz = ursprungssatz.Substring(0, randomNumberGeneration1) + ersatz + ursprungssatz.Substring(nachDemErsatz1, nachDemErsatz2);
                                ursprungssatz = neuerSatz;
                                change = 1;
                            }
                            else if (vokaleGross.Contains(ursprungssatz.Substring(randomNumberGeneration1, 1)))
                            {
                                ersatz = vokaleGross.Substring(randomNumberGeneration2, 1);
                                string neuerSatz = ursprungssatz.Substring(0, randomNumberGeneration1) + ersatz + ursprungssatz.Substring(nachDemErsatz1, nachDemErsatz2);
                                ursprungssatz = neuerSatz;
                                change = 1;
                            }
                            else if (konsonantenGross.Contains(ursprungssatz.Substring(randomNumberGeneration1, 1)))
                            {
                                ersatz = konsonantenGross.Substring(randomNumberGeneration3, 1);
                                string neuerSatz = ursprungssatz.Substring(0, randomNumberGeneration1) + ersatz + ursprungssatz.Substring(nachDemErsatz1, nachDemErsatz2);
                                ursprungssatz = neuerSatz;
                                change = 1;
                            }
                            else
                            {
                                change = 0;
                            }
                        }
                    }
                    Console.WriteLine("Spieler " + i + " sagt: " + ursprungssatz);
                }
                string YesNo = "";
                while (YesNo != "Y" && YesNo != "N")
                {
                    Console.WriteLine("Weitermachen? [Y/N]");
                    YesNo = Console.ReadLine();
                    if (YesNo == "Y")
                    {
                        stop = false;
                    } else if (YesNo == "N")
                    {
                        stop = true;
                    } else
                    {
                        Console.WriteLine("Ungültige Eingabe!");
                    }
                }
            }
        }
    }
}
