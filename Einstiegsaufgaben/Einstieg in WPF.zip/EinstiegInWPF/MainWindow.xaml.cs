﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EinstiegInWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        void changeLabelText(object sender, RoutedEventArgs e)
        {
            string AllTheCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
            Random random = new Random();
            var list1 = Enumerable.Repeat(0, 8).Select(x => AllTheCharacters[random.Next(AllTheCharacters.Length)]);
            var list2 = Enumerable.Repeat(0, 8).Select(x => AllTheCharacters[random.Next(AllTheCharacters.Length)]);
            Text.Content = string.Join("", list1);
            if(Convert.ToString(Text2.Visibility) == "Visible")
            {
                Text2.Content = string.Join("", list2);
            }
        }
        void newButtonAndLabel(object sender, RoutedEventArgs e)
        {
            if(Convert.ToString(TheButton4.Visibility) == "Hidden")
            {
                TheButton4.Visibility = TheButton3.Visibility;
                TheButton5.Visibility = TheButton3.Visibility;
                TheButton6.Visibility = TheButton3.Visibility;
                Text2.Visibility = TheButton3.Visibility;
                TheButton3.Content = "Entfernen von Label und Button";
                TheButton6.Content = "Entfernen von Label und Button";
            } else if (Convert.ToString(TheButton4.Visibility) == "Visible")
            {
                TheButton4.Visibility = AlwaysInvis.Visibility;
                TheButton5.Visibility = AlwaysInvis.Visibility;
                TheButton6.Visibility = AlwaysInvis.Visibility;
                Text2.Visibility = AlwaysInvis.Visibility;
                TheButton3.Content = "Hinzufügen von Label und Button";
                TheButton3.Content = "Hinzufügen von Label und Button";
            } else
            {
                TheButton4.Visibility = TheButton3.Visibility;
                TheButton5.Visibility = TheButton3.Visibility;
                TheButton6.Visibility = TheButton3.Visibility;
                Text2.Visibility = TheButton3.Visibility;
                TheButton3.Content = "Entfernen von Label und Button";
                TheButton6.Content = "Entfernen von Label und Button";
            }
        }
        void changeColors(object sender, RoutedEventArgs e)
        {
            Random r = new Random();
            Brush brush1 = new SolidColorBrush(Color.FromRgb((byte)r.Next(1, 255), (byte)r.Next(1, 255), (byte)r.Next(1, 255)));
            Brush brush2 = new SolidColorBrush(Color.FromRgb((byte)r.Next(1, 255), (byte)r.Next(1, 255), (byte)r.Next(1, 255)));
            Brush brush3 = new SolidColorBrush(Color.FromRgb((byte)r.Next(1, 255), (byte)r.Next(1, 255), (byte)r.Next(1, 255)));
            Brush brush4 = new SolidColorBrush(Color.FromRgb((byte)r.Next(1, 255), (byte)r.Next(1, 255), (byte)r.Next(1, 255)));
            Brush brush5 = new SolidColorBrush(Color.FromRgb((byte)r.Next(1, 255), (byte)r.Next(1, 255), (byte)r.Next(1, 255)));
            Brush brush6 = new SolidColorBrush(Color.FromRgb((byte)r.Next(1, 255), (byte)r.Next(1, 255), (byte)r.Next(1, 255)));
            Brush brush7 = new SolidColorBrush(Color.FromRgb((byte)r.Next(1, 255), (byte)r.Next(1, 255), (byte)r.Next(1, 255)));
            Brush brush8 = new SolidColorBrush(Color.FromRgb((byte)r.Next(1, 255), (byte)r.Next(1, 255), (byte)r.Next(1, 255)));
            TheButton1.Background = brush1;
            TheButton2.Background = brush2;
            TheButton3.Background = brush3;
            Text.Background = brush4;
            TheButton4.Background = brush5;
            TheButton5.Background = brush6;
            TheButton6.Background = brush7;
            Text2.Background = brush8;

        }
    }
}
