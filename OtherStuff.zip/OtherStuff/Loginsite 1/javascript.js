let eins = 1
let zwei = 2
function add(eins, zwei){
    return eins + zwei
}
let x = add
alert(x)