using System;
using System.Threading;
using System.IO;
using StuffFolder;
using DieSammlungFolder;

namespace HenkelSoftTextBasedOS
{
    class HenkelSoftTextBasedOperatingSystem
    {
        static readonly Random random = new();
        static int Year = random.Next(1975, 1998);
        private static Timer timer = null;
        static bool login = false;
        static bool turnoff = false;
        static readonly Stuff stuff = new();
        static readonly Die_Sammlung_Folder dieSammlung = new();
        public void TBOS()
        {
            Start();
            Login();
            if (login)
            {
                Logic();
            }
        }
        static string name;
        static string currentdir;
        static void Start()
        {
            Console.Write("Starting Up systems.");
            timer = new Timer(loading, null, 0, 250);
            Thread.Sleep(2500);
            timer.Dispose();
            Console.WriteLine("Done!");
            Console.Write("Loading HenkelSoft TBOS");
            timer = new Timer(loading, null, 0, 500);
            Thread.Sleep(5000);
            timer.Dispose();
            Console.WriteLine("Loading Finished!");
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("HenkelSoft");
            Console.WriteLine(@" _______        _   ____                     _  ____                       _   _              _____           _                 ");
            Console.WriteLine(@"|__   __|      | | |  _ \                   | |/ __ \                     | | (_)            / ____|         | |                ");
            Console.WriteLine(@"   | | _____  _| |_| |_) | __ _ ___  ___  __| | |  | |_ __   ___ _ __ __ _| |_ _ _ __   __ _| (___  _   _ ___| |_ ___ _ __ ___  ");
            Console.WriteLine(@"   | |/ _ \ \/ / __|  _ < / _` / __|/ _ \/ _` | |  | | '_ \ / _ \ '__/ _` | __| | '_ \ / _` |\___ \| | | / __| __/ _ \ '_ ` _ \ ");
            Console.WriteLine(@"   | |  __/>  <| |_| |_) | (_| \__ \  __/ (_| | |__| | |_) |  __/ | | (_| | |_| | | | | (_| |____) | |_| \__ \ ||  __/ | | | | |");
            Console.WriteLine(@"   |_|\___/_/\_\\__|____/ \__,_|___/\___|\__,_|\____/| .__/ \___|_|  \__,_|\__|_|_| |_|\__, |_____/ \__, |___/\__\___|_| |_| |_|");
            Console.WriteLine(@"                                                     | |                                __/ |        __/ |                      ");
            Console.WriteLine(@"                                                     |_|                               |___/        |___/                       ");
            Console.WriteLine("                                                                    Original by HenkelSoft Studios " + Year + ", remade by Samael Henkel");
            Console.WriteLine("");
        }
        static void Login()
        {
            bool UserExists = false;
            while (UserExists == false)
            {
                string password = "";
                string correctpass;
                Console.WriteLine("Select User:");
                name = Console.ReadLine();
                currentdir = Directory.GetCurrentDirectory();
                if (File.Exists(currentdir + @"/Users/" + name + ".txt"))
                {
                    UserExists = true;
                    int attempts = 0;
                    correctpass = File.ReadAllText(currentdir + @"/Passwords/" + name + ".txt");
                    while (password != correctpass && attempts <= 3)
                    {
                        Console.WriteLine("Enter Password for " + name);
                        password = Console.ReadLine();
                        if (password != correctpass)
                        {
                            Console.WriteLine("Incorrect! Try again");
                            attempts++;
                        }
                    }
                    if (password == correctpass)
                    {
                        name = File.ReadAllText(currentdir + @"/Users/" + name + ".txt");
                        Console.Write("Logging in as " + name + ".");
                        timer = new Timer(loading, null, 0, 250);
                        Thread.Sleep(2000);
                        timer.Dispose();
                        login = true;
                        desktop();
                    }
                    else if (attempts > 3)
                    {
                        Console.Write("Too many attempts! Shutting down.");
                        timer = new Timer(loading, null, 0, 250);
                        Thread.Sleep(2000);
                        timer.Dispose();
                    }
                }
                else
                {
                    Console.WriteLine("User not Found");
                }
            }
        }
        private static void loading(Object o)
        {
            Console.Write(".");
        }
        static void Logic()
        {
            desktop();
            string toDo;
            while (!turnoff && login)
            {
                Console.Write("What do you do?:");
                toDo = Console.ReadLine();
                switch (toDo)
                {
                    case "logoff":
                        login = false;
                        Year = random.Next(1975, 1998);
                        Login();
                        break;
                    case "turnoff":
                        turnoff = true;
                        break;
                    case "desktop":
                        desktop();
                        break;
                    case "settings":
                        Year = random.Next(1975, 1998);
                        settings();
                        break;
                    case "stuff":
                        Year = random.Next(1975, 1998);
                        stuff.OpenStuff(Year);
                        break;
                    case "DieSammlung":
                        Year = random.Next(1975, 1998);
                        dieSammlung.OpenFolder(Year);
                        break;
                    case "trash can":
                        Year = random.Next(1975, 1998);
                        bin();
                        break;
                    case "help":
                        Console.WriteLine();
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"|  __________    __________                                                  |");
                        Console.WriteLine(@"|  \ \    / /    |      | |                                                  |");
                        Console.WriteLine(@"|   \ \__/ /     |      | |                                                  |");
                        Console.WriteLine(@"|    \/__\/      |      | |                                                  |");
                        Console.WriteLine(@"|  Trash Can     |___/_______________________________/                       |");
                        Console.WriteLine(@"|  __________    DieS| Help                     | X |                        |");
                        Console.WriteLine(@"|  |      | |        |__________________________|___|                        |");
                        Console.WriteLine(@"|  |      | |        | logoff - Log off currentUser |                        |");
                        Console.WriteLine(@"|  |      | |        | turnoff - shuts down Every-  |                        |");
                        Console.WriteLine(@"|  |______|_|        | thing                        |                        |");
                        Console.WriteLine(@"|     Stuff          | desktop - Shows empty Desktop|                        |");
                        Console.WriteLine(@"|      _             | help - Shows this Box        |                        |");
                        Console.WriteLine(@"|   /\| |/\          |______________________________|/                       |");
                        Console.WriteLine(@"|  _\     /_                                                                 |");
                        Console.WriteLine(@"| |_   O   _|                                                                |");
                        Console.WriteLine(@"|   /     \                                                                  |");
                        Console.WriteLine(@"|   \/|_|\/                                                                  |");
                        Console.WriteLine(@"|   Settings                                                                 |");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T |                                               01:00 01.01." + Year + " |");
                        Console.WriteLine(@"|___________|________________________________________________________________|");
                        break;
                    case "Is there a secret":
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| Generic Video Platform                                           _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"|                                                                          G |");
                        Console.WriteLine(@"|   (|>) Generic [Video Platform] [rick roll           ]                   o |");
                        Console.WriteLine(@"|  _____________________________________________                           T |");
                        Console.WriteLine(@"|  |                    |                      |                           o |");
                        Console.WriteLine(@"|  |                    |                      |                           ' |");
                        Console.WriteLine(@"|  |                    |                      |                           D |");
                        Console.WriteLine(@"|  |                  __|___                   |                           i |");
                        Console.WriteLine(@"|  |                 |______|                  |                           e |");
                        Console.WriteLine(@"|  |                 | o  o |                  |                           S |");
                        Console.WriteLine(@"|  |                 |_----_|                  |                           a |");
                        Console.WriteLine(@"|  |               ____|()|____                |                           m |");
                        Console.WriteLine(@"|  |______________| __ \||/ __ |_______________|                           m |");
                        Console.WriteLine(@"|  |              | ||  ||  || |               |                           l |");
                        Console.WriteLine(@"|  |______________|_||__||__||_|_______________|                           u |");
                        Console.WriteLine(@"|   Rick Astley - Never gonna give you up                                  n |");
                        Console.WriteLine(@"|   1 billion views - 123 mil likes - 23 mil dislikes                      g |");
                        Console.WriteLine(@"|__________________________________________________________________________'_|");
                        Console.WriteLine(@"| S T A R T | Googolplex |                                  01:00 01.01." + Year + " |");
                        Console.WriteLine(@"|___________|____________|___________________________________________________|");
                        Console.WriteLine("Yes, this one");
                        break;
                    default:
                        Console.WriteLine();
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"|  __________    __________                                                  |");
                        Console.WriteLine(@"|  \ \    / /    |      | |                                                  |");
                        Console.WriteLine(@"|   \ \__/ /     |      | |                                                  |");
                        Console.WriteLine(@"|    \/__\/      |      | |                                                  |");
                        Console.WriteLine(@"|  Trash Can     |___/_______________________________/                       |");
                        Console.WriteLine(@"|  __________    DieS| Error                    | X |                        |");
                        Console.WriteLine(@"|  |      | |        |__________________________|___|                        |");
                        Console.WriteLine(@"|  |      | |        |    .                         |                        |");
                        Console.WriteLine(@"|  |      | |        |   / \    Command not found   |                        |");
                        Console.WriteLine(@"|  |______|_|        |  / ! \     Try again!        |                        |");
                        Console.WriteLine(@"|     Stuff          | /_____\          ____________|                        |");
                        Console.WriteLine(@"|      _             |                 |     Ok     |                        |");
                        Console.WriteLine(@"|   /\| |/\          |_________________|____________|/                       |");
                        Console.WriteLine(@"|  _\     /_                                                                 |");
                        Console.WriteLine(@"| |_   O   _|                                                                |");
                        Console.WriteLine(@"|   /     \                                                                  |");
                        Console.WriteLine(@"|   \/|_|\/                                                                  |");
                        Console.WriteLine(@"|   Settings                                                                 |");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T |                                               01:00 01.01." + Year + " |");
                        Console.WriteLine(@"|___________|________________________________________________________________|");
                        break;
                }
            }
        }
        static void desktop()
        {
            Console.WriteLine();
            Console.WriteLine(@"______________________________________________________________________________");
            Console.WriteLine(@"|  __________    __________                                                  |");
            Console.WriteLine(@"|  \ \    / /    |      | |                                                  |");
            Console.WriteLine(@"|   \ \__/ /     |      | |                                                  |");
            Console.WriteLine(@"|    \/__\/      |      | |                                                  |");
            Console.WriteLine(@"|  Trash Can     |______|_|                                                  |");
            Console.WriteLine(@"|  __________    DieSammlung                                                 |");
            Console.WriteLine(@"|  |      | |                                                                |");
            Console.WriteLine(@"|  |      | |                                                                |");
            Console.WriteLine(@"|  |      | |                                                                |");
            Console.WriteLine(@"|  |______|_|                                                                |");
            Console.WriteLine(@"|     Stuff                                                                  |");
            Console.WriteLine(@"|      _                                                                     |");
            Console.WriteLine(@"|   /\| |/\                                                                  |");
            Console.WriteLine(@"|  _\     /_                                                                 |");
            Console.WriteLine(@"| |_   O   _|                                                                |");
            Console.WriteLine(@"|   /     \                                                                  |");
            Console.WriteLine(@"|   \/|_|\/                                                                  |");
            Console.WriteLine(@"|   Settings                                                                 |");
            Console.WriteLine(@"|____________________________________________________________________________|");
            Console.WriteLine(@"| S T A R T |                                               01:00 01.01." + Year + " |");
            Console.WriteLine(@"|___________|________________________________________________________________|");
        }
        static void bin()
        {
            bool inBin = true;
            string toDo;
            Console.WriteLine(@"______________________________________________________________________________");
            Console.WriteLine(@"| Trash Can                                                        _   8 | X |");
            Console.WriteLine(@"|________________________________________________________________________|___|");
            Console.WriteLine(@"| Icon    | Name                      | Type               | Size            |");
            Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|       O                                                                    |");
            Console.WriteLine(@"|      /|7  'Trash Can' is empty                                             |");
            Console.WriteLine(@"|   _ //\                                                                    |");
            Console.WriteLine(@"|    /|                                                                      |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|____________________________________________________________________________|");
            Console.WriteLine(@"| S T A R T | Trash Can |                                   01:00 01.01." + Year + " |");
            Console.WriteLine(@"|___________|___________|____________________________________________________|");
            while (inBin == true)
            {
                Console.Write("What do you want to do? (Enter help for help):");
                toDo = Console.ReadLine();
                switch (toDo)
                {
                    case "help":
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| Trash Can                                                        _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"|  __________                                                                |");
                        Console.WriteLine(@"|  \ \    / /                                                                |");
                        Console.WriteLine(@"|   \ \__/ /   Trash Can - Abfalleimer                                       |");
                        Console.WriteLine(@"|    \/__\/                                                                  |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|  open - open a Program/File                                                |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|  view - view the Contents of this folder                                   |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|  exit - leave the folder                                                   |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|  help - show this list                                                     |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                       TBOS was made " + Year + " by HenkelSoft Inc.|");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T | Trash Can |                                   01:00 01.01." + Year + " |");
                        Console.WriteLine(@"|___________|___________|____________________________________________________|");
                        break;
                    case "view":
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| Trash Can                                                        _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"| Icon    | Name                      | Type               | Size            |");
                        Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|       O                                                                    |");
                        Console.WriteLine(@"|      /|7  'Trash Can' is empty                                             |");
                        Console.WriteLine(@"|   _ //\                                                                    |");
                        Console.WriteLine(@"|    /|                                                                      |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T | Trash Can |                                   01:00 01.01." + Year + " |");
                        Console.WriteLine(@"|___________|___________|____________________________________________________|");
                        break;
                    case "open":
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| Trash Can                                                        _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"| Icon    | Name                      | Type               | Size            |");
                        Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
                        Console.WriteLine(@"|                  /_______________________________/                         |");
                        Console.WriteLine(@"|       O          | Error                        |                          |");
                        Console.WriteLine(@"|      /|7  'Trash |______________________________|                          |");
                        Console.WriteLine(@"|   _ //\          |    .                         |                          |");
                        Console.WriteLine(@"|    /|            |   / \    There is nothing to |                          |");
                        Console.WriteLine(@"|                  |  / ! \   open!               |                          |");
                        Console.WriteLine(@"|                  | /_____\          ____________|                          |");
                        Console.WriteLine(@"|                  |                 |     Ok     |                          |");
                        Console.WriteLine(@"|                  |_________________|____________|/                         |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T | Trash Can |                                   01:00 01.01." + Year + " |");
                        Console.WriteLine(@"|___________|___________|____________________________________________________|");
                        break;
                    case "is there a secret":
                        if (name.ToLower() != "admin")
                        {
                            Console.WriteLine(@"______________________________________________________________________________");
                            Console.WriteLine(@"| Trash Can                                                        _   8 | X |");
                            Console.WriteLine(@"|________________________________________________________________________|___|");
                            Console.WriteLine(@"| Icon    | Name                      | Type               | Size            |");
                            Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
                            Console.WriteLine(@"|                  /_______________________________/                         |");
                            Console.WriteLine(@"|       O          | No Secrets 4 you lol         |                          |");
                            Console.WriteLine(@"|      /|7  'Trash |______________________________|                          |");
                            Console.WriteLine(@"|   _ //\          |    .                         |                          |");
                            Console.WriteLine(@"|    /|            |   / \   There is no Secret...|                          |");
                            Console.WriteLine(@"|                  |  / ! \   ...on this account! |                          |");
                            Console.WriteLine(@"|                  | /_____\          ____________|                          |");
                            Console.WriteLine(@"|                  |                 |     Ok     |                          |");
                            Console.WriteLine(@"|                  |_________________|____________|/                         |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|____________________________________________________________________________|");
                            Console.WriteLine(@"| S T A R T | Trash Can |                                   01:00 01.01." + Year + " |");
                            Console.WriteLine(@"|___________|___________|____________________________________________________|");
                        }
                        else
                        {
                            Console.WriteLine(@"______________________________________________________________________________");
                            Console.WriteLine(@"| Trash Can                                                        _   8 | X |");
                            Console.WriteLine(@"|________________________________________________________________________|___|");
                            Console.WriteLine(@"| Icon    | Name                      | Type               | Size            |");
                            Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
                            Console.WriteLine(@"|                  /_______________________________/                         |");
                            Console.WriteLine(@"|       O          | Secret                       |                          |");
                            Console.WriteLine(@"|      /|7  'Trash |______________________________|                          |");
                            Console.WriteLine(@"|   _ //\          |    .                         |                          |");
                            Console.WriteLine(@"|    /|            |   / \    Yes, there is!      |                          |");
                            Console.WriteLine(@"|                  |  / ! \   Just enter your Name|                          |");
                            Console.WriteLine(@"|                  | /_____\          ____________|                          |");
                            Console.WriteLine(@"|                  |                 |     Ok     |                          |");
                            Console.WriteLine(@"|                  |_________________|____________|/                         |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|____________________________________________________________________________|");
                            Console.WriteLine(@"| S T A R T | Trash Can |                                   01:00 01.01." + Year + " |");
                            Console.WriteLine(@"|___________|___________|____________________________________________________|");
                        }
                        break;
                    case "admin":
                        if (name.ToLower() == "admin")
                        {
                            Console.WriteLine(@"______________________________________________________________________________");
                            Console.WriteLine(@"| Trash Can                                                        _   8 | X |");
                            Console.WriteLine(@"|________________________________________________________________________|___|");
                            Console.WriteLine(@"|  __________                                                                |");
                            Console.WriteLine(@"|  \ \    / /                                                                |");
                            Console.WriteLine(@"|   \ \__/ /   Enter your Password...                                        |");
                            Console.WriteLine(@"|    \/__\/                                                                  |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                       TBOS was made " + Year + " by HenkelSoft Inc.|");
                            Console.WriteLine(@"|____________________________________________________________________________|");
                            Console.WriteLine(@"| S T A R T | Trash Can |                                   01:00 01.01." + Year + " |");
                            Console.WriteLine(@"|___________|___________|____________________________________________________|");
                            string password = Console.ReadLine();
                            if (password == "Password")
                            {
                                Console.WriteLine(@"______________________________________________________________________________");
                                Console.WriteLine(@"| Entry                                                            _   8 | X |");
                                Console.WriteLine(@"|________________________________________________________________________|___|");
                                Console.WriteLine(@"|  __________                                                                |");
                                Console.WriteLine(@"|  \ \    / /                                                                |");
                                Console.WriteLine(@"|   \ \__/ /   ENTRY NUMBER 1:                                               |");
                                Console.WriteLine(@"|    \/__\/    I just started my PC and loaded this old Program. It looks ab-|");
                                Console.WriteLine(@"|              solutly like crap, and im sure it isnt intentionally like this|");
                                Console.WriteLine(@"|              Im gonna make a better version of this in my spare time and...|");
                                Console.WriteLine(@"|              [END OF DOCUMENT]                                             |");
                                Console.WriteLine(@"|              Username: SaHe                                                |");
                                Console.WriteLine(@"|              Password: SaHe2006                                            |");
                                Console.WriteLine(@"|              Filename: SecretFolder\NotSecretAnymore                       |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                       TBOS was made " + Year + " by HenkelSoft Inc.|");
                                Console.WriteLine(@"|____________________________________________________________________________|");
                                Console.WriteLine(@"| S T A R T |   Entry   |                                   01:00 01.01." + Year + " |");
                                Console.WriteLine(@"|___________|___________|____________________________________________________|");
                            }
                            else
                            {
                                Console.WriteLine(@"______________________________________________________________________________");
                                Console.WriteLine(@"| Trash Can                                                        _   8 | X |");
                                Console.WriteLine(@"|________________________________________________________________________|___|");
                                Console.WriteLine(@"|  __________                                                                |");
                                Console.WriteLine(@"|  \ \    / /                                                                |");
                                Console.WriteLine(@"|   \ \__/ /   Wrong Password! Please try again...                           |");
                                Console.WriteLine(@"|    \/__\/                                                                  |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                       TBOS was made " + Year + " by HenkelSoft Inc.|");
                                Console.WriteLine(@"|____________________________________________________________________________|");
                                Console.WriteLine(@"| S T A R T | Trash Can |                                   01:00 01.01." + Year + " |");
                                Console.WriteLine(@"|___________|___________|____________________________________________________|");
                            }
                        }
                        else
                        {
                            Console.WriteLine(@"______________________________________________________________________________");
                            Console.WriteLine(@"| Trash Can                                                        _   8 | X |");
                            Console.WriteLine(@"|________________________________________________________________________|___|");
                            Console.WriteLine(@"| Icon    | Name                      | Type               | Size            |");
                            Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
                            Console.WriteLine(@"|                  /_______________________________/                         |");
                            Console.WriteLine(@"|       O          | Err0r                        |                          |");
                            Console.WriteLine(@"|      /|7  'Trash |______________________________|                          |");
                            Console.WriteLine(@"|   _ //\          |    .                         |                          |");
                            Console.WriteLine(@"|    /|            |   / \    Command not found!  |                          |");
                            Console.WriteLine(@"|                  |  / ! \   Try again!          |                          |");
                            Console.WriteLine(@"|                  | /_____\          ____________|                          |");
                            Console.WriteLine(@"|                  |                 |     Ok     |                          |");
                            Console.WriteLine(@"|                  |_________________|____________|/                         |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|____________________________________________________________________________|");
                            Console.WriteLine(@"| S T A R T | Trash Can |                                   01:00 01.01." + Year + " |");
                            Console.WriteLine(@"|___________|___________|____________________________________________________|");
                        }
                        break;
                    case "exit":
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| Trash Can                                                        _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"|  __________                                                                |");
                        Console.WriteLine(@"|  \ \    / /                                                                |");
                        Console.WriteLine(@"|   \ \__/ /   Exiting Trash Can...                                          |");
                        Console.WriteLine(@"|    \/__\/                                                                  |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                       TBOS was made " + Year + " by HenkelSoft Inc.|");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T | Trash Can |                                   01:00 01.01." + Year + " |");
                        Console.WriteLine(@"|___________|___________|____________________________________________________|");
                        inBin = false;
                        break;
                    default:
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| Trash Can                                                        _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"| Icon    | Name                      | Type               | Size            |");
                        Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
                        Console.WriteLine(@"|                  /_______________________________/                         |");
                        Console.WriteLine(@"|       O          | Error                        |                          |");
                        Console.WriteLine(@"|      /|7  'Trash |______________________________|                          |");
                        Console.WriteLine(@"|   _ //\          |    .                         |                          |");
                        Console.WriteLine(@"|    /|            |   / \    Command not found!  |                          |");
                        Console.WriteLine(@"|                  |  / ! \   Try again!          |                          |");
                        Console.WriteLine(@"|                  | /_____\          ____________|                          |");
                        Console.WriteLine(@"|                  |                 |     Ok     |                          |");
                        Console.WriteLine(@"|                  |_________________|____________|/                         |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T | Trash Can |                                   01:00 01.01." + Year + " |");
                        Console.WriteLine(@"|___________|___________|____________________________________________________|");
                        break;
                }
            }
        }
        static void settings()
        {
            bool inSettings = true;
            string toDo;
            Console.WriteLine(@"______________________________________________________________________________");
            Console.WriteLine(@"| Settings                                                         _   8 | X |");
            Console.WriteLine(@"|________________________________________________________________________|___|");
            Console.WriteLine(@"|      _                                                                     |");
            Console.WriteLine(@"|   /\| |/\                                                                  |");
            Console.WriteLine(@"|  _\     /_                                                                 |");
            Console.WriteLine(@"| |_   O   _|   Welcome to Settings.                                         |");
            Console.WriteLine(@"|   /     \                                                                  |");
            Console.WriteLine(@"|   \/|_|\/                                                                  |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                       TBOS was made " + Year + " by HenkelSoft Inc.|");
            Console.WriteLine(@"|____________________________________________________________________________|");
            Console.WriteLine(@"| S T A R T | Settings |                                    01:00 01.01." + Year + " |");
            Console.WriteLine(@"|___________|__________|_____________________________________________________|");
            while (inSettings)
            {
                string AccountName;
                Console.Write("What do you want to do? (Enter help for list of Settings):");
                toDo = Console.ReadLine();
                switch (toDo)
                {
                    case "help":
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| Settings                                                         _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"|      _                                                                     |");
                        Console.WriteLine(@"|   /\| |/\                                                                  |");
                        Console.WriteLine(@"|  _\     /_                                                                 |");
                        Console.WriteLine(@"| |_   O   _|   Welcome to Settings.                                         |");
                        Console.WriteLine(@"|   /     \                                                                  |");
                        Console.WriteLine(@"|   \/|_|\/                                                                  |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|  newAccount - creates a new Account                                        |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|  changePass - changes Password for Account                                 |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|  deleteAccount - deletes Account                                           |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|  help - brings up this window                                              |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|  exit - leaves settings               TBOS was made " + Year + " by HenkelSoft Inc.|");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T | Settings |                                    01:00 01.01." + Year + " |");
                        Console.WriteLine(@"|___________|__________|_____________________________________________________|");
                        break;
                    case "exit":
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| Settings                                                         _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"|      _                                                                     |");
                        Console.WriteLine(@"|   /\| |/\                                                                  |");
                        Console.WriteLine(@"|  _\     /_                                                                 |");
                        Console.WriteLine(@"| |_   O   _|   Quitting Settings...                                         |");
                        Console.WriteLine(@"|   /     \                                                                  |");
                        Console.WriteLine(@"|   \/|_|\/                                                                  |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                       TBOS was made " + Year + " by HenkelSoft Inc.|");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T | Settings |                                    01:00 01.01." + Year + " |");
                        Console.WriteLine(@"|___________|__________|_____________________________________________________|");
                        inSettings = false;
                        break;
                    case "newAccount":
                        if (name.ToLower() == "admin")
                        {
                            Console.WriteLine(@"______________________________________________________________________________");
                            Console.WriteLine(@"| Settings                                                         _   8 | X |");
                            Console.WriteLine(@"|________________________________________________________________________|___|");
                            Console.WriteLine(@"|      _                                                                     |");
                            Console.WriteLine(@"|   /\| |/\                                                                  |");
                            Console.WriteLine(@"|  _\     /_                                                                 |");
                            Console.WriteLine(@"| |_   O   _|   Pick a Name for the new Account:                             |");
                            Console.WriteLine(@"|   /     \                                                                  |");
                            Console.WriteLine(@"|   \/|_|\/                                                                  |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                       TBOS was made " + Year + " by HenkelSoft Inc.|");
                            Console.WriteLine(@"|____________________________________________________________________________|");
                            Console.WriteLine(@"| S T A R T | Settings |                                    01:00 01.01." + Year + " |");
                            Console.WriteLine(@"|___________|__________|_____________________________________________________|");
                            AccountName = Console.ReadLine();
                            File.WriteAllText(@"Z:\HenkelSoftTextBasedOS\HenkelSoftTextBasedOS\bin\Debug\net5.0\Users\" + AccountName + ".txt", AccountName);
                            Console.WriteLine(@"______________________________________________________________________________");
                            Console.WriteLine(@"| Settings                                                         _   8 | X |");
                            Console.WriteLine(@"|________________________________________________________________________|___|");
                            Console.WriteLine(@"|      _                                                                     |");
                            Console.WriteLine(@"|   /\| |/\                                                                  |");
                            Console.WriteLine(@"|  _\     /_                                                                 |");
                            Console.WriteLine(@"| |_   O   _|   Choose a Password for the new Account:                       |");
                            Console.WriteLine(@"|   /     \                                                                  |");
                            Console.WriteLine(@"|   \/|_|\/                                                                  |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                       TBOS was made " + Year + " by HenkelSoft Inc.|");
                            Console.WriteLine(@"|____________________________________________________________________________|");
                            Console.WriteLine(@"| S T A R T | Settings |                                    01:00 01.01." + Year + " |");
                            Console.WriteLine(@"|___________|__________|_____________________________________________________|");
                            string Password = Console.ReadLine();
                            File.WriteAllText(@"Z:\HenkelSoftTextBasedOS\HenkelSoftTextBasedOS\bin\Debug\net5.0\Passwords\" + AccountName + ".txt", Password);
                            Console.WriteLine(@"______________________________________________________________________________");
                            Console.WriteLine(@"| Settings                                                         _   8 | X |");
                            Console.WriteLine(@"|________________________________________________________________________|___|");
                            Console.WriteLine(@"|      _                                                                     |");
                            Console.WriteLine(@"|   /\| |/\                                                                  |");
                            Console.WriteLine(@"|  _\     /_                                                                 |");
                            Console.WriteLine(@"| |_   O   _|   New Account created: Log off to use it.                      |");
                            Console.WriteLine(@"|   /     \                                                                  |");
                            Console.WriteLine(@"|   \/|_|\/                                                                  |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                       TBOS was made " + Year + " by HenkelSoft Inc.|");
                            Console.WriteLine(@"|____________________________________________________________________________|");
                            Console.WriteLine(@"| S T A R T | Settings |                                    01:00 01.01." + Year + " |");
                            Console.WriteLine(@"|___________|__________|_____________________________________________________|");
                        }
                        else
                        {
                            Console.WriteLine(@"______________________________________________________________________________");
                            Console.WriteLine(@"| Settings                                                         _   8 | X |");
                            Console.WriteLine(@"|________________________________________________________________________|___|");
                            Console.WriteLine(@"|      _                                                                     |");
                            Console.WriteLine(@"|   /\| |/\                                                                  |");
                            Console.WriteLine(@"|  _\     /_                                                                 |");
                            Console.WriteLine(@"| |_   O   _|   You cannot create an account without being an Administrator! |");
                            Console.WriteLine(@"|   /     \                                                                  |");
                            Console.WriteLine(@"|   \/|_|\/                                                                  |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                       TBOS was made " + Year + " by HenkelSoft Inc.|");
                            Console.WriteLine(@"|____________________________________________________________________________|");
                            Console.WriteLine(@"| S T A R T | Settings |                                    01:00 01.01." + Year + " |");
                            Console.WriteLine(@"|___________|__________|_____________________________________________________|");
                        }
                        break;
                    case "deleteAccount":
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| Settings                                                         _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"|      _                                                                     |");
                        Console.WriteLine(@"|   /\| |/\                                                                  |");
                        Console.WriteLine(@"|  _\     /_                                                                 |");
                        Console.WriteLine(@"| |_   O   _|   Pick a Account to delete:                                    |");
                        Console.WriteLine(@"|   /     \                                                                  |");
                        Console.WriteLine(@"|   \/|_|\/                                                                  |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                       TBOS was made " + Year + " by HenkelSoft Inc.|");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T | Settings |                                    01:00 01.01." + Year + " |");
                        Console.WriteLine(@"|___________|__________|_____________________________________________________|");
                        AccountName = Console.ReadLine();
                        if (AccountName == name)
                        {
                            Console.WriteLine(@"______________________________________________________________________________");
                            Console.WriteLine(@"| Settings                                                         _   8 | X |");
                            Console.WriteLine(@"|________________________________________________________________________|___|");
                            Console.WriteLine(@"|      _                                                                     |");
                            Console.WriteLine(@"|   /\| |/\                                                                  |");
                            Console.WriteLine(@"|  _\     /_                                                                 |");
                            Console.WriteLine(@"| |_   O   _|   You cannot delete your own Account!                          |");
                            Console.WriteLine(@"|   /     \                                                                  |");
                            Console.WriteLine(@"|   \/|_|\/                                                                  |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                       TBOS was made " + Year + " by HenkelSoft Inc.|");
                            Console.WriteLine(@"|____________________________________________________________________________|");
                            Console.WriteLine(@"| S T A R T | Settings |                                    01:00 01.01." + Year + " |");
                            Console.WriteLine(@"|___________|__________|_____________________________________________________|");
                        }
                        else if (AccountName.ToLower() == "admin")
                        {
                            Console.WriteLine(@"______________________________________________________________________________");
                            Console.WriteLine(@"| Settings                                                         _   8 | X |");
                            Console.WriteLine(@"|________________________________________________________________________|___|");
                            Console.WriteLine(@"|      _                                                                     |");
                            Console.WriteLine(@"|   /\| |/\                                                                  |");
                            Console.WriteLine(@"|  _\     /_                                                                 |");
                            Console.WriteLine(@"| |_   O   _|   You cannot delete the Administrator!                         |");
                            Console.WriteLine(@"|   /     \                                                                  |");
                            Console.WriteLine(@"|   \/|_|\/                                                                  |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                       TBOS was made " + Year + " by HenkelSoft Inc.|");
                            Console.WriteLine(@"|____________________________________________________________________________|");
                            Console.WriteLine(@"| S T A R T | Settings |                                    01:00 01.01." + Year + " |");
                            Console.WriteLine(@"|___________|__________|_____________________________________________________|");
                        }
                        else
                        {
                            File.Delete(@"Z:\HenkelSoftTextBasedOS\HenkelSoftTextBasedOS\bin\Debug\net5.0\Users\" + AccountName + ".txt");
                            File.Delete(@"Z:\HenkelSoftTextBasedOS\HenkelSoftTextBasedOS\bin\Debug\net5.0\Passwords\" + AccountName + ".txt");
                            Console.WriteLine(@"______________________________________________________________________________");
                            Console.WriteLine(@"| Settings                                                         _   8 | X |");
                            Console.WriteLine(@"|________________________________________________________________________|___|");
                            Console.WriteLine(@"|      _                                                                     |");
                            Console.WriteLine(@"|   /\| |/\                                                                  |");
                            Console.WriteLine(@"|  _\     /_                                                                 |");
                            Console.WriteLine(@"| |_   O   _|   Account deleted!                                             |");
                            Console.WriteLine(@"|   /     \                                                                  |");
                            Console.WriteLine(@"|   \/|_|\/                                                                  |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                       TBOS was made " + Year + " by HenkelSoft Inc.|");
                            Console.WriteLine(@"|____________________________________________________________________________|");
                            Console.WriteLine(@"| S T A R T | Settings |                                    01:00 01.01." + Year + " |");
                            Console.WriteLine(@"|___________|__________|_____________________________________________________|");
                        }
                        break;
                    case "changePass":
                        Console.WriteLine("Current Password: " + File.ReadAllText(currentdir + @"/Passwords/" + name + ".txt"));
                        Console.Write("New Password: ");
                        string newPassword = Console.ReadLine();
                        Console.Write("Confirm Password: ");
                        string confirmPassword = Console.ReadLine();
                        if (newPassword == confirmPassword)
                        {
                            File.WriteAllText(currentdir + @"/Passwords/" + name + ".txt", newPassword);
                            Console.WriteLine(@"______________________________________________________________________________");
                            Console.WriteLine(@"| Settings                                                         _   8 | X |");
                            Console.WriteLine(@"|________________________________________________________________________|___|");
                            Console.WriteLine(@"|      _                                                                     |");
                            Console.WriteLine(@"|   /\| |/\                                                                  |");
                            Console.WriteLine(@"|  _\     /_                                                                 |");
                            Console.WriteLine(@"| |_   O   _|   Password changed successfully!                               |");
                            Console.WriteLine(@"|   /     \                                                                  |");
                            Console.WriteLine(@"|   \/|_|\/                                                                  |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                       TBOS was made " + Year + " by HenkelSoft Inc.|");
                            Console.WriteLine(@"|____________________________________________________________________________|");
                            Console.WriteLine(@"| S T A R T | Settings |                                    01:00 01.01." + Year + " |");
                            Console.WriteLine(@"|___________|__________|_____________________________________________________|");
                        }
                        else
                        {
                            Console.WriteLine(@"______________________________________________________________________________");
                            Console.WriteLine(@"| Settings                                                         _   8 | X |");
                            Console.WriteLine(@"|________________________________________________________________________|___|");
                            Console.WriteLine(@"|      _                                                                     |");
                            Console.WriteLine(@"|   /\| |/\                                                                  |");
                            Console.WriteLine(@"|  _\     /_                                                                 |");
                            Console.WriteLine(@"| |_   O   _|   Passwordchange has failed!                                   |");
                            Console.WriteLine(@"|   /     \                                                                  |");
                            Console.WriteLine(@"|   \/|_|\/                                                                  |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                                                            |");
                            Console.WriteLine(@"|                                       TBOS was made " + Year + " by HenkelSoft Inc.|");
                            Console.WriteLine(@"|____________________________________________________________________________|");
                            Console.WriteLine(@"| S T A R T | Settings |                                    01:00 01.01." + Year + " |");
                            Console.WriteLine(@"|___________|__________|_____________________________________________________|");
                        }
                        break;
                    default:
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| Settings                                                         _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"|      _                                                                     |");
                        Console.WriteLine(@"|   /\| |/\                                                                  |");
                        Console.WriteLine(@"|  _\     /_                                                                 |");
                        Console.WriteLine(@"| |_   O   _|   Invalid Command: Try again.                                  |");
                        Console.WriteLine(@"|   /     \                                                                  |");
                        Console.WriteLine(@"|   \/|_|\/                                                                  |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                       TBOS was made " + Year + " by HenkelSoft Inc.|");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T | Settings |                                    01:00 01.01." + Year + " |");
                        Console.WriteLine(@"|___________|__________|_____________________________________________________|");
                        break;
                }
            }
        }
    }
}