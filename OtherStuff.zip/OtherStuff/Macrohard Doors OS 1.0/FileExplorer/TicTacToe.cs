using System;

namespace TicTacToe
{
    class TicTacToeGame
    {
        public void Game()
        {
            bool Play = true;
            bool canParse = false;
            int players = 0;
            string playersNumberString = "";
            Console.WriteLine("How many players should play Tic Tac Toe?");
            while (canParse == false)
            {
                playersNumberString = Console.ReadLine();
                if (int.TryParse(playersNumberString, out players) == true)
                {
                    players = Convert.ToInt32(playersNumberString);
                    if (players > 2)
                    {
                        Console.WriteLine("Too many players! Set to Max of 2!");
                        players = 2;
                    }
                    else if (players < 1)
                    {
                        Console.WriteLine("Too few players! Set to Min of 1!");
                        players = 1;
                    }
                    canParse = true;
                }
                else
                {
                    Console.WriteLine("Invalid Input! Please try again!");
                    canParse = false;
                }
            }
            while (Play == true)
            {
                Random rngGenerator = new Random();
                int playerTurn = 1;
                int TurnNumber = 1;
                string Top = "1 ¦ 2 ¦ 3";
                string Center = "4 ¦ 5 ¦ 6";
                string Bottom = "7 ¦ 8 ¦ 9";
                string state = "In Play";
                string YesNo = "";
                Console.WriteLine(Top);
                Console.WriteLine("-----------");
                Console.WriteLine(Center);
                Console.WriteLine("-----------");
                Console.WriteLine(Bottom);
                while (state == "In Play")
                {
                    if (playerTurn == 1)
                    {
                        turn("x");
                    }
                    else if (playerTurn == 2)
                    {
                        turn("o");
                    }
                    void turn(string symbol)
                    {
                        bool InvalidMove = true;

                        while (InvalidMove == true)
                        {
                            string PickAField = "";
                            if (playerTurn == 2 && players == 1)
                            {
                                PickAField = Convert.ToString(rngGenerator.Next(1, 10));
                            } else
                            {
                                Console.WriteLine("Pick a Space");
                                PickAField = Console.ReadLine();
                            }
                            switch (PickAField)
                            {
                                case "1":
                                    if (Top.Contains("1"))
                                    {
                                        Top = Top.Replace("1", symbol);
                                        InvalidMove = false;
                                    }
                                    else
                                    {
                                        if (playerTurn != 2 | players != 1)
                                        {
                                            Console.WriteLine("Already Occupied!");
                                        }
                                    }
                                    break;
                                case "2":
                                    if (Top.Contains("2"))
                                    {
                                        Top = Top.Replace("2", symbol);
                                        InvalidMove = false;
                                    }
                                    else
                                    {
                                        if (playerTurn != 2 | players != 1)
                                        {
                                            Console.WriteLine("Already Occupied!");
                                        }
                                    }
                                    break;
                                case "3":
                                    if (Top.Contains("3"))
                                    {
                                        Top = Top.Replace("3", symbol);
                                        InvalidMove = false;
                                    }
                                    else
                                    {
                                        if (playerTurn != 2 | players != 1)
                                        {
                                            Console.WriteLine("Already Occupied!");
                                        }
                                    }
                                    break;
                                case "4":
                                    if (Center.Contains("4"))
                                    {
                                        Center = Center.Replace("4", symbol);
                                        InvalidMove = false;
                                    }
                                    else
                                    {
                                        if (playerTurn != 2 | players != 1)
                                        {
                                            Console.WriteLine("Already Occupied!");
                                        }
                                    }
                                    break;
                                case "5":
                                    if (Center.Contains("5"))
                                    {
                                        Center = Center.Replace("5", symbol);
                                        InvalidMove = false;
                                    }
                                    else
                                    {
                                        if (playerTurn != 2 | players != 1)
                                        {
                                            Console.WriteLine("Already Occupied!");
                                        }
                                    }
                                    break;
                                case "6":
                                    if (Center.Contains("6"))
                                    {
                                        Center = Center.Replace("6", symbol);
                                        InvalidMove = false;
                                    }
                                    else
                                    {
                                        if (playerTurn != 2 | players != 1)
                                        {
                                            Console.WriteLine("Already Occupied!");
                                        }
                                    }
                                    break;
                                case "7":
                                    if (Bottom.Contains("7"))
                                    {
                                        Bottom = Bottom.Replace("7", symbol);
                                        InvalidMove = false;
                                    }
                                    else
                                    {
                                        if (playerTurn != 2 | players != 1)
                                        {
                                            Console.WriteLine("Already Occupied!");
                                        }
                                    }
                                    break;
                                case "8":
                                    if (Bottom.Contains("8"))
                                    {
                                        Bottom = Bottom.Replace("8", symbol);
                                        InvalidMove = false;
                                    }
                                    else
                                    {
                                        if (playerTurn != 2 | players != 1)
                                        {
                                            Console.WriteLine("Already Occupied!");
                                        }
                                    }
                                    break;
                                case "9":
                                    if (Bottom.Contains("9"))
                                    {
                                        Bottom = Bottom.Replace("9", symbol);
                                        InvalidMove = false;
                                    }
                                    else
                                    {
                                        if (playerTurn != 2 | players != 1)
                                        {
                                            Console.WriteLine("Already Occupied!");
                                        }
                                    }
                                    break;
                                default:
                                    if (playerTurn != 2 | players != 1)
                                    {
                                        Console.WriteLine("Invalid Input!");
                                    }
                                    break;
                            }
                        }
                        Console.WriteLine(Top);
                        Console.WriteLine("-----------");
                        Console.WriteLine(Center);
                        Console.WriteLine("-----------");
                        Console.WriteLine(Bottom);
                        if (Top == symbol + " ¦ " + symbol + " ¦ " + symbol || Center == symbol + " ¦ " + symbol + " ¦ " + symbol || Bottom == symbol + " ¦ " + symbol + " ¦ " + symbol)
                        {
                            state = "victory";
                            Console.WriteLine("Player " + playerTurn + " won!");
                            playerTurn = 0;
                        }
                        else if (Bottom.StartsWith(symbol) && Center.StartsWith(symbol) && Top.StartsWith(symbol))
                        {
                            state = "victory";
                            Console.WriteLine("Player " + playerTurn + " won!");
                            playerTurn = 0;
                        }
                        else if (Bottom.Contains("¦ " + symbol + " ¦") && Center.Contains("¦ " + symbol + " ¦") && Top.Contains("¦ " + symbol + " ¦"))
                        {
                            state = "victory";
                            Console.WriteLine("Player " + playerTurn + " won!");
                            playerTurn = 0;
                        }
                        else if (Bottom.EndsWith(symbol) && Center.EndsWith(symbol) && Top.EndsWith(symbol))
                        {
                            state = "victory";
                            Console.WriteLine("Player " + playerTurn + " won!");
                            playerTurn = 0;
                        }
                        else if (Top.StartsWith(symbol) && Center.Contains("¦ " + symbol + " ¦") && Bottom.EndsWith(symbol))
                        {
                            state = "victory";
                            Console.WriteLine("Player " + playerTurn + " won!");
                            playerTurn = 0;
                        }
                        else if (Bottom.StartsWith(symbol) && Center.Contains("¦ " + symbol + " ¦") && Top.EndsWith(symbol))
                        {
                            state = "victory";
                            Console.WriteLine("Player " + playerTurn + " won!");
                            playerTurn = 0;
                        }
                        else if (TurnNumber == 9)
                        {
                            state = "draw";
                            Console.WriteLine("Its a draw...");
                            playerTurn = 0;
                        } else
                        {
                            TurnNumber += 1;
                            if (playerTurn == 1)
                            {
                                playerTurn = 2;
                            } else if (playerTurn == 2)
                            {
                                playerTurn = 1;
                            }
                            Console.WriteLine("Player " + playerTurn + "'s Turn");
                        }
                    }
                }
                Console.WriteLine("Continue? [y/n]");
                while (YesNo.ToLower() != "y" && YesNo.ToLower() != "n")
                {
                    YesNo = Console.ReadLine();
                    if (YesNo.ToLower() == "y")
                    {
                        Play = true;
                    }
                    else if (YesNo.ToLower() == "n")
                    {
                        Play = false;
                    }
                    else
                    {
                        Console.WriteLine("Invalid Input!");
                    }
                }
            }
        }
    }
}