﻿using System;
using System.IO;
using HenkelSoftTextBasedOS;
using TicTacToe;
using ManagingSim;

namespace Macrohard_Doors_OS_1_0
{
    class Program
    {
        static string CurrentDir = Directory.GetCurrentDirectory();
        static bool canContinue = false;
        static bool antivirusActive = false;
        static HenkelSoftTextBasedOperatingSystem TBOS = new();
        static TicTacToeGame Tictactoe = new();
        static ManagingSimulator Managing = new();
        static string Username;
        static void Main()
        {
            LoginProcedure();
            if (canContinue)
            {
                DesktopLogic();
            }
        }
        static void DoorsOSLogo()
        {
            Console.WriteLine(@"\__________________________________________________________________________/");
            Console.WriteLine(@" | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|");
            Console.WriteLine(@" ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |");
            Console.WriteLine(@" ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|");
            Console.WriteLine(@" ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |");
            Console.WriteLine(@" ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|");
            Console.WriteLine(@" ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |");
            Console.WriteLine(@" ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|");
            Console.WriteLine(@" ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |");
            Console.WriteLine(@" ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|");
            Console.WriteLine(@" ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |");
            Console.WriteLine(@" ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |");
            Console.WriteLine(@" ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|");
            Console.WriteLine(@" ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||");
            Console.WriteLine(@" ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||");
            Console.WriteLine(@" ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |");
            Console.WriteLine(@" ||_______________|_______________________________________________________|");
            Console.WriteLine(@"/                                                      by Macrohard Studios\");
        }
        static void Desktop()
        {
            Console.WriteLine(@"___________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|                                                                        |");
            Console.WriteLine(@"| | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|   /||                                                                        |");
            Console.WriteLine(@"| ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |  / ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|./| ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||                                                                        |");
            Console.WriteLine(@"| ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -||_|_||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|| | ||                                                                        |");
            Console.WriteLine(@"| ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- | \| ||                                                                        |");
            Console.WriteLine(@"| ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|  \ ||                                                                        |");
            Console.WriteLine(@"| ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |   \||                                                                        |");
            Console.WriteLine(@"| ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |     |                                                                        |");
            Console.WriteLine(@"| ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|     |                                                                        |");
            Console.WriteLine(@"| ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||     |                                                                        |");
            Console.WriteLine(@"| ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||     |                                                                        |");
            Console.WriteLine(@"| ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |     |                                                                        |");
            Console.WriteLine(@"| ||_______________|_______________________________________________________|     |                                                                        |");
            Console.WriteLine(@"|/                                                      by Macrohard Studios\    |                                                                        |");
            Console.WriteLine(@"|                                                                            \   |                                                                        |");
            Console.WriteLine(@"|                                                                             \  |                                                                        |");
            Console.WriteLine(@"|                                                                              \ |                                                                        |");
            Console.WriteLine(@"|                                                                               \|________________________________________________________________________|");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| S T A R T | File Explorer | Settings | Information | Help |                                                                      | 11:12 09.11.1997 |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
        }
        static void artism()
        {
            Console.WriteLine(@"___________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|   ______________________________________________________________       |");
            Console.WriteLine(@"| | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|   /||  |                                                     |        |      |");
            Console.WriteLine(@"| ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |  / ||  |                                            _________|  __ _  |      |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|./| ||  |                                            |_______|| |  | \ |      |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||      /                                        |       || |  |  ||      |");
            Console.WriteLine(@"| ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -||_|_||     /                                         |       || |  |  ||      |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||    /                                          |_______|| |__|_/ |      |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|| | ||   /                                                    |        |      |");
            Console.WriteLine(@"| ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- | \| ||  |                                                     |________|      |");
            Console.WriteLine(@"| ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|  \ ||  |                                                              |      |");
            Console.WriteLine(@"| ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |   \||  |                                                              |      |");
            Console.WriteLine(@"| ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |     |  |                                                              |      |");
            Console.WriteLine(@"| ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|     |  |                                                              |      |");
            Console.WriteLine(@"| ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||     |  |_______                                                       |      |");
            Console.WriteLine(@"| ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||     |  |       |                                                      |      |");
            Console.WriteLine(@"| ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |     |  |_______|______________________________________________________|      |");
            Console.WriteLine(@"| ||_______________|_______________________________________________________|     |   SUBJSTATUS: Alive and healthy                                        |");
            Console.WriteLine(@"|/                                                      by Macrohard Studios\    |   SUBJLOCATION: Somewhere                                              |");
            Console.WriteLine(@"|                                                                            \   |   LOCAL_TIME: 29:63 45.65.1890                                         |");
            Console.WriteLine(@"|                                                                             \  |   NOTE: We will find him.                                              |");
            Console.WriteLine(@"|                                                                              \ |                                                                        |");
            Console.WriteLine(@"|                                                                               \|________________________________________________________________________|");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| S T A R T | File Explorer | Settings | Information | Help |                                                                      | 11:12 09.11.1997 |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
        }
        static void Entry2()
        {
            Console.WriteLine(@"___________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|                                                                        |");
            Console.WriteLine(@"| | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|   /||  ENTRY NUMBER 2                                                        |");
            Console.WriteLine(@"| ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |  / ||  Where am I... What happened... And what are those...things. They look |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|./| ||  kinda humanoid, but at the same time, they dont. Maybe i should try   |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||  and talk to them. Whats the worst thing that could happen...          |");
            Console.WriteLine(@"| ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -||_|_||  [END OF DOCUMENT]                                                     |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||  Username: LPSam                                                       |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|| | ||                                                                        |");
            Console.WriteLine(@"| ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- | \| ||                                                                        |");
            Console.WriteLine(@"| ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|  \ ||                                                                        |");
            Console.WriteLine(@"| ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |   \||                                                                        |");
            Console.WriteLine(@"| ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |     |                                                                        |");
            Console.WriteLine(@"| ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|     |                                                                        |");
            Console.WriteLine(@"| ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||     |                                                                        |");
            Console.WriteLine(@"| ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||     |                                                                        |");
            Console.WriteLine(@"| ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |     |                                                                        |");
            Console.WriteLine(@"| ||_______________|_______________________________________________________|     |                                                                        |");
            Console.WriteLine(@"|/                                                      by Macrohard Studios\    |                                                                        |");
            Console.WriteLine(@"|                                                                            \   |                                                                        |");
            Console.WriteLine(@"|                                                                             \  |                                                                        |");
            Console.WriteLine(@"|                                                                              \ |                                                                        |");
            Console.WriteLine(@"|                                                                               \|________________________________________________________________________|");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| S T A R T | File Explorer | Settings | Information | Help |                                                                      | 11:12 09.11.1997 |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
        }
        static void TicTacToedotexe()
        {
            Console.WriteLine(@"___________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|                                                                        |");
            Console.WriteLine(@"| | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|   /||  Loading TicTacToe for ConsoleApp by Triple T Studios...               |");
            Console.WriteLine(@"| ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |  / ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|./| ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||                                                                        |");
            Console.WriteLine(@"| ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -||_|_||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|| | ||                                                                        |");
            Console.WriteLine(@"| ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- | \| ||                                                                        |");
            Console.WriteLine(@"| ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|  \ ||                                                                        |");
            Console.WriteLine(@"| ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |   \||                                                                        |");
            Console.WriteLine(@"| ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |     |                                                                        |");
            Console.WriteLine(@"| ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|     |                                                                        |");
            Console.WriteLine(@"| ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||     |                                                                        |");
            Console.WriteLine(@"| ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||     |                                                                        |");
            Console.WriteLine(@"| ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |     |                                                                        |");
            Console.WriteLine(@"| ||_______________|_______________________________________________________|     |                                                                        |");
            Console.WriteLine(@"|/                                                      by Macrohard Studios\    |                                                                        |");
            Console.WriteLine(@"|                                                                            \   |                                                                        |");
            Console.WriteLine(@"|                                                                             \  |                                                                        |");
            Console.WriteLine(@"|                                                                              \ |                                                                        |");
            Console.WriteLine(@"|                                                                               \|________________________________________________________________________|");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| S T A R T | File Explorer | Settings | Information | Help |                                                                      | 11:12 09.11.1997 |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
            Tictactoe.Game();
        }
        static void Entry3()
        {
            Console.WriteLine(@"___________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|                                                                        |");
            Console.WriteLine(@"| | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|   /||  ENTRY NUMBER 3                                                        |");
            Console.WriteLine(@"| ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |  / ||  It turns out that they were not friendly at all! they were chasing me |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|./| ||  for the past few hours without ever stopping. I found this old Base-  |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||  looking building and it had a Computer inside. I saved my last entries|");
            Console.WriteLine(@"| ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -||_|_||  on it and wrote this one. I think its safe now...                     |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||  [END OF DOCUMENT]                                                     |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|| | ||  Password: ItsGamingTime                                               |");
            Console.WriteLine(@"| ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- | \| ||                                                                        |");
            Console.WriteLine(@"| ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|  \ ||                                                                        |");
            Console.WriteLine(@"| ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |   \||                                                                        |");
            Console.WriteLine(@"| ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |     |                                                                        |");
            Console.WriteLine(@"| ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|     |                                                                        |");
            Console.WriteLine(@"| ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||     |                                                                        |");
            Console.WriteLine(@"| ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||     |                                                                        |");
            Console.WriteLine(@"| ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |     |                                                                        |");
            Console.WriteLine(@"| ||_______________|_______________________________________________________|     |                                                                        |");
            Console.WriteLine(@"|/                                                      by Macrohard Studios\    |                                                                        |");
            Console.WriteLine(@"|                                                                            \   |                                                                        |");
            Console.WriteLine(@"|                                                                             \  |                                                                        |");
            Console.WriteLine(@"|                                                                              \ |                                                                        |");
            Console.WriteLine(@"|                                                                               \|________________________________________________________________________|");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| S T A R T | File Explorer | Settings | Information | Help |                                                                      | 11:12 09.11.1997 |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
        }
        static void help()
        {
            Console.WriteLine(@"___________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|                                                                        |");
            Console.WriteLine(@"| | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|   /|| Help                                                                   |");
            Console.WriteLine(@"| ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |  / ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|./| || - desktop - Empty the desktop to original state                        |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||                                                                        |");
            Console.WriteLine(@"| ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -||_|_|| - information - Displays Information about the System                  |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|| | || - settings - Open Settings                                             |");
            Console.WriteLine(@"| ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- | \| ||                                                                        |");
            Console.WriteLine(@"| ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|  \ || - explorer - Opens the File Explorer                                   |");
            Console.WriteLine(@"| ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |   \||                                                                        |");
            Console.WriteLine(@"| ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |     | - turnoff - Shuts the System down                                      |");
            Console.WriteLine(@"| ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|     |                                                                        |");
            Console.WriteLine(@"| ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||     |                                                                        |");
            Console.WriteLine(@"| ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||     |                                                                        |");
            Console.WriteLine(@"| ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |     |                                                                        |");
            Console.WriteLine(@"| ||_______________|_______________________________________________________|     |                                                                        |");
            Console.WriteLine(@"|/                                                      by Macrohard Studios\    |                                                                        |");
            Console.WriteLine(@"|                                                                            \   |                                                                        |");
            Console.WriteLine(@"|                                                                             \  |                                                                        |");
            Console.WriteLine(@"|                                                                              \ |                                                                        |");
            Console.WriteLine(@"|                                                                               \|________________________________________________________________________|");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| S T A R T | File Explorer | Settings | Information | Help |                                                                      | 11:12 09.11.1997 |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
        }
        static void LoginProcedure()
        {
            DoorsOSLogo();
            Username = "";
            bool UserExists = false;
            bool correctPass = false;
            string actualPass = "";
            string writtenPass = "";
            int attempts = 0;
            while (!UserExists)
            {
                Console.Write("Enter Name:");
                Username = Console.ReadLine();
                Console.WriteLine();
                if (File.Exists(CurrentDir + @"\Users+Passwords\" + Username + ".txt"))
                {
                    UserExists = true;
                    actualPass = File.ReadAllText(CurrentDir + @"\Users+Passwords\" + Username + ".txt");
                }
                else
                {
                    Console.WriteLine("That user doesnt exist!");
                }
            }
            while(!correctPass && attempts <= 3)
            {
                Console.Write("Enter Password:");
                writtenPass = Console.ReadLine();
                Console.WriteLine();
                if(actualPass == writtenPass)
                {
                    correctPass = true;
                    Console.WriteLine("Welcome");
                }
                else
                {
                    attempts++;
                    Console.WriteLine("Wrong Password!");
                }
            }
            if (correctPass)
            {
                canContinue = true;
            }
        }
        static void error()
        {
            Console.WriteLine(@"__________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|                                                                        |");
            Console.WriteLine(@"| | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|   /|| Error 404 - Command not found                                          |");
            Console.WriteLine(@"| ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |  / ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|./| || The entered Command was not found. Please check if                     |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||                                                                        |");
            Console.WriteLine(@"| ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -||_|_|| 1. the command exists                                                  |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|| | || 2. this is where it should be executed                                 |");
            Console.WriteLine(@"| ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- | \| ||                                                                        |");
            Console.WriteLine(@"| ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|  \ || 3. its written correctly                                               |");
            Console.WriteLine(@"| ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |   \||                                                                        |");
            Console.WriteLine(@"| ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |     | If all the above are true and it still doesnt work, please contact the |");
            Console.WriteLine(@"| ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|     | System Admin to fix the issue.                                         |");
            Console.WriteLine(@"| ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||     |                                                                        |");
            Console.WriteLine(@"| ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||     |                                                                        |");
            Console.WriteLine(@"| ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |     |                                                                        |");
            Console.WriteLine(@"| ||_______________|_______________________________________________________|     |                                                                        |");
            Console.WriteLine(@"|/                                                      by Macrohard Studios\    |                                                                        |");
            Console.WriteLine(@"|                                                                            \   |                                                                        |");
            Console.WriteLine(@"|                                                                             \  |                                                                        |");
            Console.WriteLine(@"|                                                                              \ |                                                    - Macrohard Studios |");
            Console.WriteLine(@"|                                                                               \|________________________________________________________________________|");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| S T A R T | File Explorer | Settings | Information | Help |                                                                      | 11:12 09.11.1997 |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
        }
        static void WrongAcc()
        {
            Console.WriteLine(@"__________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|                                                                        |");
            Console.WriteLine(@"| | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|   /|| Error 111 - This File is private                                       |");
            Console.WriteLine(@"| ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |  / ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|./| || The entered Filename was found, but it was set to private by User SaHe |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | || If access is needed, you have to either                                |");
            Console.WriteLine(@"| ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -||_|_||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | || 1. change your account to SaHe                                         |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|| | ||                                                                        |");
            Console.WriteLine(@"| ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- | \| || 2. get SaHe to unprivate it                                            |");
            Console.WriteLine(@"| ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|  \ ||                                                                        |");
            Console.WriteLine(@"| ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |   \|| 3. get SaHe to make a public copy                                      |");
            Console.WriteLine(@"| ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |     |                                                                        |");
            Console.WriteLine(@"| ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|     | If you did any of the above and it still doesnt work, please contact   |");
            Console.WriteLine(@"| ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||     | the System Admin to fix the issue.                                     |");
            Console.WriteLine(@"| ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||     |                                                                        |");
            Console.WriteLine(@"| ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |     |                                                                        |");
            Console.WriteLine(@"| ||_______________|_______________________________________________________|     |                                                                        |");
            Console.WriteLine(@"|/                                                      by Macrohard Studios\    |                                                                        |");
            Console.WriteLine(@"|                                                                            \   |                                                                        |");
            Console.WriteLine(@"|                                                                             \  |                                                                        |");
            Console.WriteLine(@"|                                                                              \ |                                                    - Macrohard Studios |");
            Console.WriteLine(@"|                                                                               \|________________________________________________________________________|");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| S T A R T | File Explorer | Settings | Information | Help |                                                                      | 11:12 09.11.1997 |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
        }
        static void settings()
        {
            Console.WriteLine(@"___________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|      _                                                                 |");
            Console.WriteLine(@"| | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|   /||   /\| |/\                                                              |");
            Console.WriteLine(@"| ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |  / ||  _\     /_                                                             |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|./| || |_   O   _|  Settings                                                  |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||   /     \                                                              |");
            Console.WriteLine(@"| ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -||_|_||   \/|_|\/                                                              |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|| | ||   NewAccount - Creates new Account(admin only)                         |");
            Console.WriteLine(@"| ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- | \| ||                                                                        |");
            Console.WriteLine(@"| ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|  \ ||   DelAccount - Deletes old Account(admin only)                         |");
            Console.WriteLine(@"| ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |   \||                                                                        |");
            Console.WriteLine(@"| ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |     |   changepass - Changes the Password(everyone)                          |");
            Console.WriteLine(@"| ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|     |                                                                        |");
            Console.WriteLine(@"| ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||     |   Antivirus  - scans Computer for Viruses and removes them             |");
            Console.WriteLine(@"| ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||     |                                                                        |");
            Console.WriteLine(@"| ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |     |   Provirus   - puts Viruses on the Computer so it can build an Immunity|");
            Console.WriteLine(@"| ||_______________|_______________________________________________________|     |                                                                        |");
            Console.WriteLine(@"|/                                                      by Macrohard Studios\    |   exit       - leave Settings                                          |");
            Console.WriteLine(@"|                                                                            \   |                                                                        |");
            Console.WriteLine(@"|                                                                             \  |                                                                        |");
            Console.WriteLine(@"|                                                                              \ |                                                                        |");
            Console.WriteLine(@"|                                                                               \|________________________________________________________________________|");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| S T A R T | File Explorer | Settings | Information | Help |                                                                      | 11:12 09.11.1997 |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
        }
        static void info()
        {
            Console.WriteLine(@"___________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|                                                                        |");
            Console.WriteLine(@"| | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|   /||  - System Information                                                  |");
            Console.WriteLine(@"| ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |  / ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|./| ||  Macrohard Doors OS 1.0 (Build Ver. 1876325)                           |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||                                                                        |");
            Console.WriteLine(@"| ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -||_|_||  developed in 1997                                                     |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|| | ||  300/500 MB used Storage                                               |");
            Console.WriteLine(@"| ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- | \| ||                                                                        |");
            Console.WriteLine(@"| ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|  \ ||  Last Antivirus Scan: 1. January 1970                                  |");
            Console.WriteLine(@"| ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |   \||                                                                        |");
            Console.WriteLine(@"| ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |     |  Internet connection: None                                             |");
            Console.WriteLine(@"| ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|     |                                                                        |");
            Console.WriteLine(@"| ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||     |                                                                        |");
            Console.WriteLine(@"| ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||     |                                                                        |");
            Console.WriteLine(@"| ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |     |                                                                        |");
            Console.WriteLine(@"| ||_______________|_______________________________________________________|     |                                                                        |");
            Console.WriteLine(@"|/                                                      by Macrohard Studios\    |                                                                        |");
            Console.WriteLine(@"|                                                                            \   |                                                                        |");
            Console.WriteLine(@"|                                                                             \  |                                                                        |");
            Console.WriteLine(@"|                                                                              \ |                                                                        |");
            Console.WriteLine(@"|                                                                               \|________________________________________________________________________|");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| S T A R T | File Explorer | Settings | Information | Help |                                                                      | 11:12 09.11.1997 |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
        }
        static void antivirus()
        {
            Console.WriteLine(@"___________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|                                                                        |");
            Console.WriteLine(@"| | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|   /||  Doors OS Antivirus detected and removed 1 virus(es)                   |");
            Console.WriteLine(@"| ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |  / ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|./| ||  Affected Commands:                                                    |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||                                                                        |");
            Console.WriteLine(@"| ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -||_|_||  Provirus(contained Virus named BadIdea.exe)                           |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|| | ||                                                                        |");
            Console.WriteLine(@"| ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- | \| ||                                                                        |");
            Console.WriteLine(@"| ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|  \ ||                                                                        |");
            Console.WriteLine(@"| ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |   \||                                                                        |");
            Console.WriteLine(@"| ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |     |                                                                        |");
            Console.WriteLine(@"| ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|     |                                                                        |");
            Console.WriteLine(@"| ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||     |                                                                        |");
            Console.WriteLine(@"| ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||     |                                                                        |");
            Console.WriteLine(@"| ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |     |                                                                        |");
            Console.WriteLine(@"| ||_______________|_______________________________________________________|     |                                                                        |");
            Console.WriteLine(@"|/                                                      by Macrohard Studios\    |                                                                        |");
            Console.WriteLine(@"|                                                                            \   |                                                                        |");
            Console.WriteLine(@"|                                                                             \  |                                                                        |");
            Console.WriteLine(@"|                                                                              \ |                                                                        |");
            Console.WriteLine(@"|                                                                               \|________________________________________________________________________|");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| S T A R T | File Explorer | Settings | Information | Help |                                                                      | 11:12 09.11.1997 |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
        }
        static void past()
        {
            Console.WriteLine(@"___________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|                                                                        |");
            Console.WriteLine(@"| | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|   /||  ENTRY NUMBER                                                          |");
            Console.WriteLine(@"| ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |  / ||  SEVENTEEN                                                             |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|./| ||  DARK                                                                  |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||  DARKER                                                                |");
            Console.WriteLine(@"| ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -||_|_||  YET DARKER                                                            |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||  THE DARKNESS                                                          |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|| | ||  KEEPS GROWING                                                         |");
            Console.WriteLine(@"| ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- | \| ||  THE SHADOWS                                                           |");
            Console.WriteLine(@"| ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|  \ ||  CUTTING DEEPER                                                        |");
            Console.WriteLine(@"| ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |   \||  THIS NEXT                                                             |");
            Console.WriteLine(@"| ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |     |  EXPERIMENT                                                            |");
            Console.WriteLine(@"| ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|     |  SEEMS                                                                 |");
            Console.WriteLine(@"| ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||     |  VERY                                                                  |");
            Console.WriteLine(@"| ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||     |  VERY                                                                  |");
            Console.WriteLine(@"| ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |     |  INTERESTING                                                           |");
            Console.WriteLine(@"| ||_______________|_______________________________________________________|     |  ...                                                                   |");
            Console.WriteLine(@"|/                                                      by Macrohard Studios\    |  WHAT DO YOU TWO THINK                                                 |");
            Console.WriteLine(@"|                                                                            \   |  [END OF DOCUMENT]                                                     |");
            Console.WriteLine(@"|                                                                             \  |  EntryNr1.location == HenkelSoft TBOS                                  |");
            Console.WriteLine(@"|                                                                              \ |                                                                        |");
            Console.WriteLine(@"|                                                                               \|________________________________________________________________________|");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| S T A R T | File Explorer | Settings | Information | Help |                                                                      | 11:12 09.11.1997 |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
        }
        static void present()
        {
            Console.WriteLine(@"___________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|                                                                        |");
            Console.WriteLine(@"| | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|   /||  ENTRY NUMBER 4:                                                       |");
            Console.WriteLine(@"| ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |  / ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|./| ||  I was wrong, it is never safe out there. I had to run away again from |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||  them, who- or whatever they are. I must find a way. There has to be a |");
            Console.WriteLine(@"| ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -||_|_||  Way out of here...atleast i hope there is. I can see the lights of a  |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||  City! Maybe there are some nice people there...                       |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|| | ||  [END OF DOCUMENT]                                                     |");
            Console.WriteLine(@"| ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- | \| ||  Dont forget, im with you in the Dark...                               |");
            Console.WriteLine(@"| ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|  \ ||  Dark.txt                                                              |");
            Console.WriteLine(@"| ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |   \||  Find It                                                               |");
            Console.WriteLine(@"| ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |     |                                                                        |");
            Console.WriteLine(@"| ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|     |                                                                        |");
            Console.WriteLine(@"| ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||     |                                                                        |");
            Console.WriteLine(@"| ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||     |                                                                        |");
            Console.WriteLine(@"| ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |     |                                                                        |");
            Console.WriteLine(@"| ||_______________|_______________________________________________________|     |                                                                        |");
            Console.WriteLine(@"|/                                                      by Macrohard Studios\    |                                                                        |");
            Console.WriteLine(@"|                                                                            \   |                                                                        |");
            Console.WriteLine(@"|                                                                             \  |                                                                        |");
            Console.WriteLine(@"|                                                                              \ |                                                                        |");
            Console.WriteLine(@"|                                                                               \|________________________________________________________________________|");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| S T A R T | File Explorer | Settings | Information | Help |                                                                      | 11:12 09.11.1997 |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
        }
        static void future()
        {
            Console.WriteLine(@"___________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|                                                                        |");
            Console.WriteLine(@"| | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|   /||  ENTRY NUMBER 21                                                       |");
            Console.WriteLine(@"| ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |  / ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|./| ||  I made it... I escaped that hellhole, somehow. Well, im never touching|");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||  that Program again, ever! Ive seen enough of it to make my own Version|");
            Console.WriteLine(@"| ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -||_|_||  of it. Will release it with all my Entries in it.                     |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||  [END OF DOCUMENT]                                                     |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|| | ||  Its not the end                                                       |");
            Console.WriteLine(@"| ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- | \| ||                                                                        |");
            Console.WriteLine(@"| ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|  \ ||                                                                        |");
            Console.WriteLine(@"| ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |   \||                                                                        |");
            Console.WriteLine(@"| ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |     |                                                                        |");
            Console.WriteLine(@"| ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|     |                                                                        |");
            Console.WriteLine(@"| ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||     |                                                                        |");
            Console.WriteLine(@"| ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||     |                                                                        |");
            Console.WriteLine(@"| ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |     |                                                                        |");
            Console.WriteLine(@"| ||_______________|_______________________________________________________|     |                                                                        |");
            Console.WriteLine(@"|/                                                      by Macrohard Studios\    |                                                                        |");
            Console.WriteLine(@"|                                                                            \   |                                                                        |");
            Console.WriteLine(@"|                                                                             \  |                                                                        |");
            Console.WriteLine(@"|                                                                              \ |                                                                        |");
            Console.WriteLine(@"|                                                                               \|________________________________________________________________________|");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| S T A R T | File Explorer | Settings | Information | Help |                                                                      | 11:12 09.11.1997 |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
        }
        static void ProVirus()
        {
            Console.WriteLine(@"___________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"| |._______________. Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea |   /||bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"| ||  ._________.  | Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea |  / ||bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"| ||  |  _ |_   |  | Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea |./| ||bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"| ||  |\/ \/ \_/|  | Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea || | ||bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"| ||  |\/\  /\_/|  | Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea ||_|_||bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"| ||  |  / . \_ |  | Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea || | ||bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"| ||  | / /|\_ \|  | Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea || | ||bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"| ||  |/_/_|__\_|  | Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea | \| ||bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"| ||          _    | Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea |  \ ||bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"| ||         [_]   | Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea Bad Idea |   \||bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"| ||               | Bad Idea Bad /____/ad Idea Ba/_/_____/d /_/  Bad Idea |     |bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"| ||               | Bad Idea Bad |  _ \/d Idea Ba| |_   _|/ | |  Bad Idea |     |bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"| ||               | Bad Idea Bad | |_) | /_/_/ /_| | | |  /_| | /__/ /_/_/|     |bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"| ||               | Bad Idea Bad |  _ < / _` |/ _` | | | / _` |/ _ \/ _` ||     |bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"| ||               | Bad Idea Bad | |_) | (_| | (_| |/| || (_| |  __/ (_| ||     |bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"| ||_______________|______________|____/ \__,_|\__,_|_____\__,_|\___|\__,_||     |bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"|/                                                          by a stupid User\    |bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"|                                                                            \   |bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"|                                                                             \  |bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"|                                                                              \ |bad idea bad idea bad idea bad idea bad idea bad idea bad idea bad idea |");
            Console.WriteLine(@"|                                                                               \|________________________________________________________________________|");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| Bad Idea! | Badideabadidea| Bad Idea | Bad Idea!!! | Idea |                                                                      | BA:DI DE.A!.!!!! |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
            Console.Write("Bad Idea!:");
        }
        static void libraryInfo()
        {
            Console.WriteLine(@"___________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|                                                                        |");
            Console.WriteLine(@"| | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|   /||   Library of Flefingbridge                                             |");
            Console.WriteLine(@"| ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |  / ||                                                                        |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|./| ||   5 User(s)                                                            |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||________________________________________________________________________|");
            Console.WriteLine(@"| ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -||_|_|| Name          | Join Date | Last Visit | Number of Books               |");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | ||_______________|___________|____________|_______________________________|");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|| | || Anonymous     | 01.01.1970| 43.54.1289 | 43242443543543265787989583610 |");
            Console.WriteLine(@"| ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- | \| ||_______________|___________|____________|_______________________________|");
            Console.WriteLine(@"| ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|  \ || Sans          | 09.10.2015| 15.09.2021 | 15                            |");
            Console.WriteLine(@"| ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |   \||_______________|___________|____________|_______________________________|");
            Console.WriteLine(@"| ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |     | LoremIpsum    | Unknown   | Unknown    | Unknown                       |");
            Console.WriteLine(@"| ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|     |_______________|___________|____________|_______________________________|");
            Console.WriteLine(@"| ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||     | User          | 09.11.1997| 09.11.1997 | 29                            |");
            Console.WriteLine(@"| ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||     |_______________|___________|____________|_______________________________|");
            Console.WriteLine(@"| ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |     | SpamGSpam     | 19.97.1997| 08.11.1997 | 1997                          |");
            Console.WriteLine(@"| ||_______________|_______________________________________________________|     |_______________|___________|____________|_______________________________|");
            Console.WriteLine(@"|/                                                      by Macrohard Studios\    |               |           |            |                               |");
            Console.WriteLine(@"|                                                                            \   |_______________|___________|____________|_______________________________|");
            Console.WriteLine(@"|                                                                             \  |               |           |            |                               |");
            Console.WriteLine(@"|                                                                              \ |_______________|___________|____________|_______________________________|");
            Console.WriteLine(@"|                                                                               \|_______________|___________|____________|_______________________________|");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| S T A R T | File Explorer | Settings | Information | Help |                                                                      | 11:12 09.11.1997 |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
        }
        static void FileExplorerPage1()
        {
            Console.WriteLine(@"___________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|       Name      | Type | Last Modified | Size                          |");
            Console.WriteLine(@"| | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|   /||_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |  / || HenkelSoftTBOS  | .exe | 01.01.19XX    | 1 MB                          |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|./| ||_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | || EntryNr2        | .txt | 31.09.2022    | 12 KB                         |");
            Console.WriteLine(@"| ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -||_|_||_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | || BadIdea.exe     | Virus| 09.11.1997    | 90 MB                         |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|| | ||_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- | \| || TicTacToe       | .exe | 07.07.1976    | 14 KB                         |");
            Console.WriteLine(@"| ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|  \ ||_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |   \|| theFuture       | .txt | Tomorrow      | 12 KB                         |");
            Console.WriteLine(@"| ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |     |_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|     | thePast         | .txt | Yesterday     | 12 KB                         |");
            Console.WriteLine(@"| ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||     |_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||     | thePresent      | .txt | Today         | 12 KB                         |");
            Console.WriteLine(@"| ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |     |_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||_______________|_______________________________________________________|     | EntryNr3        | .png | Never         | 33 KB                         |");
            Console.WriteLine(@"|/                                                      by Macrohard Studios\    |_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"|                                                                            \   | LibraryInfo     | .txt | 09.07.1989    | 23 KB                         |");
            Console.WriteLine(@"|                                                                             \  |_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"|                                                                              \ | artism          | .jpg | 00.00.0000    | 120 KB                        |");
            Console.WriteLine(@"|                                                                               \|_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"|                                                                                 Page 1/3                                                                |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| S T A R T | File Explorer | Settings | Information | Help |                                                                      | 11:12 09.11.1997 |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
        }
        static void FileExplorerPage2()
        {
            Console.WriteLine(@"___________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|       Name      | Type | Last Modified | Size                          |");
            Console.WriteLine(@"| | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|   /||_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |  / || FightingGameV1  | .exe | 11.11.2006    | 23 KB                         |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|./| ||_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | || HenkelSoft Word | .exe | 25.10.1976    | 91 KB                         |");
            Console.WriteLine(@"| ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -||_|_||_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | || GoodIdea        | .exe | 09.11.1997    | 90 MB                         |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|| | ||_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- | \| || FunnySkelePuns  | .txt | 01.01.1900    | 34 KB                         |");
            Console.WriteLine(@"| ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|  \ ||_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |   \|| AboutDoors      | .txt | 01.01.1997    | 43 KB                         |");
            Console.WriteLine(@"| ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |     |_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|     | AboutMacroHard  | .txt | 01.01.1997    | 51 KB                         |");
            Console.WriteLine(@"| ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||     |_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||     | AboutYou        | .txt | 01.01.1997    | 41 KB                         |");
            Console.WriteLine(@"| ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |     |_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||_______________|_______________________________________________________|     | NULL            | NULL | NULL          | NULL B                        |");
            Console.WriteLine(@"|/                                                      by Macrohard Studios\    |_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"|                                                                            \   | How2JoinLibrary | .txt | 01.01.1950    | 23 KB                         |");
            Console.WriteLine(@"|                                                                             \  |_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"|                                                                              \ | NSMBWii         | .exe | 21.12.2012    | 120 KB                        |");
            Console.WriteLine(@"|                                                                               \|_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"|                                                                                 Page 2/3                                                                |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| S T A R T | File Explorer | Settings | Information | Help |                                                                      | 11:12 09.11.1997 |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
        }
        static void FileExplorerPage3()
        {
            Console.WriteLine(@"___________________________________________________________________________________________________________________________________________________________");
            Console.WriteLine(@"|\__________________________________________________________________________/   .|       Name      | Type | Last Modified | Size                          |");
            Console.WriteLine(@"| | _______________-  --  --  --  --  --  --  --  --  --  --  --  --  --  -|   /||_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||  ._________.  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |  / || ManagingSim     | .exe | 03.05.1066    | 1 MB                          |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|./| ||_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | || WhatsAnAU       | .txt | 12.12.2015    | 12 KB                         |");
            Console.WriteLine(@"| ||  |____|____|  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -||_|_||_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||  |    |    |  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- || | || JustAnIdea      | .exe | 09.11.1997    | 90 MB                         |");
            Console.WriteLine(@"| ||  |    |    |  |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|| | ||_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"| ||  |____|____|  |--  --  --  --  --  --  --  --  --  --  --  --  --  -- | \| ||                 |      |               |                               |");
            Console.WriteLine(@"| ||          _    |  --  --  --  --  --  --  --  --  --  --  --  --  --  -|  \ ||                 |      |               |                               |");
            Console.WriteLine(@"| ||         [_]   |--  --  --  --  --  --  --  --  --  --  --  --  --  -- |   \||                 |      |               |                               |");
            Console.WriteLine(@"| ||               |  /____/  --  --  --  --  --  -- /__/ /___/-  //  /__/ |     |                 |      |               |                               |");
            Console.WriteLine(@"| ||               |--|  _ \/ /__/  /__//_/__/___/  / _ \/ ___|/ / | / _ \/|     |                 |      |               |                               |");
            Console.WriteLine(@"| ||               |  | | | |/ _ \// _ \| '__/ __|/| | | \___ \//_ || | | ||     |                 |      |               |                               |");
            Console.WriteLine(@"| ||               |--| |_| | (_) | (_) | |  \__ \/| |_| |___) | | || |_| ||     |                 |      |               |                               |");
            Console.WriteLine(@"| ||               |  |____/ \___/ \___/|_|/ |___/  \___/|____/  |_(_)___/ |     |                 |      |               |                               |");
            Console.WriteLine(@"| ||_______________|_______________________________________________________|     |                 |      |               |                               |");
            Console.WriteLine(@"|/                                                      by Macrohard Studios\    |                 |      |               |                               |");
            Console.WriteLine(@"|                                                                            \   |                 |      |               |                               |");
            Console.WriteLine(@"|                                                                             \  |                 |      |               |                               |");
            Console.WriteLine(@"|                                                                              \ |                 |      |               |                               |");
            Console.WriteLine(@"|                                                                               \|_________________|______|_______________|_______________________________|");
            Console.WriteLine(@"|                                                                                 Page 3/3                                                                |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|                                                                                                                                                         |");
            Console.WriteLine(@"|_________________________________________________________________________________________________________________________________________________________|");
            Console.WriteLine(@"| |\| S T A R T | File Explorer | Settings | Information | Help |                                                                      | 11:12 09.11.1997 |");
            Console.WriteLine(@"|__\|___________|_______________|__________|_____________|______|______________________________________________________________________|__________________|");
        }
        static void DesktopLogic()
        {
            Desktop();
            bool inDesktop = true;
            string where = "desktop";
            while (inDesktop)
                {
                if(where != "BadIdea")
                    {
                    string toDo;
                    Console.Write("Enter Command:");
                    toDo = Console.ReadLine();
                    switch (toDo)
                    {
                        case "explorer":
                            FileExplorerPage1();
                            where = "FileExplorer";
                            break;
                        case "LibraryInfo":
                            if (where == "FileExplorer")
                            {
                                libraryInfo();
                            }
                            else
                            {
                                error();
                            }
                            break;
                        case "page1":
                            if (where == "FileExplorer")
                            {
                                FileExplorerPage1();
                            }
                            else
                            {
                                error();
                            }
                            break;
                        case "page2":
                            if (where == "FileExplorer")
                            {
                                FileExplorerPage2();
                            }
                            else
                            {
                                error();
                            }
                            break;
                        case "page3":
                            if (where == "FileExplorer")
                            {
                                FileExplorerPage3();
                            }
                            else
                            {
                                error();
                            }
                            break;
                        case "ManagingSim":
                            if (where == "FileExplorer")
                            {
                                Managing.Game();
                            }
                            else
                            {
                                error();
                            }
                            break;
                        case "TicTacToe":
                            if (where == "FileExplorer")
                            {
                                TicTacToedotexe();
                                FileExplorerPage1();
                            }
                            else
                            {
                                error();
                            }
                            break;
                        case "help":
                            if (where == "desktop" || where == "info")
                            {
                                help();
                            }
                            else
                            {
                                error();
                            }
                            break;
                        case "desktop":
                            Desktop();
                            where = "desktop";
                            break;
                        case "settings":
                            settings();
                            where = "settings";
                            break;
                        case "Provirus":
                            if (where == "settings")
                            {
                                if (!antivirusActive)
                                {
                                    ProVirus();
                                    where = "BadIdea";
                                }
                                else
                                {
                                    antivirus();
                                    where = "settings";
                                }
                            }
                            else
                            {
                                error();
                            }
                            break;
                        case "HenkelSoftTBOS":
                            if (where == "FileExplorer")
                            {
                                TBOS.TBOS();
                            }
                            break;
                        case "EntryNr2":
                            if (where == "FileExplorer" && (Username == "SaHe" || Username == "admin"))
                            {
                                Entry2();
                            }
                            else
                            {
                                WrongAcc();
                            }
                            break;
                        case "EntryNr3":
                            if (where == "FileExplorer" && (Username == "SaHe" || Username == "admin"))
                            {
                                Entry3();
                            }
                            else
                            {
                                WrongAcc();
                            }
                            break;
                        case "artism":
                            if (where == "FileExplorer" && Username == "admin")
                            {
                                artism();
                            }
                            else
                            {
                                error();
                            }
                            break;
                        case "ThePast":
                            past();
                            break;
                        case "ThePresent":
                            if (where == "FileExplorer" && (Username == "SaHe" || Username == "admin"))
                            {
                                present();
                            }
                            else
                            {
                                WrongAcc();
                            }
                            break;
                        case "TheFuture":
                            if (where == "FileExplorer" && Username == "admin")
                            {
                                future();
                            }
                            else
                            {
                                error();
                            }
                            break;
                        case "BadIdea":
                            if (where == "FileExplorer")
                            {
                                if (!antivirusActive)
                                {
                                    ProVirus();
                                    where = "BadIdea";
                                }
                                else
                                {
                                    antivirus();
                                    where = "settings";
                                }
                            }
                            else
                            {
                                error();
                            }
                            break;
                        case "Antivirus":
                            if (where == "settings")
                            {
                                antivirus();
                                antivirusActive = true;
                            }
                            break;
                        case "exit":
                            if (where != "desktop")
                            {
                                where = "desktop";
                            }
                            Desktop();
                            break;
                        case "information":
                        case "info":
                            info();
                            where = "desktop";
                            break;
                        case "turnoff":
                            if (where == "desktop")
                            {
                                inDesktop = false;
                            }
                            else
                            {
                                error();
                            }
                            break;
                        default:
                            error();
                            break;
                    }
                }
            }
        }
    }
}