using System;
using System.IO;

namespace StuffFolder.HenkelsoftWord
{
    class FileReaderWriter
    {
        public int setYear;
        public static int year = 0;
        static string JustFile = "";
        public string TextProgram()
        {
            year = setYear;
            string FileName = Choosing();
            string Operative = "";
            while (Operative != "exit")
            {
                Console.WriteLine("What do you do with " + FileName + "? [file/read/edit/clear/copy/exit]");
                Operative = Console.ReadLine();
                if (Operative.ToLower() == "file")
                {
                    FileName = Choosing();
                }
                else if (Operative.ToLower() == "read")
                {
                    FileName = Reading(FileName);
                }
                else if (Operative.ToLower() == "edit")
                {
                    FileName = Writing(FileName);
                }
                else if (Operative.ToLower() == "clear")
                {
                    FileName = Clearing(FileName);
                }
                else if (Operative.ToLower() == "copy")
                {
                    FileName = Copying(FileName);
                }
                else if (Operative.ToLower() == "exit")
                {
                    Console.WriteLine("Closing Programm");
                }
                else
                {
                    Console.WriteLine("Unidentified input. Try again!");
                }
            }
            return FileName;
        }
        static string Choosing()
        {
            string FileName = "";
            bool exists = false;
            while (exists == false)
            {
                Console.WriteLine(@"______________________________________________________________________________");
                Console.WriteLine(@"| Henkelsoft Writer                                                _   8 | X |");
                Console.WriteLine(@"|________________________________________________________________________|___|");
                Console.WriteLine(@"|   _______                                                                  |");
                Console.WriteLine(@"|  |  H-S  |                                                                 |");
                Console.WriteLine(@"|  | Write |     Please enter File Name:                                     |");
                Console.WriteLine(@"|  |   r   |                                                                 |");
                Console.WriteLine(@"|  |_______|                                                                 |");
                Console.WriteLine(@"|                                                                            |");
                Console.WriteLine(@"|                                                                            |");
                Console.WriteLine(@"|                                                                            |");
                Console.WriteLine(@"|                                                                            |");
                Console.WriteLine(@"|                                                                            |");
                Console.WriteLine(@"|                                                                            |");
                Console.WriteLine(@"|                                                                            |");
                Console.WriteLine(@"|                                                                            |");
                Console.WriteLine(@"|                                                                            |");
                Console.WriteLine(@"|                                                                            |");
                Console.WriteLine(@"|                                                                            |");
                Console.WriteLine(@"|____________________________________________________________________________|");
                Console.WriteLine(@"| S T A R T | HS-Writer |                                    01:00 01.01." + year + "|");
                Console.WriteLine(@"|___________|___________|____________________________________________________|");
                Console.WriteLine(@"Enter File Name (Z:\HenkelSoftTextBasedOS\HenkelSoftTextBasedOS\stuff\HenkelsoftWord\)");
                JustFile = Console.ReadLine() + ".txt";
                FileName = @"Z:\HenkelSoftTextBasedOS\HenkelSoftTextBasedOS\stuff\HenkelsoftWord\" + JustFile;
                if (File.Exists(FileName))
                {
                    exists = true;
                }
                else
                {
                    Console.WriteLine(@"______________________________________________________________________________");
                    Console.WriteLine(@"| Henkelsoft Writer                                                _   8 | X |");
                    Console.WriteLine(@"|________________________________________________________________________|___|");
                    Console.WriteLine(@"|   _______                                                                  |");
                    Console.WriteLine(@"|  |  H-S  |                                                                 |");
                    Console.WriteLine(@"|  | Write |     Invalid File Name: Try again!                               |");
                    Console.WriteLine(@"|  |   r   |                                                                 |");
                    Console.WriteLine(@"|  |_______|                                                                 |");
                    Console.WriteLine(@"|                                                                            |");
                    Console.WriteLine(@"|                                                                            |");
                    Console.WriteLine(@"|                                                                            |");
                    Console.WriteLine(@"|                                                                            |");
                    Console.WriteLine(@"|                                                                            |");
                    Console.WriteLine(@"|                                                                            |");
                    Console.WriteLine(@"|                                                                            |");
                    Console.WriteLine(@"|                                                                            |");
                    Console.WriteLine(@"|                                                                            |");
                    Console.WriteLine(@"|                                                                            |");
                    Console.WriteLine(@"|                                                                            |");
                    Console.WriteLine(@"|____________________________________________________________________________|");
                    Console.WriteLine(@"| S T A R T | HS-Writer |                                    01:00 01.01." + year + "|");
                    Console.WriteLine(@"|___________|___________|____________________________________________________|");
                    exists = false;
                }
            }
            return FileName;
        }
        static string Reading(string FileName)
        {
            int restSpaces = 49 - JustFile.Length;
            Console.WriteLine(@"______________________________________________________________________________");
            Console.WriteLine(@"| Henkelsoft Writer                                                _   8 | X |");
            Console.WriteLine(@"|________________________________________________________________________|___|");
            Console.WriteLine(@"|   _______                                                                  |");
            Console.WriteLine(@"|  |  H-S  |                                                                 |");
            Console.Write(@"|  | Write |     Showing "+ JustFile + "...");
            while(restSpaces > 0)
            {
                Console.Write(" ");
                restSpaces--;
            }
            Console.WriteLine("|");
            Console.WriteLine(@"|  |   r   |                                                                 |");
            Console.WriteLine(@"|  |_______|                                                                 |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|____________________________________________________________________________|");
            Console.WriteLine(@"| S T A R T | HS-Writer |                                    01:00 01.01." + year + "|");
            Console.WriteLine(@"|___________|___________|____________________________________________________|");
            string FileContent = File.ReadAllText(FileName);
            Console.WriteLine(FileContent);
            return FileName;
        }
        static string Writing(string FileName)
        {
            string FileContent = File.ReadAllText(FileName);
            Console.WriteLine(@"______________________________________________________________________________");
            Console.WriteLine(@"| Henkelsoft Writer                                                _   8 | X |");
            Console.WriteLine(@"|________________________________________________________________________|___|");
            Console.WriteLine(@"|   _______                                                                  |");
            Console.WriteLine(@"|  |  H-S  |                                                                 |");
            Console.WriteLine(@"|  | Write |     Writing in File...                                          |");
            Console.WriteLine(@"|  |   r   |                                                                 |");
            Console.WriteLine(@"|  |_______|                                                                 |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|____________________________________________________________________________|");
            Console.WriteLine(@"| S T A R T | HS-Writer |                                    01:00 01.01." + year + "|");
            Console.WriteLine(@"|___________|___________|____________________________________________________|");
            Console.WriteLine(FileContent);
            FileContent += "\n" + Console.ReadLine();
            File.WriteAllText(FileName, FileContent);
            return FileName;
        }
        static string Clearing(string FileName)
        {
            int restSpaces = 48 - JustFile.Length;
            string FileContent = "HenkelSoft Writer File:";
            Console.WriteLine(@"______________________________________________________________________________");
            Console.WriteLine(@"| Henkelsoft Writer                                                _   8 | X |");
            Console.WriteLine(@"|________________________________________________________________________|___|");
            Console.WriteLine(@"|   _______                                                                  |");
            Console.WriteLine(@"|  |  H-S  |                                                                 |"); 
            Console.Write(@"|  | Write |     Clearing " + JustFile + "...");
            while (restSpaces > 0)
            {
                Console.Write(" ");
                restSpaces--;
            }
            Console.WriteLine("|");
            Console.WriteLine(@"|  |   r   |                                                                 |");
            Console.WriteLine(@"|  |_______|                                                                 |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|____________________________________________________________________________|");
            Console.WriteLine(@"| S T A R T | HS-Writer |                                    01:00 01.01." + year + "|");
            Console.WriteLine(@"|___________|___________|____________________________________________________|");
            File.WriteAllText(FileName, FileContent);
            Console.WriteLine(@"______________________________________________________________________________");
            Console.WriteLine(@"| Henkelsoft Writer                                                _   8 | X |");
            Console.WriteLine(@"|________________________________________________________________________|___|");
            Console.WriteLine(@"|   _______                                                                  |");
            Console.WriteLine(@"|  |  H-S  |                                                                 |");
            Console.WriteLine(@"|  | Write |     Cleared File!                                               |");
            Console.WriteLine(@"|  |   r   |                                                                 |");
            Console.WriteLine(@"|  |_______|                                                                 |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|____________________________________________________________________________|");
            Console.WriteLine(@"| S T A R T | HS-Writer |                                    01:00 01.01." + year + "|");
            Console.WriteLine(@"|___________|___________|____________________________________________________|");
            return FileName;
        }
        static string Copying(string FileName1)
        {
            int restSpaces = 48 - JustFile.Length;
            Console.WriteLine(@"______________________________________________________________________________");
            Console.WriteLine(@"| Henkelsoft Writer                                                _   8 | X |");
            Console.WriteLine(@"|________________________________________________________________________|___|");
            Console.WriteLine(@"|   _______                                                                  |");
            Console.WriteLine(@"|  |  H-S  |                                                                 |");
            Console.WriteLine(@"|  | Write |     Please enter new File Name:                                 |");
            Console.WriteLine(@"|  |   r   |                                                                 |");
            Console.WriteLine(@"|  |_______|                                                                 |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|____________________________________________________________________________|");
            Console.WriteLine(@"| S T A R T | HS-Writer |                                    01:00 01.01." + year + "|");
            Console.WriteLine(@"|___________|___________|____________________________________________________|");
            string FileName2 = @"Z:\HenkelSoftTextBasedOS\HenkelSoftTextBasedOS\stuff\HenkelsoftWord\" + Console.ReadLine() + ".txt";
            Console.WriteLine(@"______________________________________________________________________________");
            Console.WriteLine(@"| Henkelsoft Writer                                                _   8 | X |");
            Console.WriteLine(@"|________________________________________________________________________|___|");
            Console.WriteLine(@"|   _______                                                                  |");
            Console.WriteLine(@"|  |  H-S  |                                                                 |");
            Console.Write(@"|  | Write |     Copying " + JustFile + "...");
            while (restSpaces > 0)
            {
                Console.Write(" ");
                restSpaces--;
            }
            Console.WriteLine("|");
            Console.WriteLine(@"|  |   r   |                                                                 |");
            Console.WriteLine(@"|  |_______|                                                                 |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|____________________________________________________________________________|");
            Console.WriteLine(@"| S T A R T | HS-Writer |                                    01:00 01.01." + year + "|");
            Console.WriteLine(@"|___________|___________|____________________________________________________|");
            Console.WriteLine("Copying " + FileName1 + " to " + FileName2 + "...");
            string FileContent = File.ReadAllText(FileName1);
            File.WriteAllText(FileName2, FileContent);
            Console.WriteLine(@"______________________________________________________________________________");
            Console.WriteLine(@"| Henkelsoft Writer                                                _   8 | X |");
            Console.WriteLine(@"|________________________________________________________________________|___|");
            Console.WriteLine(@"|   _______                                                                  |");
            Console.WriteLine(@"|  |  H-S  |                                                                 |");
            Console.WriteLine(@"|  | Write |     Copied File!                                                |");
            Console.WriteLine(@"|  |   r   |                                                                 |");
            Console.WriteLine(@"|  |_______|                                                                 |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|____________________________________________________________________________|");
            Console.WriteLine(@"| S T A R T | HS-Writer |                                    01:00 01.01." + year + "|");
            Console.WriteLine(@"|___________|___________|____________________________________________________|");
            Console.WriteLine("Copied " + FileName1 + " to " + FileName2);
            return FileName1;
        }
    }
}