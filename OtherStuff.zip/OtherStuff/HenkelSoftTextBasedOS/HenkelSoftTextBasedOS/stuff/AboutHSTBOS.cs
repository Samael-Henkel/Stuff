using System;
using System.Threading;
using System.IO;

namespace StuffFolder.AboutHSTBOS
{
    class TXT_About
    {
        public void aboutHStxt(int year)
        {
            bool inAbout = true;
            string toDo;
            while (inAbout)
            {
                Console.WriteLine(@"______________________________________________________________________________");
                Console.WriteLine(@"| AboutHSTBOS.txt                                                  _   8 | X |");
                Console.WriteLine(@"|________________________________________________________________________|___|");
                Console.WriteLine(@"| HenkelSofts first Operating System started Development in " + (year - 10) + " in Flefing- |");
                Console.WriteLine(@"| bridge, Northumbriannna, England. Competition was rampant, as MacroHard re-|");
                Console.WriteLine(@"| leased MH-DBOS in " + (year - 7) + ". Development on HSTBOS had to stop for a bit during |");
                Console.WriteLine(@"| the great Panic of " + (year - 5) + ", which caused 69 different Software-Companies to go|");
                Console.WriteLine(@"| bankrupt, including MacroHard. MacroHard was bought by the CEO of Henkel-  |");
                Console.WriteLine(@"| Soft at the Time, Trands Schelper, Inventor of the Vacso Corroticks, the   |");
                Console.WriteLine(@"| most often bought Product by shreake men over the age of 53. The first Lau-|");
                Console.WriteLine(@"| nch was unsuccessful due to the Video Game Crash of " + (year - 5) + ", which nearly cau-|");
                Console.WriteLine(@"| sed HenkelSoft to go bankrupt themselves. After 5 more Years of Work spent |");
                Console.WriteLine(@"| on TBOS, it was finally time to release it. Due to the Bankrupcy of Henkel-|");
                Console.WriteLine(@"| soft in " + (year + 5) + ", TBOS was nearly lost to Time, until Samael Henkel found a co-|");
                Console.WriteLine(@"| py, thought it was bad, even by " + year + " standards, and made a Version that is |");
                Console.WriteLine(@"| better than the Original.                                                  |");
                Console.WriteLine(@"|                                                                            |");
                Console.WriteLine(@"| Type 'exit' to return.                                                     |");
                Console.WriteLine(@"|                                       TBOS was made " + year + " by HenkelSoft Inc.|");
                Console.WriteLine(@"|____________________________________________________________________________|");
                Console.WriteLine(@"| S T A R T |  AboutHSTBOS.TXT  |                                            |");
                Console.WriteLine(@"|___________|___________________|____________________________________________|");
                toDo = Console.ReadLine();
                if(toDo == "exit")
                {
                    inAbout = false; 
                } else
                {
                    string Year = Convert.ToString(year - 5); 
                    Console.WriteLine(@"______________________________________________________________________________");
                    Console.WriteLine(@"| AboutHSTBOS.txt                                                  _   8 | X |");
                    Console.WriteLine(@"|________________________________________________________________________|___|");
                    Console.WriteLine(@"| HenkelSofts first Operating System started Development in " + (year - 10) + " in Flefing- |");
                    Console.WriteLine(@"| bridge, Northumbriannna, England. Competition was rampant, as MacroHard re-|");
                    Console.WriteLine(@"| leased MH-DBOS in " + (year - 7) + ". Development on HSTBOS had to stop for a bit during |");
                    Console.WriteLine(@"| the great Panic of 1/_______________________________/ftware-Companies to go|");
                    Console.WriteLine(@"| bankrupt, including |Error                     | X | y the CEO of Henkel-  |");
                    Console.WriteLine(@"| Soft at the Time, Tr|__________________________|___| cso Corroticks, the   |");
                    Console.WriteLine(@"| most often bought Pr|    .                         |  of 53. The first Lau-|");
                    Console.WriteLine(@"| nch was unsuccessful|   / \    Command not found   | " + Year[1..] + ", which nearly cau-|");
                    Console.WriteLine(@"| sed HenkelSoft to go|  / ! \     Try again!        | e Years of Work spent |");
                    Console.WriteLine(@"| on TBOS, it was fina| /_____\          ____________| e Bankrupcy of Henkel-|");
                    Console.WriteLine(@"| soft in " + (year + 5) + ", TBOS w|                 |     Ok     | ael Henkel found a co-|");
                    Console.WriteLine(@"| py, thought it was b|_________________|____________|/ade a Version that is |");
                    Console.WriteLine(@"| better than the Original.                                                  |");
                    Console.WriteLine(@"|                                                                            |");
                    Console.WriteLine(@"| Type 'exit' to return.                                                     |");
                    Console.WriteLine(@"|                                       TBOS was made " + year + " by HenkelSoft Inc.|");
                    Console.WriteLine(@"|____________________________________________________________________________|");
                    Console.WriteLine(@"| S T A R T |  AboutHSTBOS.TXT  |                                            |");
                    Console.WriteLine(@"|___________|___________________|____________________________________________|");
                }
            }
        }
    }
}