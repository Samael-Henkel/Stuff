using System;
using DieSammlungFolder.dieSammlung;

namespace DieSammlungFolder
{
    class Die_Sammlung_Folder
    {
        readonly dieSammlungProgramm Sammlung = new();
        public void OpenFolder(int year)
        {
            bool inStuff = true;
            string toDo;
            Console.WriteLine(@"______________________________________________________________________________");
            Console.WriteLine(@"| DieSammlung                                                      _   8 | X |");
            Console.WriteLine(@"|________________________________________________________________________|___|");
            Console.WriteLine(@"| Icon    | Name                      | Type               | Size            |");
            Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
            Console.WriteLine(@"|  O--O-� |                           |                    |                 |");
            Console.WriteLine(@"|   &     | Die Sammlung              | Sammlung           | 23 KB           |");
            Console.WriteLine(@"|   --)   |                           |                    |                 |");
            Console.WriteLine(@"|---------|---------------------------|--------------------|-----------------|");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|                                                                            |");
            Console.WriteLine(@"|____________________________________________________________________________|");
            Console.WriteLine(@"| S T A R T | DieSammlung |                                 01:00 01.01." + year + " |");
            Console.WriteLine(@"|___________|_____________|__________________________________________________|");
            while (inStuff == true)
            {
                Console.Write("What do you want to do? (Enter help for help):");
                toDo = Console.ReadLine();
                switch (toDo)
                {
                    case "help":
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| DieSammlung                                                      _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"|  __________                                                                |");
                        Console.WriteLine(@"|  |      | |                                                                |");
                        Console.WriteLine(@"|  |      | |  DieSammlung - Folder                                          |");
                        Console.WriteLine(@"|  |      | |                                                                |");
                        Console.WriteLine(@"|  |______|_|                                                                |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|  open - open a Program/File                                                |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|  view - view the Contents of this folder                                   |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|  exit - leave the folder                                                   |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|  help - show this list                                                     |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                       TBOS was made " + year + " by HenkelSoft Inc.|");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T | DieSammlung |                                 01:00 01.01." + year + " |");
                        Console.WriteLine(@"|___________|_____________|__________________________________________________|");
                        break;
                    case "view":
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| DieSammlung                                                      _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"| Icon    | Name                      | Type               | Size            |");
                        Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
                        Console.WriteLine(@"|  O--O-� |                           |                    |                 |");
                        Console.WriteLine(@"|   &     | Die Sammlung              | Sammlung           | 23 KB           |");
                        Console.WriteLine(@"|   --)   |                           |                    |                 |");
                        Console.WriteLine(@"|---------|---------------------------|--------------------|-----------------|");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T | DieSammlung |                                 01:00 01.01." + year + " |");
                        Console.WriteLine(@"|___________|_____________|__________________________________________________|");
                        break;
                    case "open":
                        Console.Write("What file/program do you want to open?:");
                        string OpenFile = Console.ReadLine();
                        switch (OpenFile)
                        {
                            case "Die Sammlung":
                            case "1":
                                Sammlung.Main();
                                break;
                            default:
                                Console.WriteLine(@"______________________________________________________________________________");
                                Console.WriteLine(@"| DieSammlung                                                      _   8 | X |");
                                Console.WriteLine(@"|________________________________________________________________________|___|");
                                Console.WriteLine(@"| Icon    | Name                      | Type               | Size            |");
                                Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
                                Console.WriteLine(@"|  O--O-� |          /_______________________________/     |                 |");
                                Console.WriteLine(@"|   &     | Die Samml| Error                        |      | 23 KB           |");
                                Console.WriteLine(@"|   --)   |          |______________________________|      |                 |");
                                Console.WriteLine(@"|---------|----------|    .                         | -----|-----------------|");
                                Console.WriteLine(@"|                    |   / \ File/Program not found!|                        |");
                                Console.WriteLine(@"|                    |  / ! \   Try again!          |                        |");
                                Console.WriteLine(@"|                    | /_____\          ____________|                        |");
                                Console.WriteLine(@"|                    |                 |     Ok     |                        |");
                                Console.WriteLine(@"|                    |_________________|____________|/                       |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|                                                                            |");
                                Console.WriteLine(@"|____________________________________________________________________________|");
                                Console.WriteLine(@"| S T A R T | DieSammlung |                                 01:00 01.01." + year + " |");
                                Console.WriteLine(@"|___________|_____________|__________________________________________________|");
                                break;
                        }
                        break;
                    case "Is there a Secret":
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| DieSammlung                                                      _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"|  __________                                                                |");
                        Console.WriteLine(@"|  |      | |                                                                |");
                        Console.WriteLine(@"|  |      | |  Yes, but it requieres a secret password to find               |");
                        Console.WriteLine(@"|  |      | |  This isnt it btw...                                           |");
                        Console.WriteLine(@"|  |______|_|                                                                |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                       TBOS was made " + year + " by HenkelSoft Inc.|");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T | DieSammlung |                                 01:00 01.01." + year + " |");
                        Console.WriteLine(@"|___________|_____________|__________________________________________________|");
                        break;
                    case "P455W0RT":
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| DieSammlung                                                      _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"|  __________                                                                |");
                        Console.WriteLine(@"|  |      | |                                                                |");
                        Console.WriteLine(@"|  |      | |  Username: admin                                               |");
                        Console.WriteLine(@"|  |      | |  Password Hint: Literally                                      |");
                        Console.WriteLine(@"|  |______|_|  This is supposed to be a secret. Did you enter 'Die Sammlung' |");
                        Console.WriteLine(@"|              or did you look it up on the Internet or in the code?         |");
                        Console.WriteLine(@"|              The next secret is a bit trashy                               |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                       TBOS was made " + year + " by HenkelSoft Inc.|");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T | DieSammlung |                                 01:00 01.01." + year + " |");
                        Console.WriteLine(@"|___________|_____________|__________________________________________________|");
                        break;
                    case "exit":
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| DieSammlung                                                      _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"|  __________                                                                |");
                        Console.WriteLine(@"|  |      | |                                                                |");
                        Console.WriteLine(@"|  |      | |  Exiting DieSammlung...                                        |");
                        Console.WriteLine(@"|  |      | |                                                                |");
                        Console.WriteLine(@"|  |______|_|                                                                |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                       TBOS was made " + year + " by HenkelSoft Inc.|");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T | DieSammlung |                                 01:00 01.01." + year + " |");
                        Console.WriteLine(@"|___________|_____________|__________________________________________________|");
                        inStuff = false;
                        break;
                    default:
                        Console.WriteLine(@"______________________________________________________________________________");
                        Console.WriteLine(@"| DieSammlung                                                      _   8 | X |");
                        Console.WriteLine(@"|________________________________________________________________________|___|");
                        Console.WriteLine(@"| Icon    | Name                      | Type               | Size            |");
                        Console.WriteLine(@"|_________|___________________________|____________________|_________________|");
                        Console.WriteLine(@"|  O--O-� |          /_______________________________/     |                 |");
                        Console.WriteLine(@"|   &     | Die Samml| Error                        |      | 69 MB           |");
                        Console.WriteLine(@"|   --)   |          |______________________________|      |                 |");
                        Console.WriteLine(@"|---------|----------|    .                         | -----|-----------------|");
                        Console.WriteLine(@"|                    |   / \    Command not found!  |                        |");
                        Console.WriteLine(@"|                    |  / ! \   Try again!          |                        |");
                        Console.WriteLine(@"|                    | /_____\          ____________|                        |");
                        Console.WriteLine(@"|                    |                 |     Ok     |                        |");
                        Console.WriteLine(@"|                    |_________________|____________|/                       |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|                                                                            |");
                        Console.WriteLine(@"|____________________________________________________________________________|");
                        Console.WriteLine(@"| S T A R T | DieSammlung |                                 01:00 01.01." + year + " |");
                        Console.WriteLine(@"|___________|_____________|__________________________________________________|");
                        break;
                }
            }
        }
    }
}