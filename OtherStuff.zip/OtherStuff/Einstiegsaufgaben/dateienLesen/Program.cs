﻿using System;
using System.IO;

namespace dateienLesen
{
    class FileReaderWriter
    {
        public string TextProgram()
        {
            string FileName = Choosing();
            string Operative = "";
            while (Operative != "exit")
            {
                Console.WriteLine("What do you do with " + FileName + "? [file/read/edit/clear/copy/exit]");
                Operative = Console.ReadLine();
                if (Operative.ToLower() == "file")
                {
                    FileName = Choosing();
                }
                else if (Operative.ToLower() == "read")
                {
                    FileName = Reading(FileName);
                }
                else if(Operative.ToLower() == "edit")
                {
                    FileName = Writing(FileName);
                }
                else if(Operative.ToLower() == "clear")
                {
                    FileName = Clearing(FileName);
                }
                else if(Operative.ToLower() == "copy")
                {
                    FileName = Copying(FileName);
                }
                else if(Operative.ToLower() == "exit")
                {
                    Console.WriteLine("Closing Programm");
                } else
                {
                    Console.WriteLine("Unidentified input. Try again!");
                }
            }
            return FileName;
        }
        static string Choosing()
        {
            string FileName = "";
            bool exists = false;
            while (exists == false)
            {
                Console.WriteLine(@"Enter File Name (Z:\)");
                FileName = @"Z:\" + Console.ReadLine() + ".txt";
                if (File.Exists(FileName))
                {
                    exists = true;
                } else
                {
                    Console.WriteLine("Invalid Filename");
                    exists = false;
                }
            }
            return FileName;
        }
        static string Reading(string FileName)
        {
            Console.WriteLine("Showing: " + FileName);
            string FileContent = File.ReadAllText(FileName);
            Console.WriteLine(FileContent);
            return FileName;
        }
        static string Writing(string FileName)
        {
            string FileContent = File.ReadAllText(FileName);
            Console.WriteLine("Write:");
            Console.WriteLine(FileContent);
            FileContent += "\n" + Console.ReadLine();
            File.WriteAllText(FileName, FileContent);
            return FileName;
        }
        static string Clearing(string FileName)
        {
            string FileContent = "";
            Console.WriteLine("Clearing " + FileName + "...");
            File.WriteAllText(FileName, FileContent);
            Console.WriteLine("Cleared " + FileName);
            return FileName;
        }
        static string Copying(string FileName1)
        {
            Console.WriteLine("Choose the name for the new file:");
            string FileName2 = @"Z:\" + Console.ReadLine() + ".txt";
            Console.WriteLine("Copying " + FileName1 + " to " + FileName2 + "...");
            string FileContent = File.ReadAllText(FileName1);
            File.WriteAllText(FileName2, FileContent);
            Console.WriteLine("Copied " + FileName1 + " to " + FileName2);
            return FileName1;
        }
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            FileReaderWriter Word = new FileReaderWriter();
            Word.TextProgram();
        }
    }
}
