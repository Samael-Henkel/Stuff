﻿using System;

namespace TheCrowsNest
{
    class Program
    {
        static void Main(string[] args)
        {
            CrowsNest();
        }

        static string CrowsNest()
        {
            bool SeeSomething = true;
            string ThingsList = "bluewhale, octopus, dolphin, crab, ";
            string SeenThing = " ";
            string aeiou = "a e i o u A E I O U";
            Console.WriteLine("What do you see?: ");
            while (SeeSomething == true)
            {
                SeenThing = Console.ReadLine();
                bool IsItOnTheList = ThingsList.Contains(SeenThing);
                string firstLetter = SeenThing.Substring(0, 1);
                bool vowelCheck = aeiou.Contains(firstLetter);
                if (IsItOnTheList == true)
                {
                    if (vowelCheck == true)
                    {
                        Console.WriteLine("Aye Captain, there is an " + SeenThing + " over there!");
                    } else
                    {
                        Console.WriteLine("Aye Captain, there is a " + SeenThing + " over there!");
                    }
                } else
                {
                    if (vowelCheck == true)
                    {
                        Console.WriteLine("Aye Captain, i dont know what it is! Looks like an " + SeenThing + "!");
                        ThingsList += SeenThing + ", ";
                    }
                    else
                    {
                        Console.WriteLine("Aye Captain, i dont know what it is! Looks like a " + SeenThing + "!");
                        ThingsList += SeenThing + ", ";
                    }
                }
                Console.WriteLine("You see something else?[Y/N]");
                string YesNo = " ";
                while(YesNo != "N" && YesNo != "Y")
                {
                    YesNo = Console.ReadLine();
                    if (YesNo == "Y")
                    {
                        Console.WriteLine("What else do you see?: ");
                        SeeSomething = true;
                    } else if (YesNo == "N")
                    {
                        Console.WriteLine("Nothing? Then come back down!");
                        SeeSomething = false;
                    } else
                    {
                        Console.WriteLine("Huh? What did you say? I cant understand!");
                    }
                }
                
            }
            return "Its a pirates Life for me";
        }
    }
}
