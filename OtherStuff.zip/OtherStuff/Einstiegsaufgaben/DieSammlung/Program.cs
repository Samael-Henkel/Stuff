﻿using System;
using System.IO;

namespace DieSammlung
{
    class Program
    {
        static void Main()
        {
            string cashSave = @"Z:\Einstiegsaufgaben\DieSammlung\bin\secret\cash.txt";
            string login = password();
            string todo = " ";
            int cash = Convert.ToInt32(File.ReadAllText(cashSave));
            if (login == "login" | login == "secret")
            {
                Console.WriteLine("d8888b. d888888b d88888b       .d8888.  .d8b.  .88b  d88. .88b  d88. db      db    db d8b   db  d888b  ");
                Console.WriteLine("88  `8D   `88'   88'           88'  YP d8' `8b 88'YbdP`88 88'YbdP`88 88      88    88 888o  88 88' Y8b ");
                Console.WriteLine("88   88    88    fizzbuzz      `420.   88ooo88 88  88  88 88  88  88 88      88    88 88V8o 88 88      ");
                Console.WriteLine("88   88    88    88~~~~~         `Y8b. 88~~~88 88  88  88 88  88  88 88      88    88 88 V8o88 88  ooo ");
                Console.WriteLine("88  .8D   .88.   88.           db   8D 88   88 88  88  88 88  88  88 88booo. 88b  d88 88  V888 88. ~8~ ");
                Console.WriteLine("Y8888D' Y888888P Y88888P       `8888Y' YP   YP YP  YP  YP YP  YP  YP Y88888P ~Y8888P' VP   V8P  Y888P  ");
                if (login == "secret")
                {
                    Console.WriteLine("Geheime Version?");
                } else
                {
                    Console.WriteLine("Ver. 1.7(.txt Update)    Gemacht von Samael Henkel");
                }
                while (todo != "exit")
                {
                    if (login == "secret")
                    {
                        Console.WriteLine("Was wollen Sie tun? [d6, fizzbuzz, guessinggame, word, drawstar, web, exit]");
                    } else
                    {
                        Console.WriteLine("Was wollen Sie tun? [d6, fizzbuzz, guessinggame, word, exit]");
                    }
                    todo = Console.ReadLine();
                    if (todo == "d6")
                    {
                        Console.WriteLine("Öffne Würfelprogramm...");
                        string weiterwürfeln = "0";
                        while (weiterwürfeln == "0")
                        {
                            weiterwürfeln = Würfeln();
                        }
                    } else if (todo == "fizzbuzz")
                    {
                        einsbisx();
                    } else if (todo == "guessinggame") {
                        ratespiel();
                    } else if (todo == "word")
                    {
                        writing();
                    } else if (todo == "exit")
                    {
                        Console.WriteLine("Schliesse Programm...");
                    } else if (todo == "aeiou")
                    {
                        Console.WriteLine("a e i o u");
                        Console.WriteLine("a  e  i  o  u");
                        Console.WriteLine("a   e   i   o   u");
                        Console.WriteLine("a    e    i    o    u");
                        Console.WriteLine("a     e     i     o     u");

                    } else if (todo == "drawstar")
                    {
                        if (login == "secret")
                        {
                            Zeichne();
                        }else
                        {
                            Console.WriteLine("Dieses Programm existiert nicht in dieser Sammlung");
                        }
                    } else if (todo == "web")
                    {
                        if (login == "secret")
                        {
                            cash = web(cash, cashSave);
                        }
                        else
                        {
                            Console.WriteLine("Dieses Programm existiert nicht in dieser Sammlung");
                        }
                    } else
                    {
                        Console.WriteLine("Dieses Programm existiert nicht in dieser Sammlung");
                    }
                }
            }
        }
        static string Zeichne()
        {
            int check = 0;
            while (check == 0)
            {
                Console.WriteLine("Was wollen sie zeichnen? [sanduhr, pyramide, 4eck, exit]");
                string auswahl = Console.ReadLine();
                if (auswahl == "pyramide")
                {
                    pyramide();
                }
                else if (auswahl == "exit")
                {
                    Console.WriteLine("Schliesse Zeichenprogramm");
                    check = 1;
                }
                else if (auswahl == "sanduhr")
                {
                    Sanduhr();
                }
                else if (auswahl == "4eck")
                {
                    Viereck();
                }
                else
                {
                    Console.WriteLine("Ungültige Eingabe!");
                }

            }
            return "1";
        }
        static string pyramide()
        {
            int weiter = 0;
            while (weiter == 0)
            {
                Console.WriteLine("Wieviele Lagen soll die Pyramide haben?");
                int lagenanzahl = Convert.ToInt32(Console.ReadLine());
                if (lagenanzahl > 20)
                {
                    Console.WriteLine("Zuviele Lagen!");
                }
                else
                {
                    for (int i = 1; i <= lagenanzahl; i++)
                    {
                        for (int leere = 1; leere <= lagenanzahl - i; leere++)
                        {
                            Console.Write(" ");
                        }
                        for (int sterne = 1; sterne <= 2 * i - 1; sterne++)
                        {
                            Console.Write("*");
                        }
                        Console.Write("\n");
                    }
                    Console.WriteLine("Noch eine Pyramide zeichnen? [Y/N]");
                    string zustimmen = Console.ReadLine();
                    if (zustimmen == "Y" || zustimmen == "y")
                    {
                        weiter = 0;
                    }
                    else if (zustimmen == "N" || zustimmen == "n")
                    {
                        Console.WriteLine("Schliesse Pyramidenzeichnen...");
                        weiter = 1;
                    }
                }
            }
            return "1";
        }
        static string Sanduhr()
        {
            int weiter = 0;
            while (weiter == 0)
            {
                Console.WriteLine("Wähle die Höhe der Sanduhr");
            int höhe = Convert.ToInt32(Console.ReadLine());
                if (höhe > 20)
                {
                    Console.WriteLine("Zu gross!");
                }
                else
                {
                    for (int j = höhe; j >= 2; j--)
                    {
                        for (int leere = 0; leere <= höhe - j; leere++)
                        {
                            Console.Write(" ");
                        }
                        for (int sterne = 1; sterne <= 2 * j - 1; sterne++)
                        {
                            Console.Write("*");
                        }
                        Console.Write("\n");
                    }
                    for (int i = 1; i <= höhe; i++)
                    {
                        for (int leere = 1; leere <= höhe - i + 1; leere++)
                        {
                            Console.Write(" ");
                        }
                        for (int sterne = 1; sterne <= 2 * i - 1; sterne++)
                        {
                            Console.Write("*");
                        }
                        Console.Write("\n");
                    }
                    Console.WriteLine("Noch eine Sanduhr zeichnen? [Y/N]");
                    string zustimmen = Console.ReadLine();
                    if (zustimmen == "Y" || zustimmen == "y")
                    {
                        weiter = 0;
                    }
                    else if (zustimmen == "N" || zustimmen == "n")
                    {
                        Console.WriteLine("Schliesse Sanduhrzeichnen...");
                        weiter = 1;
                    }
                }
            }
            return "1";
        }
        static string Viereck()
        {
            int weiter = 0;
            while (weiter == 0)
            {
                Console.WriteLine("Wähle die Höhe des Vierecks");
                int höhe = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Wähle die Breite des Vierecks");
                int breite = Convert.ToInt32(Console.ReadLine());
                for (int i = 1; i <= höhe; i++)
                {
                    for (int j = 1; j <= breite; j++)
                    {
                        Console.Write("*");
                    }
                    Console.Write("\n");
                }
                Console.WriteLine("Noch ein Viereck zeichnen? [Y/N]");
                string zustimmen = Console.ReadLine();
                if (zustimmen == "Y" || zustimmen == "y")
                {
                    weiter = 0;
                }
                else if (zustimmen == "N" || zustimmen == "n")
                {
                    Console.WriteLine("Schliesse Viereckzeichnen...");
                    weiter = 1;
                }

            }
            return "1";
        }

        static string ratespiel()
        {
            int n = 0;
            while (n == 0)
            {
                Random zufall = new Random();
                int zahl1 = 0;
                bool istZahl1Zahl = false;
                while (istZahl1Zahl == false)
                {
                    Console.WriteLine("Wähle eine untere Grenze");
                    string Nutzerzahl = Console.ReadLine();
                    if (int.TryParse(Nutzerzahl, out int value))
                    {
                        zahl1 = Convert.ToInt32(Nutzerzahl);
                        istZahl1Zahl = true;
                    }
                    else
                    {
                        Console.WriteLine("Ungültige Eingabe");
                    }
                }
                int zahl2 = 0;
                bool istZahl2Zahl = false;
                while (istZahl2Zahl == false)
                {
                    Console.WriteLine("Wähle eine untere Grenze");
                    string Nutzerzahl = Console.ReadLine();
                    if (int.TryParse(Nutzerzahl, out int value))
                    {
                        zahl2 = Convert.ToInt32(Nutzerzahl);
                        istZahl2Zahl = true;
                    }
                    else
                    {
                        Console.WriteLine("Ungültige Eingabe");
                    }
                }
                int zufallzahl = zufall.Next(zahl1, zahl2);
                int geraten = 0;
                int versuche = 0;
                while (geraten != zufallzahl)
                {
                    bool istZahl = false;
                    while(istZahl == false) 
                    { 
                        Console.WriteLine("Gib eine Zahl ein.");
                        string ichRate = Console.ReadLine();
                        if(int.TryParse(ichRate, out int value))
                        {
                            geraten = Convert.ToInt32(ichRate);
                            istZahl = true;
                        } else
                        {
                            Console.WriteLine("Ungültige Eingabe");
                        }
                    }
                    if (geraten < zahl1 || geraten > zahl2)
                    {
                        Console.WriteLine("Ausserhalb der angegeben Reichweite!");
                    }
                    else if (geraten > zufallzahl)
                    {
                        Console.WriteLine("Zu gross");
                        versuche++;
                    }
                    else if (geraten < zufallzahl)
                    {
                        Console.WriteLine("Zu klein");
                        versuche++;
                    }
                }
                Console.WriteLine("Nach " + versuche + " Versuchen richtig geraten! " +
                    "Nochmal spielen? [Y/N]");
                string best = Console.ReadLine();
                if (best == "N" || best == "n")
                {
                    n = 1;
                }
                else if (best == "Y" || best == "y")
                {
                    n = 0;
                }
            }
            return "0";
        }
        static string Würfeln()
        {
            Console.WriteLine("Würfeln? [Y/N]");
            string Zusage = Console.ReadLine();
            if (Zusage == "Y" || Zusage == "y")
            {
                Random zufall = new Random();
                string Ergebnis = Convert.ToString(zufall.Next(1, 7));
                Console.WriteLine("Der Würfel zeigt eine " + Ergebnis);
                return "0";
            }
            else if (Zusage == "N" || Zusage == "n")
            {
                Console.WriteLine("Okay. Schliesse Programm...");
                return "1";
            }
            else
            {
                Console.WriteLine("Ungültige Eingabe. Bitte geben sie eines der Auswahlmöglichkeiten ein.");
                return "0";
            }
        }
        static string einsbisx()
        {
            int einsbishundert = 1;
            string ergebnis = " ";
            Console.WriteLine("Wähle einen Endpunkt kleiner als 8994.");
            int maximum = Convert.ToInt32(Console.ReadLine());
            if (maximum == 420)
            {
                Console.WriteLine("word => suche geheimnis => read");
            }
            else 
            {
                while (einsbishundert <= maximum)
                {
                    if (einsbishundert % 3 == 0 && einsbishundert % 5 == 0)
                    {
                        ergebnis = "fizzbuzz";
                    }
                    else if (einsbishundert % 3 == 0)
                    {
                        ergebnis = "fizz";
                    }
                    else if (einsbishundert % 5 == 0)
                    {
                        ergebnis = "buzz";
                    }
                    else
                    {
                        ergebnis = Convert.ToString(einsbishundert);

                    }
                    Console.WriteLine(ergebnis);
                    einsbishundert += 1;
                }
            }
            return ergebnis;
        }
        static string writing()
        {
            string Dok1 = " ";
            string Dok2 = " ";
            string Dok3 = " ";
            string Dok4 = " ";
            string Dok5 = " ";
            string Dok6 = " ";
            string auswahlDok = " ";
            while(auswahlDok != "exit")
            {
                Console.WriteLine("Wähle ein Dokument [Dok1 - Dok5, exit]");
                auswahlDok = Console.ReadLine();
                if (auswahlDok == "Dok1")
                {
                    Dok1 = editing("Dok1");
                }
                else if (auswahlDok == "Dok2")
                {
                    Dok2 = editing("Dok2");
                }
                else if (auswahlDok == "Dok3")
                {
                    Dok3 = editing("Dok3");
                }
                else if (auswahlDok == "Dok4")
                {
                    Dok4 = editing("Dok4");
                }
                else if (auswahlDok == "Dok5")
                {
                    Dok5 = editing("Dok5");
                }
                else if (auswahlDok == "suche geheimnis")
                {
                    Console.WriteLine("Geheimes Dokument gefunden! Öffne Dok6...");
                    Dok6 = editing("Dok6");
                }
                else if (auswahlDok == "exit")
                {
                    Console.WriteLine("Schliesse Programm");
                } else
                {
                    Console.WriteLine("Ungültige Eingabe");
                }
            }
            return "0";
        }

        static string editing(string document)
        {
            string auswahlOpt = " ";
            string dateiName = @"Z:\Einstiegsaufgaben\DieSammlung\word\" + document + ".txt";
            while (auswahlOpt != "exit")
            {
                Console.WriteLine("Was wollen sie tun? [edit, clear, read, exit]");
                auswahlOpt = Console.ReadLine();
                if (auswahlOpt == "edit")
                {
                    Console.WriteLine("Überschreibe Dokument");
                    document = Console.ReadLine();
                    File.WriteAllText(dateiName, document);
                }
                else if (auswahlOpt == "clear")
                {
                    Console.WriteLine("Leere Dokument...");
                    document = " ";
                    File.WriteAllText(dateiName, document);
                }
                else if (auswahlOpt == "read")
                {
                    document = File.ReadAllText(dateiName);
                    if (document == " ")
                    {
                        Console.WriteLine("Dieses Dokument ist leer.");
                    } else
                    {
                        Console.WriteLine(document);
                    }
                }
                else if (auswahlOpt == "exit")
                {
                    Console.WriteLine("Verlasse Dokument...");
                }
                else
                {
                    Console.WriteLine("Ungültige Eingabe!");
                }
            }
            return document;
        }
        static int web(int cash, string cashSave)
        {
            int leave = 0;
            while (leave == 0)
            {
                Console.WriteLine("|www.web.com              |");
                Console.WriteLine(" ");
                Console.WriteLine(" ");
                Console.WriteLine("Wilkommen zu Web.com. Welche Webseite wollen sie besuchen?");
                string search = Console.ReadLine();
                if (search == "exit")
                {
                    leave = 1;
                    Console.WriteLine("schliesse www.web.com...");
                } else if (search == "store")
                {
                    store(cash, cashSave);
                } else
                {
                    Console.WriteLine("ERROR 404: Diese Webseite liefert 0 Resultate. Überprüfen sie ihre Schreibweise und versuchen Sie es erneut.");
                }
            }
            return cash;
        }
        static int store(int cash, string cashSave)
        {
            
            bool exit = false;
            string DoInStore = "";
            string cashDisplay = cash + "$";
            while (exit == false) {
                cashDisplay = cash + "$";
                Console.WriteLine("|shop.diesammlung.com      |");
                Console.WriteLine(" ");
                Console.WriteLine(" ");
                Console.WriteLine("Wilkommen zum 'Die Sammlung' Shop. Sie haben momentan " + cashDisplay + " Guthaben. Was wollen sie tun?");
                DoInStore = Console.ReadLine();
                if(DoInStore == "exit")
                {
                    Console.WriteLine("Verlasse shop.diesammlung.com...");
                    exit = true;
                }
                else if(DoInStore == "CoinMining")
                {
                    var random = new Random();
                    double randomChance = random.Next(-1, 6);
                    randomChance = Math.Round((double) randomChance);
                    cash += Convert.ToInt32(randomChance);
                    File.WriteAllText(cashSave, Convert.ToString(cash));
                }
                else
                {
                    Console.WriteLine("Error 404: Diese Eingabe ist undefiniert");
                }
            }
            return cash;
        }
        static string password()
        {
            string password = " ";
            int versuche = 0;

            Console.WriteLine("Eingabe Passwort:");
            while(versuche <= 3 && password != "Passwort" && password != "P455W0RT") 
            {
                password = Console.ReadLine();
                if(password == "Passwort")
                {
                    Console.WriteLine("Einloggen...");
                } else if(password == "hint")
                {
                    Console.WriteLine("Hinweis: Wortwörtlich");
                } else if (password == "P455W0RT")
                {
                    Console.WriteLine("Geheimes Passwort entdeckt! Einloggen...");
                    
                } else
                {
                    Console.WriteLine("Falsch");
                    versuche++;
                }
            }
            if (password == "Passwort")
            {
                return "login";
            }
            else if (password == "P455W0RT")
            {
                return "secret";
            } else
            {
                return "fail";
            }
        }    
    
    
    }
}
