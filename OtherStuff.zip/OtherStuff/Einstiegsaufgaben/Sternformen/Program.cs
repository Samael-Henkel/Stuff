﻿using System;

namespace Sternformen
{
    class Program
    {
        static void Main(string[] args)
        {
            Zeichne();
        }
        static string Zeichne()
        {
            int check = 0;
            while (check == 0) 
            {
                Console.WriteLine("Was Wollen sie zeichnen? [sanduhr, pyramide, 4eck, exit]");
                string auswahl = Console.ReadLine();
                if (auswahl == "pyramide")
                {
                    pyramide();
                }
                else if (auswahl == "exit")
                {
                    Console.WriteLine("Schliesse Zeichenprogramm");
                    check = 1;
                } 
                else if (auswahl == "sanduhr")
                {
                    Sanduhr();
                } 
                else if (auswahl == "4eck") 
                {
                    Viereck();
                }
                else
                {
                    Console.WriteLine("Ungültige Eingabe!");
                }

            }
            return "1";
        }
        static string pyramide()
        {
            int weiter = 0;
            while (weiter == 0) {
                Console.WriteLine("Wieviele Lagen soll die Pyramide haben?");
                int lagenanzahl = Convert.ToInt32(Console.ReadLine());
                if (lagenanzahl > 20)
                {
                    Console.WriteLine("Zuviele Lagen!");
                } else
                {
                    for (int i = 1; i <= lagenanzahl; i++)
                    {
                        for (int leere = 1; leere <= lagenanzahl - i; leere++)
                        {
                            Console.Write(" ");
                        }
                        for (int sterne = 1; sterne <= 2 * i - 1; sterne++)
                        {
                            Console.Write("*");
                        }
                        Console.Write("\n");
                    }
                    Console.WriteLine("Noch eine Pyramide zeichnen? [Y/N]");
                    string zustimmen = Console.ReadLine();
                    if(zustimmen == "Y" || zustimmen == "y")
                    {
                        weiter = 0;
                    } else if (zustimmen == "N" || zustimmen == "n")
                    {
                        Console.WriteLine("Schliesse Pyramidenzeichnen...");
                        weiter = 1;
                    }
                }
            }
            return "1";
        }
        static string Sanduhr()
        {
            int weiter = 0;
            while (weiter == 0)
            {
                Console.WriteLine("Wähle die Höhe der Sanduhr");
                int höhe = Convert.ToInt32(Console.ReadLine());
                if (höhe > 20)
                {
                    Console.WriteLine("Zu gross!");
                }
                else
                {
                    for (int j = höhe; j >= 2; j--)
                    {
                        for (int leere = 0; leere <= höhe - j; leere++)
                        {
                            Console.Write(" ");
                        }
                        for (int sterne = 1; sterne <= 2 * j - 1; sterne++)
                        {
                            Console.Write("*");
                        }
                        Console.Write("\n");
                    }
                    for (int i = 1; i <= höhe; i++)
                    {
                        for (int leere = 1; leere <= höhe - i + 1; leere++)
                        {
                            Console.Write(" ");
                        }
                        for (int sterne = 1; sterne <= 2 * i - 1; sterne++)
                        {
                            Console.Write("*");
                        }
                        Console.Write("\n");
                    }
                    Console.WriteLine("Noch eine Sanduhr zeichnen? [Y/N]");
                    string zustimmen = Console.ReadLine();
                    if (zustimmen == "Y" || zustimmen == "y")
                    {
                        weiter = 0;
                    }
                    else if (zustimmen == "N" || zustimmen == "n")
                    {
                        Console.WriteLine("Schliesse Sanduhrzeichnen...");
                        weiter = 1;
                    }
                }
            }
            return "1";
        }
        static string Viereck()
        {
            int weiter = 0;
            while (weiter == 0)
            {
                Console.WriteLine("Wähle die Höhe des Vierecks");
                int höhe = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Wähle die Breite des Vierecks");
                int breite = Convert.ToInt32(Console.ReadLine());
                for(int i = 1; i <= höhe; i++)
                {
                    for (int j = 1; j <= breite; j++)
                    {
                        Console.Write("*");
                    }
                    Console.Write("\n");
                }
                Console.WriteLine("Noch ein Viereck zeichnen? [Y/N]");
                string zustimmen = Console.ReadLine();
                if (zustimmen == "Y" || zustimmen == "y")
                {
                    weiter = 0;
                }
                else if (zustimmen == "N" || zustimmen == "n")
                {
                    Console.WriteLine("Schliesse Viereckzeichnen...");
                    weiter = 1;
                }
                
            }
            return "1";
        }
    }
}
