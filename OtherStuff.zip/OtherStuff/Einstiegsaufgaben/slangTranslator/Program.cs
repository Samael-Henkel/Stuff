﻿using System;

namespace slangTranslator
{
    class Program
    {
        static void Main(string[] args)
        {
            bool stop = false;
            while (stop == false)
            {
                Console.WriteLine("What Sentence should be translated into slang?:");
                string untranslatedString = Console.ReadLine();
                string[] translatedWords = untranslatedString.Split(" ");
                string YesNo = "";
                Console.Write("Translated: ");
                foreach (string word in translatedWords)
                {
                    string newWord = word;
                    if (newWord.Contains("You") && !newWord.Contains("Your"))
                    {
                        newWord = newWord.Replace("You", "Y'all");
                        Console.Write(newWord + " ");
                    } else if(newWord.Contains("you") && !newWord.Contains("your"))
                    {
                        newWord = newWord.Replace("you", "y'all");
                        Console.Write(newWord + " ");
                    } else if (newWord.Contains("ing"))
                    {
                        string[] vowelcheck = { "a", "e", "i", "o", "u" };
                        string newWordminusIng = newWord.Remove(newWord.IndexOf("ing"));
                        int CHECK = 0;
                        foreach (string vowel in vowelcheck)
                        {
                            if (newWordminusIng.Contains(vowel))
                            {
                                CHECK = 1;
                            }
                        }
                        if (CHECK == 1)
                        {
                            newWord = newWord.Replace("ing", "in'");
                        } 
                        Console.Write(newWord + " ");
                    }
                    else
                    {
                        Console.Write(newWord + " ");
                    }
                }
                Console.WriteLine("");
                Console.WriteLine("Continue? [Y/N]");
                while(YesNo != "N" && YesNo != "Y")
                {
                    YesNo = Console.ReadLine();
                    if (YesNo == "N")
                    {
                        stop = true;
                    } 
                    else if (YesNo == "Y")
                    {
                        stop = false;
                    }
                    else
                    {
                        Console.WriteLine("Incorrect: Please try again");
                    }
                }
            }
        }
    }
}
