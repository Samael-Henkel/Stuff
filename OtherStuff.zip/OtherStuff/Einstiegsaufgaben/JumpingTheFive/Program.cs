﻿using System;
using System.IO;

namespace JumpingTheFive
{
    class Program
    {
        static void Main(string[] args)
        {
            int JtF = JumpingTheFive();
        }
        static int JumpingTheFive()
        {
            bool stop = false;
            while (stop == false)
            {
                string uncodeNum = "";
                Console.WriteLine("Read from File?");
                string ReadFromFile = "";
                while (ReadFromFile.ToLower() != "y" && ReadFromFile.ToLower() != "n") 
                {
                    ReadFromFile = Console.ReadLine();
                    if (ReadFromFile.ToLower() == "y")
                    {
                        Console.WriteLine(@"Name a .txt file to read. If it doesnt exist, it should return empty (Z:\)");
                        string ReadFile = @"Z:\" + Console.ReadLine() + ".txt";
                        if (File.Exists(ReadFile))
                        {
                            uncodeNum = File.ReadAllText(ReadFile);
                        } else
                        {
                            uncodeNum = " ";
                        }
                    }
                    else if (ReadFromFile.ToLower() == "n")
                    {
                        Console.WriteLine("Please type text to code:");
                        uncodeNum = Console.ReadLine();
                    } else
                    {
                        Console.WriteLine("Invalid Input. Please try again.");
                    }
                }
                string uncodeNumbers = "0123456789";
                string encodeNumbers = "5987604321";
                int lengthOfuncodeNum = uncodeNum.Length;
                string encoder;
                string encodeNum = "";
                string YesNo = " ";
                for (int i = 0; i < lengthOfuncodeNum; i++)
                {
                    if (uncodeNumbers.Contains(uncodeNum.Substring(i, 1)))
                    {
                        encoder = encodeNumbers.Substring(uncodeNumbers.IndexOf(uncodeNum.Substring(i, 1)), 1);
                        encodeNum += encoder;
                    }
                    else
                    {
                        encodeNum += uncodeNum.Substring(i, 1);
                    }
                }
                if (encodeNum != " ")
                {
                    Console.WriteLine(encodeNum);
                    Console.WriteLine("Save it to a File? [Y/N]");
                    string SaveTofile = "";
                    while (SaveTofile.ToLower() != "y" && SaveTofile.ToLower() != "n")
                    {
                        SaveTofile = Console.ReadLine();
                        if (SaveTofile.ToLower() == "y")
                        {
                            Console.WriteLine("Name the File. If it already exists, it is overwritten.");
                            string Savefile = Console.ReadLine();
                            File.WriteAllText(@"Z:\" + Savefile + ".txt", encodeNum);
                        }
                        else if (SaveTofile.ToLower() == "n")
                        {
                            Console.WriteLine("Erasing Line...");
                        }
                        else
                        {
                            Console.WriteLine("Invalid Input!");
                        }
                    }
                } else if (encodeNum == " ")
                {
                    Console.WriteLine("...but it returned empty.");
                }
                Console.WriteLine("Continue? [Y/N]");
                
                while (YesNo.ToLower() != "y" && YesNo.ToLower() != "n")
                {
                    YesNo = Console.ReadLine();
                    if (YesNo.ToLower() == "y")
                    {
                        stop = false;
                    }
                    else if (YesNo.ToLower() == "n")
                    {
                        stop = true;
                    }
                    else
                    {
                        Console.WriteLine("Error: Is not Y or N!");
                    }
                }
            }
            return 1997;
        }
    }
}
