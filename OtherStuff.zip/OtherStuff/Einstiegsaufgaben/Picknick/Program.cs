﻿using System;

namespace Picknick
{
    class Program
    {
        static void Main(string[] args)
        {
            bool ja = picknick();
        }

        static bool picknick()
        {
            string[] PicknickListe = { "Picknick-Korb, ", "Becher, " };
            
            bool stop = false;
            string YesNo = " ";
            Array.Sort(PicknickListe);
            Console.Write("Ich nehme " + PicknickListe.Length + " Sachen mit: " );
            Array.ForEach(PicknickListe, Console.Write);
            Console.WriteLine(" ");
            Console.WriteLine("Hab ich etwas vergessen?");
            while (stop == false)
            {
                
                while (YesNo != "N")
                {
                    YesNo = Console.ReadLine();
                    if (YesNo == "N")
                    {
                        Console.WriteLine("Das wär dann alles!");
                        stop = true;
                    } else if (YesNo == "Y")
                    {
                        Array.Resize(ref PicknickListe, PicknickListe.Length + 1);
                        Console.WriteLine("Das möchte ich noch mitnehmen:");
                        PicknickListe[PicknickListe.Length - 1] = Console.ReadLine() + ", ";
                        Array.Sort(PicknickListe);
                        Console.Write("Ich nehme " + PicknickListe.Length + " Sachen mit: ");
                        Array.ForEach(PicknickListe, Console.Write);
                        Console.WriteLine(" ");
                        Console.WriteLine("Hab ich noch etwas vergessen?");
                    }
                }
            }
            return true;
        }
    }
}
