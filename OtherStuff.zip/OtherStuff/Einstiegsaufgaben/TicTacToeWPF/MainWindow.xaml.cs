﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TicTacToeWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public string Player = "X";
        void Reset(object sender, RoutedEventArgs e)
        {
            Button1.Visibility = AlwaysVis.Visibility;
            Button2.Visibility = AlwaysVis.Visibility;
            Button3.Visibility = AlwaysVis.Visibility;
            Button4.Visibility = AlwaysVis.Visibility;
            Button5.Visibility = AlwaysVis.Visibility;
            Button6.Visibility = AlwaysVis.Visibility;
            Button7.Visibility = AlwaysVis.Visibility;
            Button8.Visibility = AlwaysVis.Visibility;
            Button9.Visibility = AlwaysVis.Visibility;
            Player = "X";
            AICheck();
        }
        int playerCount = 2;
         public void HumanPlay(object sender, RoutedEventArgs e)
        {
            string ButtonPressed = (sender as Button).Content.ToString();
            var buttonpressed = (sender as Button);
            switch (ButtonPressed)
            {
                case "Oben Links":
                    {
                        TopLeft.Content = Player;
                        buttonpressed.Visibility = HiddenButton.Visibility;
                        break;
                    }
                case "Oben":
                    {
                        Top.Content = Player;
                        buttonpressed.Visibility = HiddenButton.Visibility;
                        break;
                    }
                case "Oben Rechts":
                    {
                        TopRight.Content = Player;
                        buttonpressed.Visibility = HiddenButton.Visibility;
                        break;
                    }
                case "Mitte Links":
                    {
                        CenterLeft.Content = Player;
                        buttonpressed.Visibility = HiddenButton.Visibility;
                        break;
                    }
                case "Mitte":
                    {
                        Center.Content = Player;
                        buttonpressed.Visibility = HiddenButton.Visibility;
                        break;
                    }
                case "Mitte Rechts":
                    {
                        CenterRight.Content = Player;
                        buttonpressed.Visibility = HiddenButton.Visibility;
                        break;
                    }
                case "Unten Links":
                    {
                        BottomLeft.Content = Player;
                        buttonpressed.Visibility = HiddenButton.Visibility;
                        break;
                    }
                case "Unten":
                    {
                        Bottom.Content = Player;
                        buttonpressed.Visibility = HiddenButton.Visibility;
                        break;
                    }
                case "Unten Rechts":
                    {
                        BottomRight.Content = Player;
                        buttonpressed.Visibility = HiddenButton.Visibility;
                        break;
                    }
            }
            if (Player == "X")
            {
                Player = "O";
            }
            else if (Player == "O")
            {
                Player = "X";
            }
            else
            {
                Player = "X";
            }
            AICheck();
        }
        public void AICheck()
        {
            if (Player == "X" && playerCount == 0)
            {
                AIPlay();
            }
            else if (Player == "O" && playerCount <= 1)
            {
                AIPlay();
            }
        }
        public void PlayerSelect(object sender, RoutedEventArgs e)
        {
            if (playerCount == 2)
            {
                playerCount = 1;
                MessageBox.Show(playerCount.ToString());
            }
            else if (playerCount == 1)
            {
                playerCount = 2;
                MessageBox.Show(playerCount.ToString());
            }
            else
            {
                playerCount = 2;
                MessageBox.Show(playerCount.ToString());
            }
            AICheck();
        }
        public void AIPlay()
        {
            Random rng = new Random();
            bool SymbolPlaced = false;
            int attempt = 0;
            while (SymbolPlaced == false && attempt <= 18) 
            {
                string buttonName = "Button" + Convert.ToString(rng.Next(1, 9));
                Button btn = this.FindName(buttonName) as Button;
                if(btn == null)
                {
                    SymbolPlaced = false;
                } else if(btn.Visibility == HiddenButton.Visibility)
                {
                    SymbolPlaced = false;
                    attempt++;
                } else
                {
                    string ButtonText = Convert.ToString(btn.Content);
                    switch (ButtonText)
                    {
                        case "Oben Links":
                            {
                                TopLeft.Content = Player;
                                btn.Visibility = HiddenButton.Visibility;
                                break;
                            }
                        case "Oben":
                            {
                                Top.Content = Player;
                                btn.Visibility = HiddenButton.Visibility;
                                break;
                            }
                        case "Oben Rechts":
                            {
                                TopRight.Content = Player;
                                btn.Visibility = HiddenButton.Visibility;
                                break;
                            }
                        case "Mitte Links":
                            {
                                CenterLeft.Content = Player;
                                btn.Visibility = HiddenButton.Visibility;
                                break;
                            }
                        case "Mitte":
                            {
                                Center.Content = Player;
                                btn.Visibility = HiddenButton.Visibility;
                                break;
                            }
                        case "Mitte Rechts":
                            {
                                CenterRight.Content = Player;
                                btn.Visibility = HiddenButton.Visibility;
                                break;
                            }
                        case "Unten Links":
                            {
                                BottomLeft.Content = Player;
                                btn.Visibility = HiddenButton.Visibility;
                                break;
                            }
                        case "Unten":
                            {
                                Bottom.Content = Player;
                                btn.Visibility = HiddenButton.Visibility;
                                break;
                            }
                        case "Unten Rechts":
                            {
                                BottomRight.Content = Player;
                                btn.Visibility = HiddenButton.Visibility;
                                break;
                            }
                    }
                    SymbolPlaced = true;
                }
            }
            if (Player == "X")
            {
                Player = "O";
            }
            else if (Player == "O")
            {
                Player = "X";
            }
            else
            {
                Player = "X";
            }
            AICheck();
        }
    } 
}
