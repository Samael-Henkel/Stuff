﻿using System;
using System.Text;

namespace ScrambledEggsuhimeanWords
{
    class Program
    {
        static void Main(string[] args)
        {
            bool stop = false;
            while (stop == false)
            {

                string YesNo = "";
                Console.Write("Welchen Satz willst du scramblen lassen?: ");
                string unscrambledText = Console.ReadLine();
                string[] unscrambledWords = unscrambledText.Split(" ");
                var rng = new Random();
                foreach (string word in unscrambledWords)
                {
                    string newWord = word;
                    int wordLength = newWord.Length;
                    for(int i = wordLength - 2; i >= 1; i--)
                    {
                        string letter1 = newWord.Substring(i, 1);
                        int newPos = rng.Next(1, i);
                        string letter2 = newWord.Substring(newPos, 1);
                        var change = new StringBuilder(newWord);
                        change[newPos] = Convert.ToChar(letter1);
                        change[i] = Convert.ToChar(letter2);
                        newWord = Convert.ToString(change);
                    }
                    Console.Write(newWord + " ");
                }
                Console.WriteLine("");
                Console.WriteLine("Continue? [Y/N]");
                while (YesNo != "N" && YesNo != "Y")
                {
                    YesNo = Console.ReadLine();
                    if (YesNo == "N")
                    {
                        stop = true;
                    }
                    else if (YesNo == "Y")
                    {
                        stop = false;
                    }
                    else
                    {
                        Console.WriteLine("Incorrect: Please try again");
                    }
                }
            }
        }
    }
}
