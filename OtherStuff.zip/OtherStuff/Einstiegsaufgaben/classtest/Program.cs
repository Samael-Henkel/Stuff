﻿using System;

namespace classtest
{
    class Person
    {
        private int IntelligenceScore;
        public int IntScore
        {

            get { return IntelligenceScore; }
            set { IntelligenceScore = value; }
        }
    }
    class Program
    {
        static void Main(string[]
        args)
        {
            Person Samael = new Person();
            Samael.IntScore = 3;
            Console.WriteLine(Samael.IntScore);
        }
    }
}


