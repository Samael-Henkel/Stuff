﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace dateienLesenWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string FileName = "";
        public string FileContent = "";
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Choosing(object sender, RoutedEventArgs e)
        {
            FileName = @"Z:\" + InputBox.Text + ".txt";
            if (File.Exists(FileName))
            {
                FileContent = File.ReadAllText(FileName);
                WriteBox.Text = FileContent;
            }
            else
            {
                MessageBox.Show("Ungültiger Dateiname");
            }
        }
        private void Clearing(object sender, RoutedEventArgs e)
        {
            WriteBox.Text = "";
            File.WriteAllText(FileName, "");
            MessageBox.Show("Datei geleert");
        }
        private void Saving(object sender, RoutedEventArgs e)
        {
            File.WriteAllText(FileName, WriteBox.Text);
        }
        private void SavingAs(object sender, RoutedEventArgs e)
        {
            FileName = @"Z:\" + InputBox.Text + ".txt";
            File.WriteAllText(FileName, WriteBox.Text);
        }
    }
}
